from algorithm.utils import log

__all__ = [
    'log'
]