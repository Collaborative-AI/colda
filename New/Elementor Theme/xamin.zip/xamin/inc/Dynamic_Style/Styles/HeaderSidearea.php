<?php

/**
 * Xamin\Xamin\Dynamic_Style\Styles\HeaderSidearea class
 *
 * @package xamin
 */

namespace Xamin\Xamin\Dynamic_Style\Styles;

use Xamin\Xamin\Dynamic_Style\Component;
use function add_action;


class HeaderSidearea extends Component
{

	public function __construct()
	{
		add_action('wp_enqueue_scripts', array($this, 'xamin_header_sidearea_style'));
	}

	public function xamin_header_sidearea_style()
	{
		$xamin_option = get_option('xamin_options');
		$dynamic_css = '';
		if (isset($xamin_option['header_display_side_area']) && $xamin_option['header_display_side_area'] == 'no') {
			$dynamic_css .= '.iq-sidearea-btn-container{
				display:none !important;
			}';
		}

		if (isset($xamin_option['sidearea_background_type']) && $xamin_option['sidearea_background_type'] != 'default') {
			$type = $xamin_option['sidearea_background_type'];
			if ($type == 'color') {
				if (!empty($xamin_option['sidearea_background_color'])) {
					$dynamic_css .= '.iq-menu-side-bar{
						background:' . $xamin_option['sidearea_background_color'] . ' !important;
					}';
				}
			}

			if ($type == 'image') {
				if (!empty($xamin_option['sidearea_background_image']['url'])) {
					$dynamic_css .= '.iq-menu-side-bar{
						background:url(' . $xamin_option['sidearea_background_image']['url'] . ') !important;
					}';
				}
			}

			if ($type == 'transparent') {
				$dynamic_css .= '.iq-menu-side-bar{
					background:transparent !important;
				}';
			}
		}

		if (isset($xamin_option['sidearea_width']['width']) && !empty($xamin_option['sidearea_width']['width']) && strlen($xamin_option['sidearea_width']['width']) > 2) {
			$xamin_option['sidearea_width']['width'];
			$dynamic_css .= '.iq-menu-side-bar{
				width:' . $xamin_option['sidearea_width']['width'] . ' !important;
				right:-' . $xamin_option['sidearea_width']['width'] . ' !important;
			}';
			$dynamic_css .= '.side-bar-open .iq-menu-side-bar{
				right:0 !important;
			}';
		}
		if (isset($xamin_option['sidearea_btn_color_type']) && $xamin_option['sidearea_btn_color_type'] == 'custom') {
			if (isset($xamin_option['sidearea_btn_open_color']) && !empty($xamin_option['sidearea_btn_open_color'])) {
				$dynamic_css .= '.iq-sidearea-btn-container{
					background:' . $xamin_option['sidearea_btn_open_color'] . ' !important;
				}';
			}

			if (isset($xamin_option['sidearea_btn_open_hover']) && !empty($xamin_option['sidearea_btn_open_hover'])) {
				$dynamic_css .= '.iq-sidearea-btn-container:hover{
					background:' . $xamin_option['sidearea_btn_open_hover'] . ' !important;
				}';
			}
			if (isset($xamin_option['sidearea_btn_close_color']) && !empty($xamin_option['sidearea_btn_close_color'])) {
				$dynamic_css .= 'body.side-bar-open .iq-sidearea-btn-container.btn-container-close{
					background:' . $xamin_option['sidearea_btn_close_color'] . ' !important;
				}';
			}

			if (isset($xamin_option['sidearea_btn_close_hover']) && !empty($xamin_option['sidearea_btn_close_hover'])) {
				$dynamic_css .= 'body.side-bar-open .iq-sidearea-btn-container.btn-container-close:hover{
					background:' . $xamin_option['sidearea_btn_close_hover'] . ' !important;
				}';
			}

			if (isset($xamin_option['sidearea_btn_line_color']) && !empty($xamin_option['sidearea_btn_line_color'])) {
				$dynamic_css .= '.menu-btn .line{
					background:' . $xamin_option['sidearea_btn_line_color'] . ' !important;
				}';
			}

			if (isset($xamin_option['sidearea_btn_line_hover_color']) && !empty($xamin_option['sidearea_btn_line_hover_color'])) {
				$dynamic_css .= '.iq-sidearea-btn-container:hover .menu-btn .line{
					background:' . $xamin_option['sidearea_btn_line_hover_color'] . ' !important;
				}';
			}

			if (isset($xamin_option['sidearea_btn_close_line_color']) && !empty($xamin_option['sidearea_btn_close_line_color'])) {
				$dynamic_css .= 'body.side-bar-open .iq-sidearea-btn-container.btn-container-close .menu-btn .line{
					background:' . $xamin_option['sidearea_btn_close_line_color'] . ' !important;
				}';
			}

			if (isset($xamin_option['sidearea_btn_close_line_hover_color']) && !empty($xamin_option['sidearea_btn_close_line_hover_color'])) {
				$dynamic_css .= 'body.side-bar-open .iq-sidearea-btn-container.btn-container-close:hover .menu-btn .line{
					background:' . $xamin_option['sidearea_btn_close_line_hover_color'] . ' !important;
				}';
			}
		}
		if (!empty($dynamic_css)) {
			wp_add_inline_style('xamin-global', $dynamic_css);
		}
	}
}
