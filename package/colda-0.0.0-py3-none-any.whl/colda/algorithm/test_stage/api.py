from algorithm.test_stage.make_eval import MakeEval
from algorithm.test_stage.make_test_local import MakeTestLocal
from algorithm.test_stage.make_test import MakeTest


__all__ = [
    'MakeEval',
    'MakeTestLocal',
    'MakeTest',
]