<?php 

if(function_exists('get_field') && class_exists('ReduxFramework'))
{
    add_action( 'wp_head', 'xamin_banner_dynamic_style' );
}
function xamin_banner_dynamic_style()
{
    $page_id = get_queried_object_id();
    $xamin_option = get_option('xamin_options');
    $dynamic_css = array();
    

    	if(get_field('display_banner' , $page_id) != 'default')  
        {	
        	if(get_field('display_banner' , $page_id) == 'no')
        	{
        		$dynamic_css[] = array(
		        'elements'  =>  '.iq-breadcrumb-one',
		        'property'  =>  'display',
		        'value'     =>  'none !important'
		    	);
                
                $dynamic_css[] = array(
                'elements'  =>  '.content-area .site-main',
                'property'  =>  'padding',
                'value'     =>  '0 !important'
                );
        	}
    	}
	    else if(isset($xamin_option['display_banner']))
	    {
	    	 
	    	if($xamin_option['display_banner'] == 'no')
	    	{
				$dynamic_css[] = array(
		        'elements'  =>  '.iq-breadcrumb-one',
		        'property'  =>  'display',
		        'value'     =>  'none !important'
		    	);

                $dynamic_css[] = array(
                'elements'  =>  '.content-area .site-main',
                'property'  =>  'padding',
                'value'     =>  '0 !important'
                );
	    	}
	    }
	
    
    
    	if( is_home() )
        {
            $page_id = get_queried_object_id();
            $key = get_field('key_pjros', $page_id);
        }
        else
        {
            $key = get_field('key_pjros');    
        }

    	if($key['display_title'] != 'default'  && $key['display_title'] == 'no' )
    	{
    		$dynamic_css[] = array(
            'elements'  =>  '.iq-breadcrumb-one .title',
            'property'  =>  'display',
            'value'     =>  'none !important'
        	);
    	}
    	else if(isset($xamin_option['display_title']))
    	{
    	 
	    	if($xamin_option['display_title'] == 'no')
	    	{
				$dynamic_css[] = array(
	            'elements'  =>  '.iq-breadcrumb-one .title',
	            'property'  =>  'display',
	            'value'     =>  'none !important'
	        	);
	    	}
    	}
        
    	if($key['display_breadcumb'] != 'default'  && $key['display_breadcumb'] == 'no' )
    	{
    		$dynamic_css[] = array(
            'elements'  =>  '.iq-breadcrumb-one .breadcrumb',
            'property'  =>  'display',
            'value'     =>  'none !important'
        	);
    	}
    	else if(isset($xamin_option['display_breadcumb']))
    	{
    	 
	    	if($xamin_option['display_breadcumb'] == 'no')
	    	{
				$dynamic_css[] = array(
            	'elements'  =>  '.iq-breadcrumb-one .breadcrumb',
            	'property'  =>  'display',
            	'value'     =>  'none !important'
        		);
	    	}
    	}
    
    if(isset($xamin_option['bg_title_color']))
    {
    	 
    	if($xamin_option['bg_title_color'] == 'no')
    	{
			$dynamic_css[] = array(
            'elements'  =>  '.iq-breadcrumb-one .title',
            'property'  =>  'color',
            'value'     =>  $xamin_option['bg_title_color'].'!important'
        	);
    	}
    }

    if(isset($xamin_option['banner_height_switch']))
    {
        if($xamin_option['banner_height_switch'] == 'yes')
        {
            if(isset($xamin_option['banner_height']['height']) && !empty($xamin_option['banner_height']['height']))
            {
            $banner_height = $xamin_option['banner_height']['height'];

            $dynamic_css[] = array(
                    'elements'  =>  '.iq-breadcrumb-one',
                    'property'  =>  'height',
                    'value'     =>  $banner_height. '!important'
                );
        	}
        }
        
    }

    if(isset($xamin_option['banner_top_padding']) && !empty($xamin_option['banner_top_padding']))
    {      
        $banner_top_padding = $xamin_option['banner_top_padding'];

		$dynamic_css[] = array(
        'elements'  =>  '.iq-breadcrumb-one',
        'property'  =>  'padding-top',
        'value'     =>  $banner_top_padding. 'px !important'
    	);
    }

    if(isset($xamin_option['banner_bottom_padding']) && !empty($xamin_option['banner_bottom_padding']))
    {    
		$banner_bottom_padding = $xamin_option['banner_bottom_padding'];

		$dynamic_css[] = array(
        'elements'  =>  '.iq-breadcrumb-one',
        'property'  =>  'padding-bottom',
        'value'     =>  $banner_bottom_padding. 'px !important'
		);
    }


    $key = get_field('key_banner_back' , $page_id);

    if($key['banner_background_type'] != 'default')
    {
        if($key['banner_background_type'] == 'color')
        {
            $dynamic_css[] = array(
            'elements'  =>  '.iq-breadcrumb-one',
            'property'  =>  'background',
            'value'     =>  $key['banner_background_color']. ' !important'
            );
        }

        if($key['banner_background_type'] == 'image')
        {
            $dynamic_css[] = array(
            'elements'  =>  '.iq-breadcrumb-one',
            'property'  =>  'background',
            'value'     =>  'url('.$key['banner_background_image']['url'].') !important'
            );

            if(!empty($key['banner_background_size']))
            {
                $dynamic_css[] = array(
                'elements'  =>  '.iq-breadcrumb-one',
                'property'  =>  'background-size',
                'value'     =>  $key['banner_background_size']. ' !important'
                ); 
            }

            if(!empty($key['banner_background_repeat']))
            {
                $dynamic_css[] = array(
                'elements'  =>  '.iq-breadcrumb-one',
                'property'  =>  'background-repeat',
                'value'     =>  $key['banner_background_repeat']. ' !important'
                ); 
            }
        }
    }
    else if(isset($xamin_option['bg_type']))
    {    
		$opt = $xamin_option['bg_type'];
		if($opt == '1')
		{
			if(isset($xamin_option['bg_color']))
			{
				$dynamic_css[] = array(
        		'elements'  =>  '.iq-breadcrumb-one',
	        	'property'  =>  'background',
	        	'value'     =>  $xamin_option['bg_color']. ' !important'
				);
			}
			
		}
		if($opt == '2')
		{
			if(isset($xamin_option['banner_image']['url']))
			{
				$dynamic_css[] = array(
	        	'elements'  =>  '.iq-breadcrumb-one',
	        	'property'  =>  'background',
	        	'value'     =>  'url('.$xamin_option['banner_image']['url'].') !important'
				);
			}
			
		}

		
    }
  
    if ( count( $dynamic_css ) > 0 ) 
    {
        echo "<style type='text/css' id='xamin-dynamic-css".rand(10,100000)."'>\n\n"; 
            xamin_dynamic_style( $dynamic_css );
        echo '</style>';
    }  
}

function xamin_banner_class()
{
	$xamin_option = get_option('xamin_options');
	$classes = array();
	
	array_push($classes, ' iq-bg-over');	

	if(isset($xamin_option['bg_opacity']))
	{
		$opt = $xamin_option['bg_opacity'];
		if($opt == '1')
		{
			array_push($classes, ' black');			
		}
		if($opt == '2')
		{
			array_push($classes, ' iq-over-dark-80');			
		}
		if($opt == '3')
		{
			array_push($classes, ' breadcrumb-bg breadcrumb-ui');			
		}
	}

	echo esc_attr(implode(' ',$classes));

}
