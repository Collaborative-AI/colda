=== Xamin ===

Contributors: automattic
Tags: four-columns,left-sidebar,right-sidebar,custom-background,custom-colors,custom-header,custom-logo,custom-menu

Requires at least: 5.0
Tested up to: 6.0
Requires PHP: 5.6+
Stable tag: 1.0.0
License: GNU General Public License v2 or later
License URI: LICENSE

A starter theme called Xamin.

== Description ==

Description

== Installation ==

1. In your admin panel, go to Appearance > Themes and click the Add New button.
2. Click Upload Theme and Choose File, then select the theme's .zip file. Click Install Now.
3. Click Activate to use your new theme right away.

== Frequently Asked Questions ==

= Does this theme support any plugins? =

Xamin includes support for Elementor.

== Changelog ==

= Version 3.4.2 – 5 July 2022 =
- Bug Fixing

= Version 3.4.1 – 01st June 2022 =
-[Add] - WordPress Version 6.0 Supported

= 3.4.0 - Mar 25 2022 =
- [Fixed] Elementor Version 3.6.0 Supported
- [Optimise] CSS Optimise
- [Optimise] Xamin extension optimise
- [Optimise] WooCommerce Optimise
- [Added] New Iqonic image Widget
- [Added] New Iqonic Layout Plugin with power of header,footer Builder
- [Added] Mega Menu With Iqonic Layout
- [Added] Smooth scroll Feature
- [Added] Add/Update New Shop Pages
    -> Portfolio List
        - Portfolio Grid
            - 2 Columns
            - 3 Columns
            - 3 Columns + Full Width
            - 4 Columns
            - 4 Columns + Full Width
            - 5 Columns
        - Portfolio Tab
            - Tab Style-1
            - Tab Style-2
        - Portfolio Detail
    -> Shop List
        - Left Sidebar
        - Right Sidebar
        - No Sidebar
    -> Shop Grid
        - Two column
        - Three column
        - Three column + Full Width
        - Four column
        - Four column + Full Width
        - Five Column
    -> Product Type
        - Product Standard
        - Product Sale
        - Product New
    -> Shop Page
        - Cart
        - Wishlist
        - Checkout
        - My Account
-[Added] New Blog Pages
    -> Blog Listing
    -> Blog Grid
        - Two Columns
        - Three Columns
        - Three Columns + Full Width
        - Four Columns
        - Four Columns + full Width
    -> Blog Sidebar
        - Left Sidebar Grid
        - Left Sidebar Grid 2
        - Right Sidebar Grid
        - Right Sidebar Grid 2
    -> Blog Single
        - standard
        - video
        - audio
        - quote
        - gallery
        - link

= 3.3.2 - Dec 16 2021 =
- [Fixed] Bug Fixing 

= 3.3.1 - Oct 20 2021 =
- [Fixed] Minor Bug Fixes

= 3.0.3 - Jul 9 2021 =
- [Fixed] Minor Bug Fixes

= 3.0.1 - Jun 9 2021 =
- [Fixed] Minor Bug Fixes

= 3.0.0 - Jun 7 2021 =
- [Added] New Modern Design
- [Added] New Elements Added
- [Improve] Improve Performance
- [Fixed] Minor Bug Fixes
- WpBakery Version 3.3.0
- [Fixed] Minor Bug Fixes

= 2.5.3 - Oct 20 2020 =
 - Minor Fixes

= 2.5.2 - Aug 12 2020 =
- [Added]  Elementor Version : Analytics Dashboards

= 2.5.2 - Aug 31 2020 =
- [Fixed] Elementor Version : Minor CSS improvements
- [Fixed] Elementor Version : Themeoptions minor bug fixes

= 2.5.1 - Aug 26 2020 =
- [Added] Elementor Version : Added New header Style
- [Added] Elementor Version : Added Side panel 
- [Fixed] Elementor Version : Color customization options
- [Fixed] Elementor Version : Minor Bugs

= 2.5 - Jul 9 2020 =
- [Added] Elementor Version
- [Added] Advanced Page options

= 2.0.1 - Jun 22 2020 =
- [Fixed] Bug Fixes
- [Added] Fontawesome 5 support 

= 2.0 - Mar 17 2020 =
- [NEW PAGE] Corona Virus Tracker

= 1.9 - Feb 28 2020 =
- [NEW PAGE] Data Science Online Courses
- [NEW PAGE] Data Science Ebook
- [NEW PAGE] Data Science News
- [NEW PAGE] Project Showcase

= 1.9 - Feb 22 2020 =
- [NEW PAGE] Analytics in Healthcare
- [NEW PAGE] Analytics in Sports
- [NEW PAGE] Analytics in Education
- [NEW PAGE] Analytics in Datacenter

= 1.8 - Jan 30 2020 =
- [FIXED] Themes Demo Import Bug Fixed

= 1.7 - Jan 4 2020 =
- [NEW UPDATE] Analytics in Banking & Finance Home Page
- [NEW UPDATE] Analytics in Manufacturing Home Page
- [NEW UPDATE] FAQ Page

= 1.6 - Dec 12 2019 =
- [NEW UPDATE] Data Visualization Home Page
- [NEW UPDATE] Analytics in Marketing Home Page 

= 1.5 - Dec 8 2019 =
- [NEW UPDATE] User Behaviour Analysis Home Page
- [NEW UPDATE] Data Scientist Profile Home Page
- [FIXED] Minor Bug  Fixes
- [UPDATE] Style.css
- [UPDATE] Responsive.css

= 1.3 - Dec 4 2019 =
- [FIXED] Team Minor Bug  Fixes
- [UPDATE] Style.css
- [UPDATE] Responsive.css

= 1.3 - Nov 15 2019 =
- [NEW UPDATE] Business Intelligence
- [NEW UPDATE] Predictive Analysis
- [FIXED] Minor Bug  Fixes
- [UPDATE] Style.css
- [UPDATE] Responsive.css

= 1.1 - Nov 9 2019 =
- [NEW UPDATE] Home Page 4
- [NEW UPDATE] Home Page 3
- [UPDATE] Added Slider Revolution v6.1.3
- [FIXED] Minor Bug  Fixes
- [UPDATE] Style.css
- [UPDATE] Responsive.css

= 1.0 - Oct 25 2019 =
* Initial release
