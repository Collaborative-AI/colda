<?php
/**
 * Xamin\Xamin\Scripts\Component class
 *
 * @package xamin
 */

namespace Xamin\Xamin\Scripts;

use Xamin\Xamin\Component_Interface;
use Xamin\Xamin\Templating_Component_Interface;
use function Xamin\Xamin\xamin;
use function add_action;
use function wp_enqueue_script;
use function get_theme_file_uri;
use function get_theme_file_path;

class Component implements Component_Interface {

	/**
	 * Associative array of CSS files, as $handle => $data pairs.
	 * $data must be an array with keys 'file' (file path relative to 'assets/css' directory), and optionally 'global'
	 * (whether the file should immediately be enqueued instead of just being registered) and 'preload_callback'
	 * (callback function determining whether the file should be preloaded for the current request).
	 *
	 * Do not access this property directly, instead use the `get_css_files()` method.
	 *
	 * @var array
	 */
	protected $js_files;

	/**
	 * Gets the unique identifier for the theme component.
	 *
	 * @return string Component slug.
	 */
	public function get_slug() : string {
		return 'scripts';
	}

	/**
	 * Adds the action and filter hooks to integrate with WordPress.
	 */
	public function initialize() {
		add_action( 'wp_enqueue_scripts', array( $this, 'action_enqueue_scripts' ) );
	}

	/**
	 * Registers or enqueues stylesheets.
	 *
	 * Stylesheets that are global are enqueued. All other stylesheets are only registered, to be enqueued later.
	 */
	public function action_enqueue_scripts() {

		$js_uri = get_template_directory_uri() . '/assets/js/';
        $js_dir = get_template_directory() . '/assets/js/';
		$js_files = $this->get_js_files();
		
		/* Array merge when smoothscroll option off */
		if (class_exists('ReduxFramework')) {
			$xamin_options = get_option('xamin_options');
			
			if (isset($xamin_options['smoth_scroll']) &&$xamin_options['smoth_scroll']  == 'on') {
				$scroll_js = array(
					'smooth-scroll' => array(
						'file'   => 'vendor/smooth-scroll.js',
						'dependency' => array('jquery'),
						'in_footer' => true,
					),
				);
				
				$js_files =  array_merge($js_files, $scroll_js);
			}
			

			$custom_js = [
				'customizer'     => array(
					'file'   => 'customizer.min.js',
					'dependency' => array('jquery'),
					'in_footer' => true,
				)
			];
	
			$js_files =  array_merge($js_files, $custom_js);
		}
		
		foreach ( $js_files as $handle => $data ) {
			$src     = $js_uri . $data['file'];
			
			$version = xamin()->get_asset_version( $js_dir . $data['file'] );
			wp_enqueue_script( $handle,$src,$data['dependency'],$version,$data['in_footer']);
		}
	}

	/**
	 * Gets all JS files.
	 *
	 * @return array Associative array of $handle => $data pairs.
	 */
	protected function get_js_files() : array {
		if ( is_array( $this->js_files ) ) {
			return $this->js_files;
		}

		$js_files = array(
			'bootstrap'     => array(
				'file'   => 'vendor/bootstrap.min.js',
				'dependency' => array('jquery'),
				'in_footer' => true,
			),
			'wow'     => array(
				'file'   => 'vendor/wow.min.js',
				'dependency' => array('jquery'),
				'in_footer' => true,
			),
			'countdown'     => array(
				'file'   => 'vendor/countdown.js',
				'dependency' => array('jquery'),
				'in_footer' => true,
			),
			'appear'     => array(
				'file'   => 'vendor/appear.js',
				'dependency' => array('jquery'),
				'in_footer' => true,
			),
			'jquery-countTo'     => array(
				'file'   => 'vendor/jquery.countTo.js',
				'dependency' => array('jquery'),
				'in_footer' => true,
			),
			'magnific-popup'     => array(
				'file'   => 'vendor/jquery.magnific-popup.min.js',
				'dependency' => array('jquery'),
				'in_footer' => true,
			),
			'skrollr'     => array(
				'file'   => 'vendor/skrollr.js',
				'dependency' => array('jquery'),
				'in_footer' => true,
			),
			'isotope-pkgd'     => array(
				'file'   => 'vendor/isotope.pkgd.min.js',
				'dependency' => array('jquery'),
				'in_footer' => true,
			),
			'owl-carousel'     => array(
				'file'   => 'vendor/owl.carousel.min.js',
				'dependency' => array('jquery'),
				'in_footer' => true,
			),
			'popper-min'     => array(
				'file'   => 'vendor/popper.min.js',
				'dependency' => array('jquery'),
				'in_footer' => true,
			),
			'swiper-min'     => array(
				'file'   => 'vendor/swiper.min.js',
				'dependency' => array('jquery'),
				'in_footer' => true,
			),
			'slick-min'     => array(
				'file'   => 'vendor/slick.min.js',
				'dependency' => array('jquery'),
				'in_footer' => true,
			),
			'custom-wishlist'     => array(
				'file'   => 'vendor/custom-wishlist.js',
				'dependency' => array('jquery'),
				'in_footer' => true,
			),
			'sticky'     => array(
				'file'   => 'vendor/sticky.js',
				'dependency' => array('jquery'),
				'in_footer' => true,
			),
			'smooth-scrollbar'			=> array(
				'file'   => 'vendor/smooth-scrollbar.js',
				'dependency' => array('jquery'),
				'in_footer' => true,
			),
			'nice-select'     => array(
				'file'   => 'vendor/jquery.nice-select.min.js',
				'dependency' => array('jquery'),
				'in_footer' => true,
			),
			'select2'     => array(
				'file'   => 'vendor/select2.js',
				'dependency' => array('jquery'),
				'in_footer' => true,
			),
			'superfish'     => array(
				'file'   => 'vendor/superfish.js',
				'dependency' => array('jquery'),
				'in_footer' => true,
			),
			'customizer'     => array(
				'file'   => 'customizer.min.js',
				'dependency' => array('jquery'),
				'in_footer' => true,
			)
		);
		$this->js_files = array();
		foreach ( $js_files as $handle => $data ) {
			if ( is_string( $data ) ) {
				$data = array( 'file' => $data );
			}

			if ( empty( $data['file'] ) ) {
				continue;
			}

			$this->js_files[ $handle ] = array_merge(
				array(
					'global'           => false,
					'preload_callback' => null,
					'media'            => 'all',
				),
				$data
			);
		}

		return $this->js_files;
	}
}
