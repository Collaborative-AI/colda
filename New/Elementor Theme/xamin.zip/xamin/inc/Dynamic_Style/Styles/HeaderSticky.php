<?php

/**
 * Xamin\Xamin\Dynamic_Style\Styles\HeaderSticky class
 *
 * @package xamin
 */

namespace Xamin\Xamin\Dynamic_Style\Styles;

use Xamin\Xamin\Dynamic_Style\Component;
use function add_action;

class HeaderSticky extends Component
{
	public function __construct()
	{
		add_action('wp_enqueue_scripts', array($this, 'xamin_header_sticky_background_style'));
		add_action('wp_enqueue_scripts', array($this, 'xamin_sticky_sub_menu_color_options'), 20);
		add_action('wp_enqueue_scripts', array($this, 'xamin_sticky_menu_color_options'), 20);
	}

	public function xamin_header_sticky_background_style()
	{
		$xamin_option = get_option('xamin_options');
		$inline_css = '';


		if (function_exists('get_field')) {
			$page_id_header = get_queried_object_id();

			$key_header_back = get_field('key_dark_header', $page_id_header);
			$key_header_style = get_field('key_header', $page_id_header);

			$header_style = $key_header_style['header_variation'];
			$has_dark = $key_header_back['name_menu_has_dark'];
			$back_color = $key_header_back['name_back_color'];
		}
		
		if (isset($has_dark) && $has_dark == 'yes' && isset($back_color) && !empty($back_color)  && isset($header_style) && $header_style != '3') {
			$inline_css = 'header .menu-sticky.main-header{
				background : ' . $back_color . ' !important
			}';
		} else if (isset($xamin_option['sticky_header_background_type']) && $xamin_option['sticky_header_background_type'] != 'default') {
			$type = $xamin_option['sticky_header_background_type'];
			if ($type == 'color') {
				if (!empty($xamin_option['sticky_header_background_color'])) {
					$inline_css = 'header .menu-sticky.main-header{
						background : ' . $xamin_option['sticky_header_background_color'] . ' !important
					}';
				}
			}

			if ($type == 'image') {
				if (!empty($xamin_option['sticky_header_background_image']['url'])) {
					$inline_css = 'header .menu-sticky.main-header{
						background : url(' . $xamin_option['sticky_header_background_image']['url'] . ') !important
					}';
				}
			}

			if ($type == 'transparent') {
				$inline_css = 'header .menu-sticky.main-header{
					background : transparent !important
				}';
			}
		}

		if (!empty($inline_css)) {
			wp_add_inline_style('xamin-global', $inline_css);
		}
	}

	public function xamin_sticky_menu_color_options()
	{
		$xamin_option = get_option('xamin_options');
		$inline_css = '';
		if (isset($xamin_option['sticky_menu_color_type']) && $xamin_option['sticky_menu_color_type'] == 'custom') {

			if (isset($xamin_option['sticky_menu_color']) && !empty($xamin_option['sticky_menu_color'])) {
				$inline_css .= 'header .menu-sticky .navbar ul li a,header .menu-sticky .navbar ul li i{
					color : ' . $xamin_option['sticky_menu_color'] . '!important;
				}';
			}
			if (isset($xamin_option['sticky_menu_active_color']) && !empty($xamin_option['sticky_menu_active_color'])) {
				$inline_css .= 'header .menu-sticky .navbar ul li.current-menu-item a, header .menu-sticky .navbar ul li.current-menu-parent a, header .menu-sticky .navbar ul li.current-menu-parent i, header .menu-sticky .navbar ul li.current-menu-item i,header .menu-sticky .navbar ul li.current-menu-ancestor a,header .menu-sticky .navbar ul li.current-menu-ancestor i{
					color : ' . $xamin_option['sticky_menu_active_color'] . '!important;
				}';
			}
			if (isset($xamin_option['sticky_menu_hover_color']) && !empty($xamin_option['sticky_menu_hover_color'])) {
				$inline_css .= 'header .menu-sticky .navbar ul li:hover a,header .menu-sticky .navbar ul li:hover i{
					color : ' . $xamin_option['sticky_menu_hover_color'] . '!important;
				}';
			}
		}

		if (!empty($inline_css)) {
			wp_add_inline_style('xamin-global', $inline_css);
		}
	}

	public function xamin_sticky_sub_menu_color_options()
	{
		$xamin_option = get_option('xamin_options');
		$inline_css = '';

		if (isset($xamin_option['sticky_header_submenu_color_type']) && $xamin_option['sticky_header_submenu_color_type'] == 'custom') {
			if (isset($xamin_option['sticky_xamin_header_submenu_color']) && !empty($xamin_option['sticky_xamin_header_submenu_color'])) {
				$inline_css .= 'header .menu-sticky #mega-menu-top > li ul.mega-sub-menu li.mega-menu-item a,header .menu-sticky #mega-menu-top > li ul.mega-sub-menu li.mega-menu-item i,header .menu-sticky #mega-menu-top > li ul.mega-sub-menu li.mega-menu-item svg,header .menu-sticky .navbar ul li .sub-menu li a,header .menu-sticky .navbar ul li .sub-menu li.current-menu-parent .sub-menu  li a, header .menu-sticky .navbar ul li .sub-menu li:hover .sub-menu li a,header .menu-sticky .navbar ul li .sub-menu li i,header .menu-sticky .navbar ul li .sub-menu li.current-menu-parent .sub-menu  li i, header .menu-sticky .navbar ul li .sub-menu li:hover .sub-menu li i,header .menu-sticky .navbar ul li .sub-menu li:hover .sub-menu li a,header .menu-sticky .navbar ul li .sub-menu li:hover .sub-menu li i{
                color : ' . $xamin_option['sticky_xamin_header_submenu_color'] . ' !important;
            }';
			}

			if (isset($xamin_option['sticky_xamin_header_submenu_active_color']) && !empty($xamin_option['sticky_xamin_header_submenu_active_color'])) {
				$inline_css .= 'header .menu-sticky #mega-menu-top > li ul.mega-sub-menu li.mega-current-menu-item a,header .menu-sticky #mega-menu-top > li ul.mega-sub-menu li.mega-current-menu-item svg,header .menu-sticky #mega-menu-top > li ul.mega-sub-menu li.mega-current-menu-item i,header .menu-sticky .navbar ul li .sub-menu li.current-menu-item a,header .menu-sticky .navbar ul li .sub-menu li.current-menu-item i,header .menu-sticky .navbar ul li .sub-menu li.current-menu-ancestor a,header .menu-sticky .navbar ul li .sub-menu li.current-menu-ancestor i,header .menu-sticky .navbar ul li .sub-menu li.current-menu-parent .sub-menu li.current-menu-item  a,header .menu-sticky .navbar ul li .sub-menu li.current-menu-parent .sub-menu li.current-menu-item  i{
                color : ' . $xamin_option['sticky_xamin_header_submenu_active_color'] . ' !important;
            }';
			}

			if (isset($xamin_option['sticky_xamin_header_submenu_hover_color']) && !empty($xamin_option['sticky_xamin_header_submenu_hover_color'])) {
				$inline_css .= 'header .menu-sticky #mega-menu-top > li ul.mega-sub-menu li.mega-menu-item:hover a,header .menu-sticky #mega-menu-top > li ul.mega-sub-menu li.mega-menu-item:hover i,header .menu-sticky #mega-menu-top > li ul.mega-sub-menu li.mega-menu-item:hover svg,header .menu-sticky .navbar ul li .sub-menu li:hover a,header .menu-sticky .navbar ul li .sub-menu li:hover i,header .menu-sticky .navbar ul li .sub-menu li.current-menu-parent:hover a, header .menu-sticky .navbar ul li .sub-menu li.current-menu-parent .sub-menu li:hover a, header .menu-sticky .navbar ul li .sub-menu li.current-menu-parent:hover .sub-menu li:hover a,header .menu-sticky .navbar ul li .sub-menu li.current-menu-parent:hover i, header .menu-sticky .navbar ul li .sub-menu li.current-menu-parent .sub-menu li:hover i, header .menu-sticky .navbar ul li .sub-menu li.current-menu-parent:hover .sub-menu li:hover i,header .menu-sticky .navbar ul li .sub-menu li:hover .sub-menu li:hover a,header .menu-sticky .navbar ul li .sub-menu li:hover .sub-menu li:hover i{
                color : ' . $xamin_option['sticky_xamin_header_submenu_hover_color'] . ' !important;
            }';
			}

			if (isset($xamin_option['sticky_xamin_header_submenu_background_color']) && !empty($xamin_option['sticky_xamin_header_submenu_background_color'])) {
				$inline_css .= 'header .menu-sticky #mega-menu-top > li ul.mega-sub-menu li.mega-menu-item a,header .menu-sticky #mega-menu-top > li ul.mega-sub-menu li.mega-menu-item i,header .menu-sticky #mega-menu-top > li ul.mega-sub-menu li.mega-menu-item svg,header .menu-sticky .navbar ul li .sub-menu li a,header .menu-sticky .navbar ul li .sub-menu li.current-menu-parent li a,header .menu-sticky .navbar ul li .sub-menu li.current-menu-parent:hover .sub-menu li a,header .menu-sticky .navbar ul li .sub-menu li:hover .sub-menu li a,header .menu-sticky .navbar ul li .sub-menu li:hover .sub-menu li a {
                background : ' . $xamin_option['sticky_xamin_header_submenu_background_color'] . ' !important;
            }';
			}

			if (isset($xamin_option['sticky_header_submenu_background_hover_color']) && !empty($xamin_option['sticky_header_submenu_background_hover_color'])) {
				$inline_css .= 'header .menu-sticky #mega-menu-top > li ul.mega-sub-menu li.mega-menu-item:hover a,header .menu-sticky #mega-menu-top > li ul.mega-sub-menu li.mega-menu-item:hover i,header .menu-sticky #mega-menu-top > li ul.mega-sub-menu li.mega-menu-item:hover svg,header .menu-sticky .navbar ul li .sub-menu li:hover a,header .menu-sticky .navbar ul li .sub-menu li.current-menu-parent:hover a,header .menu-sticky .navbar ul li .sub-menu li.current-menu-parent .sub-menu li:hover a,header .menu-sticky .navbar ul li .sub-menu li.current-menu-parent:hover .sub-menu li:hover a,header .menu-sticky .navbar ul li .sub-menu li:hover .sub-menu li:hover a{
                background : ' . $xamin_option['sticky_header_submenu_background_hover_color'] . ' !important;
            }';
			}

			if (isset($xamin_option['sticky_header_submenu_background_active_color']) && !empty($xamin_option['sticky_header_submenu_background_active_color'])) {
				$inline_css .= 'header .menu-sticky #mega-menu-top > li ul.mega-sub-menu li.mega-current-menu-item a,header .menu-sticky #mega-menu-top > li ul.mega-sub-menu li.mega-current-menu-item svg,header .menu-sticky #mega-menu-top > li ul.mega-sub-menu li.mega-current-menu-item i,header .menu-sticky .navbar ul li .sub-menu li.current-menu-item a,header .menu-sticky .navbar ul li .sub-menu li.current-menu-parent a,header .menu-sticky .navbar ul li .sub-menu li.current-menu-parent .sub-menu li.current-menu-item  a {
                background : ' . $xamin_option['sticky_header_submenu_background_active_color'] . ' !important;
            }';
			}
		}
		if (!empty($inline_css)) {
			wp_add_inline_style('xamin-global', $inline_css);
		}
	}
}
