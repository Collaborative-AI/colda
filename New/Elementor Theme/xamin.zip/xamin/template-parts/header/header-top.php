<?php

/**
 * Template part for displaying the header navigation menu
 *
 * @package xamin
 */

namespace Xamin\Xamin;

$xamin_options = get_option('xamin_options');
$xamin_container = '';
if (class_exists('ReduxFramework')) {
    if (isset($xamin_options['header_container']) && $xamin_options['header_container'] == 'container') {
        $xamin_container = 'container';
    } else {
        $xamin_container = 'container-fluid';
    }
} else {
    $xamin_container = 'container';
}
?>
<div class="sub-header">
    <div class="<?php echo esc_attr($xamin_container); ?>">
        <div class="row">
            <div class="col-auto">
                <?php
                if (!empty($xamin_options['header_display_contact'])) {
                    $options = $xamin_options['header_display_contact'];
                    if ($options == "yes") {
                ?>
                        <div class="number-info">
                            <ul class="list-inline">
                                <?php
                                if (!empty($xamin_options['header_email'])) {
                                ?>
                                    <li class="list-inline-item"><a href="mailto:<?php echo esc_url($xamin_options['header_email']); ?>">
                                            <i class="fa fa-envelope"></i><?php echo esc_html($xamin_options['header_email']); ?></a></li>
                                <?php } ?>
                                <?php if (!empty($xamin_options['header_phone'])) {
                                ?>
                                    <li class="list-inline-item"><a href="tel:<?php echo str_replace(str_split('(),-" '), '', $xamin_options['header_phone']); ?>">
                                            <i class="fa fa-phone"></i><?php echo esc_html($xamin_options['header_phone']); ?></a></li>
                                <?php } ?>
                                <?php if (!empty($xamin_options['header_address'])) {
                                ?>
                                    <li class="list-inline-item"><a>
                                            <i class="fas fa-map-marker-alt"></i><?php echo esc_html($xamin_options['header_address']); ?></a></li>
                                <?php } ?>
                            </ul>
                        </div>

                <?php
                    }
                }
                ?>
            </div>
            <div class="col-auto col-auto ml-auto sub-main">
                <?php
                if (isset($xamin_options['xamin_header_social_media'])) {
                    $options = $xamin_options['xamin_header_social_media'];
                    if ($options == "yes") { ?>
                        <div class="social-icone">
                            <?php $data = $xamin_options['social-media-iq']; ?>
                            <ul class="list-inline">
                                <?php
                                foreach ($data as $key => $options) {
                                    if ($options) {
                                        echo '<li class="d-inline"><a href="' . esc_url($options) . '"><i class="fab fa-' . $key . '"></i></a></li>';
                                    }
                                } ?>
                            </ul>
                        </div>
                <?php
                    }
                }
                ?>
            </div>
        </div>
    </div>
</div>