<?php

/**
 * Xamin\Xamin\Dynamic_Style\Styles\Banner class
 *
 * @package xamin
 */

namespace Xamin\Xamin\Dynamic_Style\Styles;

use Xamin\Xamin\Dynamic_Style\Component;
use function add_action;

class Banner extends Component
{

    public function __construct()
    {
        add_action('wp_enqueue_scripts', array($this, 'xamin_banner_dynamic_style'), 20);
        add_action('wp_enqueue_scripts', array($this, 'xamin_opacity_color'), 20);
        add_action('wp_enqueue_scripts', array($this, 'xamin_featured_hide'), 20);
    }

    public function xamin_banner_dynamic_style()
    {
        $page_id = get_queried_object_id();
        $xamin_option = get_option('xamin_options');
        $dynamic_css = "";

        if (function_exists('get_field') && get_field('field_QnF1', $page_id) != 'default') {
            if (get_field('field_QnF1', $page_id) == 'no') {
                $dynamic_css .= '.iq-breadcrumb-one{
                    display:none !important;
                }';
                $dynamic_css .= '.content-area .site-main{
                    padding:0 !important;
                }';
            }
        } else if (isset($xamin_option['display_banner'])) {

            if ($xamin_option['display_banner'] == 'no') {
                $dynamic_css .= '.iq-breadcrumb-one{
                    display:none !important;
                }';
                $dynamic_css .= '.content-area .site-main{
                    padding:0 !important;
                }';
            }
        }


        $key = function_exists('get_field') ? get_field('key_pjros', $page_id) : '';
        if (!empty($key) && $key['display_title'] != 'default'  && $key['display_title'] == 'no') {
            $dynamic_css .= '.iq-breadcrumb-one .title{
                display:none !important;
            }';
        } else if (isset($xamin_option['display_title'])) {

            if ($xamin_option['display_title'] == 'no') {
                $dynamic_css .= '.iq-breadcrumb-one .title{
                    display:none !important;
                }';
            }
        }


        if (!empty($key) && $key['display_breadcumb'] != 'default'  && $key['display_breadcumb'] == 'no') {
            $dynamic_css .= '.iq-breadcrumb-one .breadcrumb{
                display:none !important;
            }';
        } else if (isset($xamin_option['display_breadcumb'])) {

            if ($xamin_option['display_breadcumb'] == 'no') {
                $dynamic_css .= '.iq-breadcrumb-one .breadcrumb{
                    display:none !important;
                }';
            }
        }

        if (isset($xamin_option['bg_title_color'])) {

            if ($xamin_option['bg_title_color'] == 'no') {
                $dynamic_css .= '.iq-breadcrumb-one .title{
                    color:' . $xamin_option['bg_title_color'] . '!important
                }';
            }
        }


        if (function_exists('get_field')) {
            $key =  get_field('key_banner_back', $page_id);
            if ($key['banner_background_type'] != 'default') {
                if ($key['banner_background_type'] == 'color') {
                    $dynamic_css .= '.iq-breadcrumb-one{
                        background:' . $key['banner_background_color'] . '!important
                    }';
                }

                if ($key['banner_background_type'] == 'image') {
                    $dynamic_css .= '.iq-breadcrumb-one{
                        background:url(' . $key['banner_background_image']['url'] . ') !important
                    }';

                    if (!empty($key['banner_background_size'])) {
                        $dynamic_css .= '.iq-breadcrumb-one{
                            background-size:' . $key['banner_background_size'] . '!important
                        }';
                    }

                    if (!empty($key['banner_background_repeat'])) {
                        $dynamic_css .= '.iq-breadcrumb-one{
                            background-repeat:' . $key['banner_background_repeat'] . '!important
                        }';
                    }
                }
            }
        } else if (isset($xamin_option['bg_type'])) {
            $opt = $xamin_option['bg_type'];
            if ($opt == '1') {
                if (isset($xamin_option['bg_color'])) {
                    $dynamic_css .= '.iq-breadcrumb-one{
                        background:' . $xamin_option['bg_color'] . '!important
                    }';
                }
            }
            if ($opt == '2') {
                if (isset($xamin_option['banner_image']['url'])) {
                    $dynamic_css .= '.iq-breadcrumb-one{
                        background:url(' . $xamin_option['banner_image']['url'] . ') !important
                    }';
                }
            }
        }



        wp_add_inline_style('xamin-global', $dynamic_css);
    }
    public function xamin_opacity_color()
    {
        //Set Background Opacity Color
        $xamin_options = get_option('xamin_options');

        if (!empty($xamin_options['bg_opacity']) && $xamin_options['bg_opacity'] == "3") {
            $bg_opacity = $xamin_options['opacity_color']['rgba'];
        }
        $dynamic_css = '';

        if (!empty($xamin_options['bg_opacity']) && $xamin_options['bg_opacity'] == "3") {
            if (!empty($bg_opacity) && $bg_opacity != '#ffffff') {
                $dynamic_css .= "
            .breadcrumb-video::before,.breadcrumb-bg::before, .breadcrumb-ui::before {
                background : $bg_opacity !important;
            }";
            }
        }
        wp_add_inline_style('xamin-global', $dynamic_css);
    }
    /* hide featured image for post formate */
    public function xamin_featured_hide()
    {
        /*
        * Get Post Formate and set featured image display none
        */
        $xamin_options = get_option('xamin-options');
        $featured_hide = '';
        $post_format = "";

        if (isset($xamin_options['posts_select'])) {

            $posts_format = $xamin_options['posts_select'];
            $post_format = get_post_format();

            if (in_array(get_post_format(), $posts_format)) {
                $featured_hide .= '.format-' . $post_format . ' .xamin-blog-box .xamin-blog-image img { display: none !important; }';
            }
            wp_add_inline_style('xamin-global', $featured_hide);
        }
    }
}
