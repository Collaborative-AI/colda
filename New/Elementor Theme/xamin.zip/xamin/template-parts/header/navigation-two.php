<?php

/**
 * Template part for displaying the header navigation menu
 *
 * @package xamin
 */

namespace Xamin\Xamin;

$xamin_options = get_option('xamin_options');
?>

<nav id="site-navigation" class="navbar xamin-default navbar-expand-xl navbar-light p-0" aria-label="<?php esc_html_e('Main menu', 'xamin'); ?>" <?php
																																	if (xamin()->is_amp()) {
																																	?> [class]=" siteNavigationMenu.expanded ? 'main-navigation nav--toggle-sub nav--toggle-small nav--toggled-on' : 'main-navigation nav--toggle-sub nav--toggle-small' " <?php
																																																																										}
																																																																											?>>

	<?php
	if ($xamin_options['header_radio'] == 1) {
	?>
		<a href="<?php echo esc_url(home_url('/')); ?>">
			<?php
			if (!empty($xamin_options['header_text'])) {
			?>
				<h1 class="logo-text"><?php echo esc_html($xamin_options['header_text']); ?></h1>
			<?php
			}
			?>
		</a>
	<?php
	} else {
	?>
		<a class="navbar-brand" href="<?php echo esc_url(home_url('/')); ?>">
			<?php
			if (function_exists('get_field') && class_exists('ReduxFramework')) {
				$key = get_field('key_header');



				if (!empty($key['header_logo']['url'])) {
					$logo = $key['header_logo']['url'];
				} else if (isset($xamin_options['xamin_logo']['url'])) {
					$logo = $xamin_options['xamin_logo']['url'];
				}
			?>
				<img class="img-fluid logo" src="<?php echo esc_url($logo); ?>" alt="<?php esc_attr_e('xamin', 'xamin'); ?>">
			<?php
			} else {
			?>
				<img class="img-fluid logo" src="<?php echo esc_url(get_template_directory_uri()); ?>/assets/images/redux/logo.png" alt="<?php esc_attr_e('xamin', 'xamin'); ?>">
			<?php } ?>
		</a>
	<?php
	}

    if (xamin()->is_primary_nav_menu_active()) {  	?>
		<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
		    <span class="navbar-toggler-icon navbar-icon-container"><span class="navbar-icon"></span></span>
		</button>
		<?php
	} 
	?>

	<div id="navbarSupportedContent" class="collapse navbar-collapse new-collapse">
		<?php
		if (xamin()->is_primary_nav_menu_active()) {
			xamin()->display_primary_nav_menu(array('menu_id' => 'top-menu', 'menu_class' => 'navbar-nav m-auto', 'container_id' => 'iq-menu-container',));
		}
		?>
		
	</div>
	<?php if (class_exists('ReduxFramework')) { ?>
		<div class="sub-main">
			<ul class="shop_list">
				<!-- wishlist -->
				<?php
				if (class_exists('WooCommerce')) {
				?>
					<?php
					if (function_exists('YITH_WCWL') && isset($xamin_options['header_display_shop']) && $xamin_options['header_display_shop'] == 'yes') {
						$wish_url = '';
						if (isset($xamin_options['wishlist_link']) && !empty($xamin_options['wishlist_link'])) {
							$wish_url = get_page_link($xamin_options['wishlist_link']);
						}
					?>
						<li class="wishlist-btn">
							<div class="wishlist_count">
								<?php $wishlist_count = YITH_WCWL()->count_products(); ?>
								<a href="<?php echo esc_url($wish_url); ?>">
									<i class="fa fa-heart"></i>
									<span class="wcount"><?php echo esc_html($wishlist_count); ?></span>
								</a>
							</div>
						</li>
					<?php } ?>
					<!-- mini cart -->
					<?php
					if (isset($xamin_options['header_display_shop'])) {
						$options = $xamin_options['header_display_shop'];
						if ($options == "yes") { ?>
							<li class="cart-btn">
								<div class="cart_count">
									<a class="parents mini-cart-count" href="<?php echo esc_url(wc_get_cart_url()); ?>">
										<i class="fa fa-shopping-cart"></i>
										<span id="mini-cart-count"><?php echo wp_kses_post(WC()->cart->get_cart_contents_count()); ?></span>
									</a>
								</div>
							</li>

				<?php
						}
					}
				} ?>

				<!-- search -->
				<?php
				if (isset($xamin_options['header_display_search'])) {
					$options = $xamin_options['header_display_search'];
					if ($options == "yes") {
				?>
						<li class="search-btn">
							<a href="javascript:void(0);" id="btn-search-popup"><i class="fa fa-search" aria-hidden="true"></i></a>
							<div class="search custom-serach">	
								<button id="btn-search-popup-close" class="btn btn--search-close" aria-label="Close search form">
                        			<i class="ion-close-round" aria-hidden="true"></i>
                      			</button>						
								<?php get_search_form(); ?>
							</div>
						</li>
				<?php
					}
				}
				?>
				<li>
					<nav aria-label="breadcrumb">
						<?php if ((!empty($xamin_options['xamin_download_link'])) && (!empty($xamin_options['xamin_download_title']))) {
							$dlink = $xamin_options['xamin_download_link'];
							$dtitle = $xamin_options['xamin_download_title'];
						?>
							<div class="button-started xamin-btn-container">
								<a class="xamin-button" href="<?php echo esc_url($dlink); ?>">
									<span class="btn_text"><?php echo esc_html($dtitle, 'xamin'); ?></span><i class="fas fa-angle-double-right"></i>
								</a>
							</div>
						<?php } ?>
						<!-- side area btn container start-->
						<div class="iq-sidearea-btn-container" id="menu-btn-side-open">
							<span class="menu-btn d-inline-block">
								<span class="line one"></span>
								<span class="line two"></span>
								<span class="line three"></span>
							</span>
						</div>
						<!-- side area btn container end-->
					</nav>
				</li>
			</ul>
		</div>
	<?php } ?>

</nav><!-- #site-navigation -->