"""
__version__.py
~~~~~~~~~~~~~~

Information about the current version of the py-package-template package.
"""

__title__ = 'colda'
__description__ = 'colda_Package for easy use'
__version__ = '0.0.0'
__author__ = 'Jie Ding Group'
__author_email__ = 'dingj@umn.edu'
__license__ = 'Apache 2.0'
__url__ = 'None'
