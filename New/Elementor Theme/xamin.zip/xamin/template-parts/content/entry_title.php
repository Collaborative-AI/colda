<?php
/**
 * Template part for displaying a post's title
 *
 * @package xamin
 */

namespace Xamin\Xamin;

if ( is_singular( get_post_type() ) ) {
} else {
	the_title( '<div class="blog-title"><a href="' . esc_url( get_permalink() ) . '" ><h4 class="entry-title" rel="bookmark">', '</h4></a></div>' );
}
