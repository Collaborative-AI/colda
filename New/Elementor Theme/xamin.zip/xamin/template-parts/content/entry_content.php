<?php
/**
 * Template part for displaying a post's content
 *
 * @package xamin
 */

namespace Xamin\Xamin;

?>

<div class="xamin-blog-wapper">
	<?php
	if (is_single()) {
		the_content();
	} else {
		the_excerpt();
	}
	?>
</div><!-- .entry-content -->
