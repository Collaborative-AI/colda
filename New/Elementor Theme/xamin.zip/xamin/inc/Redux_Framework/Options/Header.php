<?php

/**
 * Xamin\Xamin\Redux_Framework\Options\General class
 *
 * @package xamin
 */

namespace Xamin\Xamin\Redux_Framework\Options;

use Redux;
use Xamin\Xamin\Redux_Framework\Component;

class Header extends Component
{

	public function __construct()
	{
		$this->set_widget_option();
	}

	protected function set_widget_option()
	{
		Redux::set_section($this->opt_name, array(
			'title' => esc_html__('Header', 'xamin'),
			'id'    => 'header-editor',
			'icon'  => 'el el-arrow-up',
			'customizer_width' => '500px',
		));

		
		Redux::set_section($this->opt_name, array(
			'title' => esc_html__('Menu Layout', 'xamin'),
			'id'    => 'header-variation',
			'subsection' => true,
			'desc'  => esc_html__('This section contains options for Menu .', 'xamin'),
			'fields' => array(

				array(
					'id' => 'header_layout',
					'type' => 'button_set',
					'title' => esc_html__('Header', 'xamin'),
					'options' => array(
						'default' => esc_html__('Default', 'xamin'),
						'custom' => esc_html__('Custom', 'xamin'),
					),
					'default' => 'default'
				),

				array(
					'id'        => 'menu_style',
					'type'      => 'select',
					'title' 	=> esc_html__('Header Layout', 'xamin'),
					'subtitle' 	=> esc_html__('Select the layout variation that you want to use for header layout.', 'xamin'),
					'options'	=> (function_exists('iqonic_addons_get_list_layouts')) ? iqonic_addons_get_list_layouts(false, 'header') : '',
					'required' 	=> array('header_layout', '=', 'custom'),
				),

				array(
					'id'      => 'xamin_header_variation',
					'type'    => 'image_select',
					'title'   => esc_html__('Menu Style', 'xamin'),
					'subtitle' => esc_html__('Select the design variation that you want to use for site menu.', 'xamin'),
					'required' 	=> array('header_layout', '=', 'default'),
					'options' => array(
						'1'      => array(
							'alt' => 'Style1',
							'img' => get_template_directory_uri() . '/assets/images/redux/header-1.jpg',
						),
						'2'      => array(
							'alt' => 'Style2',
							'img' => get_template_directory_uri() . '/assets/images/redux/header-2.jpg',
						),
						'3'      => array(
							'alt' => 'Style3',
							'img' => get_template_directory_uri() . '/assets/images/redux/header-3.jpg',
						),
					),
					'default' => '1'
				),

				array(
					'id'        => 'xamin_vertical_hedader_collapsed',
					'type'      => 'button_set',
					'title'     => esc_html__('Header Expanded / Collapsed', 'xamin'),
					'subtitle'  => esc_html__('Select expanded / collapsed vertical header', 'xamin'),
					'required'  => array('xamin_header_variation', '=', '3'),
					'options'   => array(
						'expanded' => esc_html__('Expanded', 'xamin'),
						'collapsed' => esc_html__('Collapsed', 'xamin'),
					),
					'default'   => esc_html__('expanded', 'xamin')
				),

				array(
					'id' => 'header_container',
					'type' => 'button_set',
					'title' => esc_html__('Header container', 'xamin'),
					'options' => array(
						'container-fluid' => esc_html__('full width', 'xamin'),
						'container' => esc_html__('Container', 'xamin'),
					),
					'required' 	=> array('header_layout', '=', 'default'),
					'default' => esc_html__('container', 'xamin')
				),
				
				// --------main header background options start----------//

				array(
					'id'   => 'vertical_expanded_trans_info',
					'type' => 'info',
					'title' =>  esc_html__('Transparent background is not applicable with "Expanded" vertical menu type.', 'xamin'),
					'style' => 'info',
					'required'  => array(
						array('xamin_header_variation', '=', '3'),
						array('xamin_header_background_type', '=', 'transparent'),
						array('xamin_vertical_hedader_collapsed', '=', 'expanded'),
						array('header_layout', '=', 'default'),
					),
				),

				array(
					'id'        => 'xamin_header_background_type',
					'type'      => 'button_set',
					'title'     => esc_html__('Background', 'xamin'),
					'subtitle'  => esc_html__('Select the variation for header background', 'xamin'),
					'options'   => array(
						'default' => esc_html__('Default', 'xamin'),
						'color' => esc_html__('Color', 'xamin'),
						'image' => esc_html__('Image', 'xamin'),
						'transparent' => esc_html__('Transparent', 'xamin')
					),
					'required' 	=> array('header_layout', '=', 'default'),
					'default'   => esc_html__('default', 'xamin')
				),

				array(
					'id'            => 'xamin_header_background_color',
					'type'          => 'color',
					'desc'     		=> esc_html__('Set Background Color', 'xamin'),
					'required'  	=> array('xamin_header_background_type', '=', 'color'),
					'mode'          => 'background',
					'transparent'   => false
				),

				array(
					'id'       => 'xamin_header_background_image',
					'type'     => 'media',
					'url'      => false,
					'desc'     => esc_html__('Upload Image', 'xamin'),
					'required'  => array('xamin_header_background_type', '=', 'image'),
					'read-only' => false,
					'default'  => array( 'url' => get_template_directory_uri() .'/assets/images/redux/logo.png' ),
					'subtitle' => esc_html__('Upload background image for header.', 'xamin'),
				),

				// --------main header Background options end----------//

				// --------main header Menu options start----------//
				array(
					'id'        => 'header_menu_color_type',
					'type'      => 'button_set',
					'title'     => esc_html__('Menu Color Options', 'xamin'),
					'subtitle' => esc_html__('Select Menu color .', 'xamin'),
					'options'   => array(
						'default' => esc_html__('Default', 'xamin'),
						'custom' => esc_html__('Custom', 'xamin'),
					),
					'required' 	=> array('header_layout', '=', 'default'),
					'default'   => esc_html__('default', 'xamin')
				),
				array(
					'id'            => 'xamin_header_menu_color',
					'type'          => 'color',
					'required'  => array('header_menu_color_type', '=', 'custom'),
					'desc'     => esc_html__('Menu Color', 'xamin'),
					'mode'          => 'background',
					'transparent'   => false
				),

				array(
					'id'            => 'xamin_header_menu_active_color',
					'type'          => 'color',
					'required'  	=> array('header_menu_color_type', '=', 'custom'),
					'desc'     		=> esc_html__('Active Menu Color', 'xamin'),
					'mode'          => 'background',
					'transparent'   => false
				),

				array(
					'id'            => 'xamin_header_menu_hover_color',
					'type'          => 'color',
					'required'  	=> array('header_menu_color_type', '=', 'custom'),
					'desc'     		=> esc_html__('Menu Hover Color', 'xamin'),
					'mode'          => 'background',
					'transparent'   => false
				),

				array(
					'id'            => 'xamin_vertical_header_active_background_color',
					'type'          => 'color',
					'required'  	=> array(
						array('xamin_header_variation', '=', '3'),
						array('header_menu_color_type', '=', 'custom'),
					),
					'desc'     => esc_html__('Active menu background color', 'xamin'),
					'mode'          => 'background',
					'transparent'   => false
				),

				//----sub menu options start---//
				array(
					'id'        => 'header_submenu_color_type',
					'type'      => 'button_set',
					'title'     => esc_html__('Submenu Color Options', 'xamin'),
					'subtitle'  => esc_html__('Select submenu color.', 'xamin'),
					'options'   => array(
						'default' => esc_html__('Default', 'xamin'),
						'custom'  => esc_html__('Custom', 'xamin'),
					),
					'required' 	=> array('header_layout', '=', 'default'),
					'default'     => esc_html__('default', 'xamin')
				),

				array(
					'id'            => 'xamin_header_submenu_color',
					'type'          => 'color',
					'desc'     		=> esc_html__('Submenu Color', 'xamin'),
					'required'  	=> array('header_submenu_color_type', '=', 'custom'),
					'mode'          => 'background',
					'transparent'   => false
				),

				array(
					'id'            => 'xamin_header_submenu_active_color',
					'type'          => 'color',
					'desc'     		=> esc_html__('Active Submenu Color', 'xamin'),
					'required'  	=> array('header_submenu_color_type', '=', 'custom'),
					'mode'          => 'background',
					'transparent'   => false
				),

				array(
					'id'            => 'xamin_header_submenu_hover_color',
					'type'          => 'color',
					'desc'     		=> esc_html__('Submenu Hover Color', 'xamin'),
					'required'  	=> array('header_submenu_color_type', '=', 'custom'),
					'mode'          => 'background',
					'transparent'   => false
				),

				array(
					'id'            => 'xamin_header_submenu_background_color',
					'type'          => 'color',
					'desc'     		=> esc_html__('Submenu Background Color', 'xamin'),
					'required'  	=> array(
						array('xamin_header_variation', '!=', '3'),
						array('header_submenu_color_type', '=', 'custom'),
					),
					'mode'          => 'background',
					'transparent'   => false
				),

				array(
					'id'            => 'header_submenu_background_active_color',
					'type'          => 'color',
					'desc'     		=> esc_html__('Submenu Background Active Color', 'xamin'),
					'required'  	=> array(
						array('xamin_header_variation', '!=', '3'),
						array('header_submenu_color_type', '=', 'custom'),
					),
					'mode'          => 'background',
					'transparent'   => false
				),

				array(
					'id'            => 'header_submenu_background_hover_color',
					'type'          => 'color',
					'desc'     		=> esc_html__('Submenu Background Hover Color', 'xamin'),
					'required'  	=> array(
						array('xamin_header_variation', '!=', '3'),
						array('header_submenu_color_type', '=', 'custom'),
					),
					'mode'          => 'background',
					'transparent'   => false
				),
				//----sub menu options end----//

				//----vertical menu wave effect and submenu vertical line color options start----//
				array(
					'id'            => 'xamin_vertical_menu_wave_effect_color',
					'type'          => 'color',
					'title'    		=> esc_html__('Click effect color', 'xamin'),
					'subtitle'    	=> esc_html__('Choose on click effect color for vertical menu', 'xamin'),
					'desc'     		=> esc_html__('Vertical menu click effect color', 'xamin'),
					'required'  	=> array('xamin_header_variation', '=', '3'),
					'mode'          => 'background',
					'transparent'   => false
				),
				array(
					'id'            => 'xamin_vertical_submenu_line__color',
					'type'          => 'color',
					'title'    		=> esc_html__('Submenu line color', 'xamin'),
					'subtitle'    	=> esc_html__('Choose color for submenu vertical line.', 'xamin'),
					'desc'     		=> esc_html__('Submenu vertical line color', 'xamin'),
					'required'  	=> array('xamin_header_variation', '=', '3'),
					'mode'          => 'background',
					'transparent'   => false
				),
				//----vertical menu wave effect and submenu horizontal line color options end----//

				// --------main header Menu options end----------//

				// --------main header responsive Menu Button Options start----------//
				array(
					'id'        => 'responsive_menu_button_type',
					'type'      => 'button_set',
					'title'     => esc_html__('Responsive Menu Color', 'xamin'),
					'required'  => array(
						array('xamin_header_variation', '!=', '3'),
						array('header_layout', '=', 'default')
					),
					'subtitle' 	=> esc_html__('Select menu color for responsive mode.', 'xamin'),
					'options'   => array(
						'default' => esc_html__('Default', 'xamin'),
						'custom' => esc_html__('Custom', 'xamin')
					),
					'default'   => esc_html__('default', 'xamin')
				),

				array(
					'id'            => 'responsive_menu_button_background_color',
					'type'          => 'color',
					'desc'     		=> esc_html__('Toggle button background color', 'xamin'),
					'required'  	=> array('responsive_menu_button_type', '=', 'custom'),
					'mode'          => 'background',
					'required' 		=> array('header_layout', '=', 'default'),
					'transparent'   => false
				),

				array(
					'id'            => 'responsive_menu_color',
					'type'          => 'color',
					'desc'     		=> esc_html__('Responsive menu color', 'xamin'),
					'required'  	=> array('responsive_menu_button_type', '=', 'custom'),
					'mode'          => 'background',
					'transparent'   => false
				),

				array(
					'id'            => 'responsive_menu_hover_color',
					'type'          => 'color',
					'desc'     		=> esc_html__('Responsive menu hover color', 'xamin'),
					'required'  	=> array('responsive_menu_button_type', '=', 'custom'),
					'mode'          => 'background',
					'transparent'   => false
				),

				array(
					'id'            => 'responsive_menu_background_color',
					'type'          => 'color',
					'desc'     		=> esc_html__('Responsive menu background color', 'xamin'),
					'required'  	=> array('responsive_menu_button_type', '=', 'custom'),
					'mode'          => 'background',
					'transparent'   => false
				),

				array(
					'id'            => 'responsive_menu_active_background_color',
					'type'          => 'color',
					'desc'     		=> esc_html__('Responsive menu active background color', 'xamin'),
					'required'  	=> array('responsive_menu_button_type', '=', 'custom'),
					'mode'          => 'background',
					'transparent'   => false
				),
				// --------main header responsive Menu Button Options end----------//

				// --------main header Login/CTA Button and shop Options start----------//
				array(
					'id'        => 'header_display_button',
					'type'      => 'button_set',
					'title'     => esc_html__('Login/CTA Button', 'xamin'),
					'subtitle' 	=> esc_html__('Turn on to display the Login and CTA button in header.', 'xamin'),
					'options'   => array(
						'yes' 	=> esc_html__('On', 'xamin'),
						'no' 	=> esc_html__('Off', 'xamin')
					),
					'required' 		=> array('header_layout', '=', 'default'),
					'default'   => esc_html__('no', 'xamin')
				),

				array(
					'id'        => 'xamin_download_title',
					'type'      => 'text',
					//'title'     => esc_html__( 'Title(Download)','xamin'),
					'required'  => array('header_display_button', '=', 'yes'),
					'default'   => 'Get Started',
					'desc'   	=> esc_html__('Change Title (e.g.Download).', 'xamin'),
				),
				array(
					'id'        => 'xamin_download_link',
					'type'      => 'text',
					//'title'     => esc_html__( 'Link(Download)','xamin'),
					'required'  => array('header_display_button', '=', 'yes'),
					'desc'   	=> esc_html__('Add download link.', 'xamin'),
				),

				array(
					'id'        => 'header_button_color_type',
					'type'      => 'button_set',
					'required'  => array('header_display_button', '=', 'yes'),
					'desc' 		=> esc_html__('Select for button color options.', 'xamin'),
					'options'   => array(
						'default' => esc_html__('Default', 'xamin'),
						'custom' => esc_html__('Custom', 'xamin')
					),
					'default'   => esc_html__('default', 'xamin')
				),

				array(
					'id'            => 'xamin_download_btn_background',
					'type'          => 'color',
					'desc'     		=> esc_html__('Button background color', 'xamin'),
					'required'  	=> array('header_button_color_type', '=', 'custom'),
					'mode'          => 'background',
					'transparent'   => false
				),

				array(
					'id'            => 'xamin_download_btn_background_hover',
					'type'          => 'color',
					'desc'     		=> esc_html__('Button background hover color', 'xamin'),
					'required'  	=> array('header_button_color_type', '=', 'custom'),
					'mode'          => 'background',
					'transparent'   => false
				),

				array(
					'id'            => 'xamin_download_btn_text',
					'type'          => 'color',
					'desc'     		=> esc_html__('Button text color', 'xamin'),
					'required'  	=> array('header_button_color_type', '=', 'custom'),
					'mode'          => 'background',
					'transparent'   => false
				),

				array(
					'id'            => 'xamin_download_btn_text_hover',
					'type'          => 'color',
					'desc'     		=> esc_html__('Button text hover Color', 'xamin'),
					'required'  	=> array('header_button_color_type', '=', 'custom'),
					'mode'          => 'background',
					'transparent'   => false
				),

				array(
					'id'        => 'header_display_search',
					'type'      => 'button_set',
					'title'     => esc_html__('Search Button', 'xamin'),
					'subtitle' 	=> esc_html__('Turn on to display Search Button in header.', 'xamin'),
					'options'   => array(
						'yes' 	=> esc_html__('Yes', 'xamin'),
						'no' 	=> esc_html__('No', 'xamin')
					),
					'required' 		=> array('header_layout', '=', 'default'),
					'default'   => esc_html__('no', 'xamin')
				),

				array(
					'id'        => 'header_display_shop',
					'type'      => 'button_set',
					'title'     => esc_html__('Shop & Wishlist Button', 'xamin'),
					'subtitle' 	=> esc_html__('Turn on to display Shop & Wishlist Button in header.', 'xamin'),
					'options'   => array(
						'yes' 	=> esc_html__('Yes', 'xamin'),
						'no' 	=> esc_html__('No', 'xamin')
					),
					'required' 		=> array('header_layout', '=', 'default'),
					'default'   => esc_html__('no', 'xamin')
				),

				array(
					'id'       => 'wishlist_link',
					'type'     => 'select',
					'multi'    => false,
					'data'     => 'pages',
					'required' => array('header_display_shop', '=', 'yes'),
					'title'    => esc_html__('Choose Wishlist Page', 'xamin'),
					'subtitle' => esc_html__('Select Page that you want to display wishlist items', 'xamin'),
				),
				// --------main header Login/CTA Button and shop Options end----------//
			)
		));

		Redux::set_section($this->opt_name, array(
			'title' => esc_html__('Header Top', 'xamin'),
			'id'    => 'Header_Contact',
			'subsection' => true,
			'desc'  => esc_html__('', 'xamin'),
			'fields'  => array(
				array(
					'id'    => 'info_custom_header_top_options',
					'type'  => 'info',
					'required' 	=> array('header_layout', '=', 'custom'),
					'title' => __('Note:', 'xamin'),
					'style' => 'warning',
					'desc'  => __('This options only works with Default Header Layout', 'xamin')
				),

				array(
					'id'   => 'vertical_header_top_info',
					'type' => 'info',
					'title' =>  esc_html__('Opps ! Not Available...', 'xamin') . '</br>' .
						esc_html__(' This options only available with standard menu type.', 'xamin') . '</br>' .
						esc_html__('We will come back soon with this options in vertical menu.', 'xamin'),
					'style' => 'critical',
					'required'  => array(
						array('xamin_header_variation', '=', '3'),
						array('header_layout', '=', 'default')
					)
				),

				array(
					'id'        => 'email_and_button',
					'type'      => 'button_set',
					'title'     => esc_html__('Display Header Top', 'xamin'),
					'subtitle' => esc_html__('Turn on to display top header Email, Phone, Social Media.', 'xamin'),
					'required'  => array(
						array('xamin_header_variation', '!=', '3'),
						array('header_layout', '=', 'default')
					),
					'options'   => array(
						'yes' => esc_html__('On', 'xamin'),
						'no' => esc_html__('Off', 'xamin')
					),
					'default'   => esc_html__('no', 'xamin')
				),
				// --------header top background options start----------//
				array(
					'id'        => 'header_top_background_type',
					'type'      => 'button_set',
					'title'     => esc_html__('Background', 'xamin'),
					'required'  => array( 
						array('email_and_button', '=', 'yes'),
						array('header_layout', '=', 'default')
					),
					'options'   => array(
						'default' => esc_html__('Default', 'xamin'),
						'color' => esc_html__('Color', 'xamin'),
						'image' => esc_html__('Image', 'xamin'),
						'transparent' => esc_html__('Transparent', 'xamin')
					),
					'default'   => esc_html__('default', 'xamin')
				),

				array(
					'id'            => 'header_top_background_color',
					'type'          => 'color',
					'desc'     => esc_html__('Set Background Color', 'xamin'),
					'required'  => array(
						array('header_top_background_type', '=', 'color'),
						array('header_layout', '=', 'default')
					),
					'mode'          => 'background',
					'transparent'   => false
				),

				array(
					'id'       => 'header_top_background_image',
					'type'     => 'media',
					'url'      => false,
					'desc'     => esc_html__('Upload Image', 'xamin'),
					'required'  => array(
						array('header_top_background_type', '=', 'image'),
						array('header_layout', '=', 'default')
					),
					'read-only' => false,
					'default'  => array( 'url' => get_template_directory_uri() .'/assets/images/redux/logo.png' ),
					'subtitle' => esc_html__('Upload background image for top header.', 'xamin'),
				),

				// --------header top background options end----------//
				// --------header top Text color options start----------//
				array(
					'id'        => 'header_top_text_color_type',
					'type'      => 'button_set',
					'required'  => array(
						array('email_and_button', '=', 'yes'),
						array('header_layout', '=', 'default')
					),
					'title'     => esc_html__('Text / Icon color options', 'xamin'),
					'subtitle' => esc_html__('Select text / icon color for normal and hover .', 'xamin'),
					'options'   => array(
						'default' => esc_html__('Default', 'xamin'),
						'custom' => esc_html__('Custom', 'xamin'),
					),
					'default'   => esc_html__('default', 'xamin')
				),
				array(
					'id'            => 'header_top_text_color',
					'type'          => 'color',
					'desc'      => esc_html__('Choose text color for top header.', 'xamin'),
					'required'  => array(
						array('header_top_text_color_type', '=', 'custom'),
						array('header_layout', '=', 'default')
					),
					'mode'          => 'background',
					'transparent'   => false
				),

				array(
					'id'            => 'header_top_text_hover_color',
					'type'          => 'color',
					'desc'      	=> esc_html__('Choose text hover color for top header.', 'xamin'),
					'required'  	=> array(
						array('header_top_text_color_type', '=', 'custom'),
						array('header_layout', '=', 'default')
					),
					'mode'          => 'background',
					'transparent'   => false
				),

				array(
					'id'            => 'header_top_icon_color',
					'type'          => 'color',
					'desc'          => esc_html__('Choose Social Icon color for top header.', 'xamin'),
					'required'      => array(
						array('header_top_text_color_type', '=', 'custom'),
						array('header_layout', '=', 'default')
					),
					'mode'          => 'background',
					'transparent'   => false
				),

				array(
					'id'            => 'header_top_icon_hover_color',
					'type'          => 'color',
					'desc'          => esc_html__('Choose Social Icon hover color for top header.', 'xamin'),
					'required'      => array(
						array('header_top_text_color_type', '=', 'custom'),
						array('header_layout', '=', 'default')
					),
					'mode'          => 'background',
					'transparent'   => false
				),
				// --------header top Text color options end----------//
				array(
					'id'       => 'header_phone',
					'type'     => 'text',
					'title'    => esc_html__('Phone', 'xamin'),
					'required'  => array( 
						array('email_and_button', '=', 'yes'),
						array('header_layout', '=', 'default')
					),
					'preg' => array(
						'pattern' => '/[^0-9_ -+()]/s',
						'replacement' => ''
					),
					'default'  => esc_html__('+0123456789', 'xamin'),
				),

				array(
					'id'       => 'header_email',
					'type'     => 'text',
					'title'    => esc_html__('Email', 'xamin'),
					'required'  => array(
						array('email_and_button', '=', 'yes'),
						array('header_layout', '=', 'default')
					),
					'validate' => 'email',
					'msg'      => esc_html__('custom error message', 'xamin'),
					'default'  => esc_html__('support@example.com', 'xamin'),
				),

				array(
					'id'       => 'header_address',
					'type'     => 'textarea',
					'title'    => esc_html__('Address', 'xamin'),
					'required'  => array(
						array('email_and_button', '=', 'yes'),
						array('header_layout', '=', 'default')
					),
					'default'  => esc_html__('1234 North Avenue Luke Lane, South Bend, IN 360001', 'xamin'),
				),

				array(
					'id'        => 'header_display_contact',
					'type'      => 'button_set',
					'title'     => esc_html__('Email/Phone on Header', 'xamin'),
					'required'  => array(
						array('email_and_button', '=', 'yes'),
						array('header_layout', '=', 'default')
					),
					'subtitle' => esc_html__('Turn on to display the Email and Phone number in header menu.', 'xamin'),
					'options'   => array(
						'yes' => esc_html__('On', 'xamin'),
						'no' => esc_html__('Off', 'xamin')
					),
					'default'   => esc_html__('yes', 'xamin')
				),

				array(
					'id'        => 'xamin_header_social_media',
					'type'      => 'button_set',
					'title'     => esc_html__('Social Media', 'xamin'),
					'desc'      => esc_html__('[ Add Social media Links from options ]', 'xamin'),
					'subtitle'  => esc_html__('Turn on to display Social Media in top header.', 'xamin'),
					'required'  => array(
						array('email_and_button', '=', 'yes'),
						array('header_layout', '=', 'default')
					),
					'options'   => array(
						'yes'   => esc_html__('Yes', 'xamin'),
						'no'    => esc_html__('No', 'xamin')
					),
					'default'   => esc_html__('yes', 'xamin')
				),

			)

		));
		//-----Sticky Header Options Start---//
		Redux::set_section($this->opt_name, array(
			'title' => esc_html__('Sticky Header', 'xamin'),
			'id' => 'sticky-header-variation',
			'subsection' => true,
			'desc' => esc_html__('This section contains options for sticky header menu and background color.', 'xamin'),
			'fields' => array(

				array(
					'id'    => 'info_custom_header_sitcky_options',
					'type'  => 'info',
					'required' 	=> array('header_layout', '=', 'custom'),
					'title' => __('Note:', 'xamin'),
					'style' => 'warning',
					'desc'  => __('This options only works with Default Header Layout', 'xamin')
				),
				array(
					'id'   => 'vertical_header_sticky_info',
					'type' => 'info',
					'title' =>  esc_html__('Opps ! Not Available...', 'xamin') . '</br>' .
						esc_html__(' This options only available with standard menu type.', 'xamin') . '</br>' .
						esc_html__('We will come back soon with this options in vertical menu.', 'xamin'),
					'style' => 'critical',
					'required'  => array('xamin_header_variation', '=', '3'),
				),

				array(
					'id'        => 'sticky_header_display',
					'type'      => 'button_set',
					'title'     => esc_html__('Sticky Header', 'xamin'),
					'subtitle' => esc_html__('Turn on to display sticky header.', 'xamin'),
					'required'  => array('xamin_header_variation', '!=', '3'),
					'options'   => array(
						'yes' => esc_html__('On', 'xamin'),
						'no' => esc_html__('Off', 'xamin')
					),
					'default'   => esc_html__('yes', 'xamin')
				),
				// --------sticky header background options start----------//
				array(
					'id'        => 'sticky_header_background_type',
					'type'      => 'button_set',
					'required'  => array('sticky_header_display', '=', 'yes'),
					'title'     => esc_html__('Background', 'xamin'),
					'subtitle'  => esc_html__('Select the variation for sticky header background', 'xamin'),
					'options'   => array(
						'default' => esc_html__('Default', 'xamin'),
						'color' => esc_html__('Color', 'xamin'),
						'image' => esc_html__('Image', 'xamin'),
						'transparent' => esc_html__('Transparent', 'xamin')
					),
					'default'   => esc_html__('default', 'xamin')
				),

				array(
					'id'            => 'sticky_header_background_color',
					'type'          => 'color',
					'desc'     => esc_html__('Set Background Color', 'xamin'),
					'required'  => array('sticky_header_background_type', '=', 'color'),
					'mode'          => 'background',
					'transparent'   => false
				),

				array(
					'id'       => 'sticky_header_background_image',
					'type'     => 'media',
					'url'      => false,
					'desc'     => esc_html__('Upload Image', 'xamin'),
					'required'  => array('sticky_header_background_type', '=', 'image'),
					'read-only' => false,
					'default'  => array( 'url' => get_template_directory_uri() .'/assets/images/redux/logo.png' ),
					'subtitle' => esc_html__('Upload background image for sticky header.', 'xamin'),
				),
				// --------sticky header Background options end----------//

				// --------sticky header Menu options start----------//

				array(
					'id'        => 'sticky_menu_color_type',
					'type'      => 'button_set',
					'required'  => array('sticky_header_display', '=', 'yes'),
					'title'     => esc_html__('Menu Color Options', 'xamin'),
					'subtitle' => esc_html__('Select Menu color for sticky.', 'xamin'),
					'options'   => array(
						'default' => esc_html__('Default', 'xamin'),
						'custom' => esc_html__('Custom', 'xamin'),
					),
					'default'   => esc_html__('default', 'xamin')
				),
				array(
					'id'            => 'sticky_menu_color',
					'type'          => 'color',
					'required'  => array('sticky_menu_color_type', '=', 'custom'),
					'desc'     => esc_html__('Sticky header menu color', 'xamin'),
					'mode'          => 'background',
					'transparent'   => false
				),

				array(
					'id'            => 'sticky_menu_active_color',
					'type'          => 'color',
					'required'  => array('sticky_menu_color_type', '=', 'custom'),
					'desc'     => esc_html__('Sticky header active menu color', 'xamin'),
					'mode'          => 'background',
					'transparent'   => false
				),

				array(
					'id'            => 'sticky_menu_hover_color',
					'type'          => 'color',
					'required'  => array('sticky_menu_color_type', '=', 'custom'),
					'desc'     => esc_html__('Sticky header menu hover color', 'xamin'),
					'mode'          => 'background',
					'transparent'   => false
				),

				//----sticky sub menu options start---//
				array(
					'id'        => 'sticky_header_submenu_color_type',
					'type'      => 'button_set',
					'title'     => esc_html__('Submenu Color Options', 'xamin'),
					'subtitle' => esc_html__('Select submenu color.', 'xamin'),
					'required'  => array('sticky_header_display', '=', 'yes'),
					'options'   => array(
						'default' => esc_html__('Default', 'xamin'),
						'custom' => esc_html__('Custom', 'xamin'),
					),
					'default'   => esc_html__('default', 'xamin')
				),

				array(
					'id'            => 'sticky_xamin_header_submenu_color',
					'type'          => 'color',
					'desc'     => esc_html__('Submenu Color', 'xamin'),
					'required'  => array('sticky_header_submenu_color_type', '=', 'custom'),
					'mode'          => 'background',
					'transparent'   => false
				),

				array(
					'id'            => 'sticky_xamin_header_submenu_active_color',
					'type'          => 'color',
					'desc'     => esc_html__('Active Submenu Color', 'xamin'),
					'required'  => array('sticky_header_submenu_color_type', '=', 'custom'),
					'mode'          => 'background',
					'transparent'   => false
				),

				array(
					'id'            => 'sticky_xamin_header_submenu_hover_color',
					'type'          => 'color',
					'desc'     => esc_html__('Submenu Hover Color', 'xamin'),
					'required'  => array('sticky_header_submenu_color_type', '=', 'custom'),
					'mode'          => 'background',
					'transparent'   => false
				),

				array(
					'id'            => 'sticky_xamin_header_submenu_background_color',
					'type'          => 'color',
					'desc'     => esc_html__('Submenu Background Color', 'xamin'),
					'required'  => array('sticky_header_submenu_color_type', '=', 'custom'),
					'mode'          => 'background',
					'transparent'   => false
				),
				array(
					'id'            => 'sticky_header_submenu_background_active_color',
					'type'          => 'color',
					'desc'     => esc_html__('Submenu Background Active Color', 'xamin'),
					'required'  => array('sticky_header_submenu_color_type', '=', 'custom'),
					'mode'          => 'background',
					'transparent'   => false
				),

				array(
					'id'            => 'sticky_header_submenu_background_hover_color',
					'type'          => 'color',
					'desc'     => esc_html__('Submenu Background Hover Color', 'xamin'),
					'required'  => array('sticky_header_submenu_color_type', '=', 'custom'),
					'mode'          => 'background',
					'transparent'   => false
				),
				// --------sticky header Menu options start----------//
			)
		));
		//-----Sticky Header Options Options End---//

		//-----Side Area Options Start---//
		Redux::set_section($this->opt_name, array(
			'title' => esc_html__('Side Area', 'xamin'),
			'id' => 'header-side-area-variation',

			'subsection' => true,
			'desc' => esc_html__('This section contains options for side area button in header.', 'xamin'),
			'fields' => array(

				array(
					'id'        => 'header_display_side_area',
					'type'      => 'button_set',
					'title'     => esc_html__('Side Area (Sliding Panel)', 'xamin'),
					'subtitle' => esc_html__('Set option for Sliding right side panel.', 'xamin'),
					'options'   => array(
						'yes' => esc_html__('On', 'xamin'),
						'no' => esc_html__('Off', 'xamin')
					),
					'default'   => esc_html__('yes', 'xamin')
				),

				// --------side area background options start----------//
				array(
					'id'        => 'sidearea_background_type',
					'type'      => 'button_set',
					'required'  => array('header_display_side_area', '=', 'yes'),
					'title'     => esc_html__('Background', 'xamin'),
					'subtitle'  => esc_html__('Select the variation for Sidearea background', 'xamin'),
					'options'   => array(
						'default' => esc_html__('Default', 'xamin'),
						'color' => esc_html__('Color', 'xamin'),
						'image' => esc_html__('Image', 'xamin'),
						'transparent' => esc_html__('Transparent', 'xamin')
					),
					'default'   => esc_html__('default', 'xamin')
				),

				array(
					'id'            => 'sidearea_background_color',
					'type'          => 'color',
					'desc'     => esc_html__('Set Background Color', 'xamin'),
					'required'  => array('sidearea_background_type', '=', 'color'),
					'mode'          => 'background',
					'transparent'   => false
				),

				array(
					'id'       => 'sidearea_background_image',
					'type'     => 'media',
					'url'      => false,
					'desc'     => esc_html__('Upload Image', 'xamin'),
					'required'  => array('sidearea_background_type', '=', 'image'),
					'read-only' => false,
					'default'  => array( 'url' => get_template_directory_uri() .'/assets/images/logo.png' ),
					'subtitle' => esc_html__('Upload background image for sidearea.', 'xamin'),
				),
				// --------side area Background options end----------//
				array(
					'id' => 'sidearea_width',
					'type' => 'dimensions',
					'height' => false,
					'units'    => array('em', 'px', '%'),
					'title' => esc_html__('Adjust sidearea width', 'xamin'),
					'subtitle' => esc_html__('Choose Width, and/or unit.', 'xamin'),
					'desc' => esc_html__('Sidearea Width.', 'xamin'),
					'required'  => array('header_display_side_area', '=', 'yes'),
				),

				// --------side area button color options ----------//
				array(
					'id'        => 'sidearea_btn_color_type',
					'type'      => 'button_set',
					'required'  => array('header_display_side_area', '=', 'yes'),
					'title'     => esc_html__('Button color options', 'xamin'),
					'subtitle' => esc_html__('Select text normal / hover color .', 'xamin'),
					'options'   => array(
						'default' => esc_html__('Default', 'xamin'),
						'custom' => esc_html__('Custom', 'xamin'),
					),
					'default'   => esc_html__('default', 'xamin')
				),

				array(
					'id'            => 'sidearea_btn_open_color',
					'type'          => 'color',
					'title' => esc_html__('Open button color', 'xamin'),
					'subtitle' => esc_html__('Select color for normal / hover.', 'xamin'),
					'desc'     => esc_html__('Set open button color', 'xamin'),
					'required'  => array('sidearea_btn_color_type', '=', 'custom'),
					'mode'          => 'background',
					'transparent'   => false
				),
				array(
					'id'            => 'sidearea_btn_open_hover',
					'type'          => 'color',
					'desc'     => esc_html__('Set open button hover color', 'xamin'),
					'required'  => array('sidearea_btn_color_type', '=', 'custom'),
					'mode'          => 'background',
					'transparent'   => false
				),

				array(
					'id'            => 'sidearea_btn_line_color',
					'type'          => 'color',
					'title' => esc_html__('Open button line color', 'xamin'),
					'subtitle' => esc_html__('Select normal / hover color of open button lines.', 'xamin'),
					'desc'     => esc_html__('Set open button line color', 'xamin'),
					'required'  => array('sidearea_btn_color_type', '=', 'custom'),
					'mode'          => 'background',
					'transparent'   => false
				),
				array(
					'id'            => 'sidearea_btn_line_hover_color',
					'type'          => 'color',
					'desc'     => esc_html__('Set open button line hover color', 'xamin'),
					'required'  => array('sidearea_btn_color_type', '=', 'custom'),
					'mode'          => 'background',
					'transparent'   => false
				),

				array(
					'id'            => 'sidearea_btn_close_color',
					'type'          => 'color',
					'title' => esc_html__('Close button color', 'xamin'),
					'subtitle' => esc_html__('Select normal / hover color of close button inside sidearea.', 'xamin'),
					'desc'     => esc_html__('Set close button color', 'xamin'),
					'required'  => array('sidearea_btn_color_type', '=', 'custom'),
					'mode'          => 'background',
					'transparent'   => false
				),
				array(
					'id'            => 'sidearea_btn_close_hover',
					'type'          => 'color',
					'desc'     => esc_html__('Set close button hover color', 'xamin'),
					'required'  => array('sidearea_btn_color_type', '=', 'custom'),
					'mode'          => 'background',
					'transparent'   => false
				),

				array(
					'id'            => 'sidearea_btn_close_line_color',
					'type'          => 'color',
					'title' => esc_html__('Close button line color', 'xamin'),
					'subtitle' => esc_html__('Select normal / hover color of close button lines.', 'xamin'),
					'desc'     => esc_html__('Set open button line color', 'xamin'),
					'required'  => array('sidearea_btn_color_type', '=', 'custom'),
					'mode'          => 'background',
					'transparent'   => false
				),
				array(
					'id'            => 'sidearea_btn_close_line_hover_color',
					'type'          => 'color',
					'desc'     => esc_html__('Set close button line hover color', 'xamin'),
					'required'  => array('sidearea_btn_color_type', '=', 'custom'),
					'mode'          => 'background',
					'transparent'   => false
				),
			)
		));
	}
}
