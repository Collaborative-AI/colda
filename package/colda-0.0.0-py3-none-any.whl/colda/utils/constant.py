from __future__ import annotations

from typing import (
    Final
)

from typeguard import typechecked


#@typechecked
class Constant:

    INITIAL_DEFAULT_MODE: Final[str] = 'auto'
    MAXIMUM_ROUND: Final[int] = 3
    