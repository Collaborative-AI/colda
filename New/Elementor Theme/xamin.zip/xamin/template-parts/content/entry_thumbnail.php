<?php

/**
 * Template part for displaying a post's featured image
 *
 * @package xamin
 */

namespace Xamin\Xamin;

// Audio or video attachments can have featured images, so they need to be specifically checked.
$support_slug = get_post_type();
if ('attachment' === $support_slug) {
	if (wp_attachment_is('audio')) {
		$support_slug .= ':audio';
	} elseif (wp_attachment_is('video')) {
		$support_slug .= ':video';
	}
}

if (post_password_required() || !post_type_supports($support_slug, 'thumbnail')) {
	return;
}
?>
<div class="xamin-blog-image">
	<?php
	$category_class = '';
	if (is_singular(get_post_type())) {
	?>
		<?php
		if (has_post_thumbnail()) {
			$category_class = 'category-tag';
		?>
			<?php the_post_thumbnail('', array('class' => 'skip-lazy')); ?>
		<?php } ?>
		<?php
	} else {
		if (class_exists('ReduxFramework')) {
			$xamin_option = get_option('xamin_options');
			if ($xamin_option['xamin_display_image'] == 'yes') { ?>
				<?php
				if ('video' === get_post_format() || 'audio' === get_post_format()) {
					$category_class = 'category-tag';
					echo xamin()->xamin_get_embed_video(get_the_ID());
				} elseif ('gallery' === get_post_format()) {
					$category_class = 'category-tag';
					echo get_post_gallery();
				} else {
				?>
					<?php
					if (has_post_thumbnail()) {
						$category_class = 'category-tag';
					?>
						<a class="post-thumbnail" href="<?php the_permalink(); ?>" aria-hidden="true">
							<?php
							global $wp_query;
							if (0 === $wp_query->current_post) {
								the_post_thumbnail(
									'post-thumbnail',
									array(
										'class' => 'skip-lazy',
										'alt'   => the_title_attribute(
											array(
												'echo' => false,
											)
										),
									)
								);
							} else {
								the_post_thumbnail(
									'post-thumbnail',
									array(
										'alt' => the_title_attribute(
											array(
												'echo' => false,
											)
										),
									)
								);
							}
							?>
						</a><!-- .post-thumbnail -->
					<?php } ?>
				<?php } ?>

			<?php }
		} else {
			?>
			<?php
			if ('video' === get_post_format() || 'audio' === get_post_format()) {
				$category_class = 'category-tag';
				echo xamin()->xamin_get_embed_video(get_the_ID());
			} elseif ('gallery' === get_post_format()) {
				$category_class = 'category-tag';
				echo get_post_gallery();
			} else {
			?>
				<?php
				if (has_post_thumbnail()) {
					$category_class = 'category-tag';
				?>
					<a class="post-thumbnail" href="<?php the_permalink(); ?>" aria-hidden="true">
						<?php
						global $wp_query;
						if (0 === $wp_query->current_post) {
							the_post_thumbnail(
								'post-thumbnail',
								array(
									'class' => 'skip-lazy',
									'alt'   => the_title_attribute(
										array(
											'echo' => false,
										)
									),
								)
							);
						} else {
							the_post_thumbnail(
								'post-thumbnail',
								array(
									'alt' => the_title_attribute(
										array(
											'echo' => false,
										)
									),
								)
							);
						}
						?>
					</a><!-- .post-thumbnail -->

				<?php } ?>
			<?php } ?>
		<?php
		}
	}

	$postcat = get_the_category();
	if ($postcat) {
		?>
		<div class="xamin-blog-meta <?php echo esc_attr($category_class); ?>">
			<ul class="list-inline">
				<?php
				foreach ($postcat as $cat) { ?>
					<li class="posted-category"><a href="<?php echo esc_url(get_category_link($cat->cat_ID)); ?>"><?php echo esc_html($cat->name); ?></a></li>
				<?php } ?>
			</ul>
		</div>
	<?php
	}
	?>
</div>