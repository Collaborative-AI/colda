<?php

/**
 * Xamin\Xamin\Dynamic_Style\Styles\Footer class
 *
 * @package xamin
 */

namespace Xamin\Xamin\Dynamic_Style\Styles;

use Xamin\Xamin\Dynamic_Style\Component;
use function add_action;

class Footer extends Component
{

	public function __construct()
	{
		add_action('wp_enqueue_scripts', array($this, 'xamin_footer_dynamic_style'), 20);
	}

	public function xamin_footer_dynamic_style()
	{

		$page_id = get_queried_object_id();
		$xamin_option = get_option('xamin_options');
		$footer_css = '';


		if (function_exists('get_field') && get_field('acf_key_footer_switch', $page_id) != 'default') {
			if (get_field('acf_key_footer_switch') == 'no') {
				$footer_css .= '.footer-top{
					display:none !important;
				}';
			}
		} else if (isset($xamin_option['xamin_footer_top'])) {
			if ($xamin_option['xamin_footer_top'] == 'no') {
				$footer_css .= '.footer-top{
					display:none !important;
				}';
			}
		}

		if (function_exists('get_field')) {
			if (get_field('field_footer_bg_color') && !empty(get_field('field_footer_bg_color'))) {
				$footer_bg_color = get_field('field_footer_bg_color');
				$footer_css .= ".footer {
						background-color: $footer_bg_color !important;
					}";
			} else if (isset($xamin_option['change_footer_color'])) {

				if ($xamin_option['change_footer_color'] == '0') {
					$footer_bg_color = $xamin_option['footer_color'];
					$footer_css .= ".footer {
						background-color: $footer_bg_color !important;
					}";
				}
			}
		}

		if ($xamin_option['change_footer_color'] == '0') {
			$footer_bg_color = $xamin_option['footer_text_color'];
			$footer_css .= "
			footer .footer-top .widget ul.menu li a, 
			footer .footer-top .widget_iq_contact .widget ul.iq-contact li a span, 
			footer .footer-top .menu-service-menu-container li:before, 
			footer .footer-top .widget_iq_contact ul.iq-contact li svg, 
			footer .footer-top .textwidget,
			footer .footer-top .widget p,
			footer .footer-top .widget ul li a {
				color: $footer_bg_color !important;
			}";
		}

		if ($xamin_option['change_footer_color'] == '0') {
			$footer_bg_color = $xamin_option['footer_title_color'];
			$footer_css .= "
			footer .footer-top .widget .footer-title, footer .footer-top .widget h4 {				
				color: $footer_bg_color !important; 
			}";
		}


		if (isset($xamin_option['display_copyright'])) {

			
			$footer_copyrightbg_color = $xamin_option['footer_copyright_bgcolor'];
			$footer_copyright_color = $xamin_option['footer_copyright_color'];
			

			if (function_exists('get_field') && get_field('display_footer')=='yes' && get_field('footer_layout_switch') == 'default' && get_field('acf_footer_copyright') == 'yes') {
				if (!empty(get_field('copyright_bg_color'))) {
					$footer_copyrightbg_color = get_field('copyright_bg_color');
				}
				if (!empty(get_field('copyright_color'))) {
					$footer_copyright_color = get_field('copyright_color');
				}
			}

			if ($xamin_option['display_copyright'] == 'yes') {

				$footer_css .= "
					footer.footer-one .copyright-footer ,body.iq-dark-mode footer.footer-one .copyright-footer{				
						background-color: $footer_copyrightbg_color ; 
						color: $footer_copyright_color ; 
					}";
			}
		}

		wp_add_inline_style('xamin-global', $footer_css);
	}
}
