<?php

/**
 * Xamin\Xamin\Dynamic_Style\Styles\HeaderTop class
 *
 * @package xamin
 */

namespace Xamin\Xamin\Dynamic_Style\Styles;

use Xamin\Xamin\Dynamic_Style\Component;
use function add_action;

class HeaderTop extends Component
{
	public function __construct()
	{
		add_action('wp_enqueue_scripts', array($this, 'xamin_header_top_background_style'), 20);
		add_action('wp_enqueue_scripts', array($this, 'xamin_top_text_color_options'), 20);
	}

	public function xamin_header_top_background_style()
	{
		$xamin_option = get_option('xamin_options');
		$inline_css = '';

		if (isset($xamin_option['header_top_background_type']) && $xamin_option['header_top_background_type'] != 'default') {
			$type = $xamin_option['header_top_background_type'];
			if ($type == 'color') {
				if (!empty($xamin_option['header_top_background_color'])) {
					$inline_css = 'header .sub-header{
						background: ' . $xamin_option['header_top_background_color'] . ' !important
					}';
				}
			}
			if ($type == 'image') {
				if (!empty($xamin_option['header_top_background_image']['url'])) {
					$inline_css = 'header .sub-header{
						background: url(' . $xamin_option['header_top_background_image']['url'] . ') !important
					}';
				}
			}
			if ($type == 'transparent') {
				$inline_css = 'header .sub-header{
					background: transparent !important
				}';
			}
		}

		if (!empty($inline_css)) {
			wp_add_inline_style('xamin-global', $inline_css);
		}
	}

	public function xamin_top_text_color_options()
	{
		$xamin_option = get_option('xamin_options');
		$inline_css = '';
		if (isset($xamin_option['header_top_text_color_type']) && $xamin_option['header_top_text_color_type'] != 'default') {
			if (isset($xamin_option['header_top_text_color']) && !empty($xamin_option['header_top_text_color'])) {

				$inline_css .= 'header.style-one .sub-header .number-info li a,header .sub-header  li a,header.style-one .sub-header .number-info li a i,header.style-one .sub-header .number-info li a svg{
                color : ' . $xamin_option['header_top_text_color'] . '!important;
            }';
			}
			if (isset($xamin_option['header_top_text_hover_color']) && !empty($xamin_option['header_top_text_hover_color'])) {
				$inline_css .= ' header.style-one .sub-header .number-info li:hover a,header .sub-header  li:hover a,header.style-one .sub-header .number-info li:hover a i,header.style-one .sub-header .number-info li:hover a svg{
                color : ' . $xamin_option['header_top_text_hover_color'] . '!important;
            }';
			}
			if (isset($xamin_option['header_top_icon_color']) && !empty($xamin_option['header_top_icon_color'])) {
				$inline_css .= 'header.style-one .sub-header .social-icone ul li i,header.style-one .sub-header .social-icone ul li svg{
                color : ' . $xamin_option['header_top_icon_color'] . '!important;
            }';
			}
			if (isset($xamin_option['header_top_icon_hover_color']) && !empty($xamin_option['header_top_icon_hover_color'])) {
				$inline_css .= 'header.style-one .sub-header .social-icone ul li:hover i,header.style-one .sub-header .social-icone ul li:hover svg{
                color : ' . $xamin_option['header_top_icon_hover_color'] . '!important;
            }';
			}
		}

		if (!empty($inline_css)) {
			wp_add_inline_style('xamin-global', $inline_css);
		}
	}
}
