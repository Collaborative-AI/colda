import pytest

from .__init__ import Regression_1s_1a
