<?php

/**
 * Template part for displaying the header navigation menu
 *
 * @package xamin
 */

namespace Xamin\Xamin;

$xamin_options = get_option('xamin_options');
?>
<nav class="navbar navbar-expand-lg navbar-light">
	<div class="iq-vertical-header-logo">
		<?php
		if (isset($xamin_options['vertical_header_radio']) && $xamin_options['vertical_header_radio'] == 1) {
		?>
			<a href="<?php echo esc_url(home_url('/')); ?>">
				<?php
				if (!empty($xamin_options['vertical_header_text'])) {
				?>
					<h1 class="logo-text"><?php echo esc_html($xamin_options['vertical_header_text']); ?></h1>
				<?php
				}
				?>
			</a>
		<?php
		} else {
		?>
			<a class="navbar-brand" href="<?php echo esc_url(home_url('/')); ?>">
				<?php
				if (function_exists('get_field') && class_exists('ReduxFramework')) {
					$key = get_field('key_header');
					if (function_exists('get_field') && class_exists('ReduxFramework')) {
						if (isset($key['header_ver_logo']['url']) && !empty($key['header_ver_logo']['url'])) {
							$logo = $key['header_ver_logo']['url'];
						} else if (isset($xamin_options['xamin_vertical_logo']['url']) && !empty($xamin_options['xamin_vertical_logo']['url'])) {
							$logo = $xamin_options['xamin_vertical_logo']['url'];
						}
				?>
						<img class="img-fluid logo" src="<?php echo esc_url($logo); ?>" alt="<?php esc_attr_e('xamin', 'xamin'); ?>">
					<?php
					}
				} else {
					?>
					<img class="img-fluid logo" src="<?php echo esc_url(get_template_directory_uri()); ?>/assets/images/redux/logo.png" alt="<?php esc_attr_e('xamin', 'xamin'); ?>">
				<?php } ?>
			</a>
		<?php
		}
		?>
		<!-- vertical menu btn container start-->
		<div class="iq-vertical-btn-container btn-vertical-close" id="vertical-menu-btn-close">
			<span class="vertical-menu-btn">
				<!-- <i class="fa fa-list-ul" aria-hidden="true"></i> -->
				<span class="menu-btn d-inline-block">
					<span class="line one"></span>
					<span class="line two"></span>
					<span class="line three"></span>
				</span>
			</span>
		</div>
		<!-- vertical menu btn container end-->
	</div>
	<div class="vertical" id="menu-sidebar-scrollbar">
		<?php if (has_nav_menu('vertical')) : ?>
			<?php wp_nav_menu(array(
				'theme_location' => 'vertical',
				'menu_class'     => 'navbar-nav ml-auto',
				'menu_id'        => 'vertical-menu',
				'container_id'   => 'iq-menu-container',
			)); ?>
		<?php endif; ?>
	</div>
</nav><!-- #site-navigation -->