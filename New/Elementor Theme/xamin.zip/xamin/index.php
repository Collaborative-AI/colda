<?php

/**
 * The main template file
 *
 * This is the most generic template file in a WordPress theme
 * and one of the two required files for a theme (the other being style.css).
 * It is used to display a page when nothing more specific matches a query.
 * E.g., it puts together the home page when no home.php file exists.
 *
 * @link https://codex.wordpress.org/Template_Hierarchy
 *
 * @package xamin
 */

namespace Xamin\Xamin;

$xamin_options = get_option('xamin_options');
$is_sidebar = xamin()->is_primary_sidebar_active();
$post_section = xamin()->post_style();
$options_blog = '';
if (isset($xamin_options['xamin_blog'])) {
	$options_blog = $xamin_options['xamin_blog'];
}
$blog_styles = '';
if (isset($xamin_options['xamin_deafult_blog_styles']) && $xamin_options['xamin_deafult_blog_styles'] != 'default') {
	$blog_styles = $xamin_options['xamin_deafult_blog_styles'];
	if ($options_blog > 3) {
		$blog_styles = $xamin_options['xamin_deafult_blog_styles'] . '-grid';
	}
}

get_header();


?>
<div class="site-content-contain">
	<div id="content" class="site-content">
		<div id="primary" class="content-area">
			<main id="main" class="site-main">
				<div class="container">
					<div class="row <?php echo esc_attr($post_section['row_reverse']); ?>">
						<?php if ($is_sidebar && !is_archive()) {
							echo '<div class="col-xl-8 col-sm-12'.esc_attr($blog_styles).'">';
						}

						if (have_posts()) {
							if($options_blog == 3) {?>
								<div class="col-md-12 col-sm-12<?php echo  esc_attr($blog_styles); ?>">
							<?php }
							while (have_posts()) { ?>
								<?php the_post();

								if($options_blog == 4 && is_home()) { ?>
									<div class="col-lg-6 col-md-6 col-sm-6 xamin-space-bottom <?php echo  esc_attr($blog_styles); ?>"> 
								<?php } elseif($options_blog == 5 && is_home()) { ?>
									<div class="col-lg-4 col-md-6 xamin-space-bottom<?php echo  esc_attr($blog_styles); ?>"> 
								<?php }
							
								get_template_part('template-parts/content/entry', get_post_type(), $post_section['post']);
								
								if(($options_blog == 4 && is_home()) || ($options_blog == 5 && is_home())) {
									echo '</div>';
								}
								?>
						<?php }
							if($options_blog == 3) {
								echo '</div>';
							}
							if (!is_singular()) {
								if (isset($xamin_options['xamin_display_pagination'])) {
									$options = $xamin_options['xamin_display_pagination'];
									if ($options == "yes") {
										get_template_part('template-parts/content/pagination');
									}
								} else {
									get_template_part('template-parts/content/pagination');
								}
							}
						} else {
							get_template_part('template-parts/content/error');
						} 
						?></div>
						<?php if ($is_sidebar && !is_archive()) { 
							get_sidebar(); 
						}
						?>
					</div>
				</div>
			</main><!-- #primary -->
		</div>
	</div>
</div>
<?php
get_footer();
