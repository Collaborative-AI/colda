<!DOCTYPE html>
<html <?php language_attributes(); ?> class="no-js no-svg">

<head>
  <!-- Required meta tags -->
  <meta charset="<?php bloginfo('charset'); ?>">
  <meta name="viewport" content="width=device-width, initial-scale=1, minimum-scale=1">
  <?php $xamin_option = get_option('xamin_options'); ?>
  <?php
  if (!function_exists('has_site_icon') || !wp_site_icon()) {
    if (!empty($xamin_option['xamin_fevicon'])) { ?>
      <link rel="shortcut icon" href="<?php echo esc_url($xamin_option['xamin_fevicon']['url']); ?>" />
  <?php
    }
  }
  ?>
  <?php remove_action('wp_head', 'wp_generator');  ?>
  <?php wp_head(); ?>
</head>


<body data-spy="scroll" data-offset="80">
<?php wp_body_open(); ?>
  <div id="page" class="site">
    <a class="skip-link screen-reader-text" href="#content"><?php esc_html__('Skip to content', 'xamin'); ?></a>

    <div class="site-content-contain">
      <div id="content" class="site-content">