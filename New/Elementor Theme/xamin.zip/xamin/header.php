<?php

/**
 * The header for our theme
 *
 * This is the template that displays all of the <head> section and everything up until <div id="content">
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package xamin
 */

namespace Xamin\Xamin;

use Elementor\Plugin;

?>
<!doctype html>
<html <?php language_attributes(); ?> class="no-js">

<head>
  <meta charset="<?php bloginfo('charset'); ?>">
  <meta name="viewport" content="width=device-width, initial-scale=1, minimum-scale=1">
  <?php $xamin_option = get_option('xamin_options'); ?>
  <link rel="profile" href="<?php echo is_ssl() ? 'https:' : 'http:' ?>//gmpg.org/xfn/11">
  <?php
  if (!function_exists('has_site_icon') || !wp_site_icon()) {
    if (!empty($xamin_option['xamin_fevicon'])) { ?>
      <link rel="shortcut icon" href="<?php echo esc_url($xamin_option['xamin_fevicon']['url']); ?>" />
  <?php
    }
  }
  ?>
  <?php wp_head(); ?>

</head>
<?php
//--- class setting for vertical menu start---// 
$has_sticky = ' has-sticky';
if (class_exists('ReduxFramework')) {
  if (isset($xamin_option['sticky_header_display']) && $xamin_option['sticky_header_display'] == 'yes') {
    $has_sticky = ' has-sticky';
  } else {
    $has_sticky = '';
  }
}

//--- class setting for vertical menu start---// 
$default_site_content = '';
if (class_exists('ReduxFramework')) {
  $default_site_content = ' xamin';
  if ($xamin_option['layout_ui'] == 'yes') {
    $default_site_content .= ' xamin-old';
  }
}
?>
<!-- Smooth scroll -->
<?php
$fr = $at = $sz = $ad = $am = $bgurl = $site_classes =  $default_header_container = "";
if (class_exists('ReduxFramework') && isset($xamin_option['smoth_scroll']) && $xamin_option['smoth_scroll']) {
  $fr = $xamin_option['smooth_framerate'];
  $at = $xamin_option['smooth_animationTime'];
  $sz = $xamin_option['smooth_stepSize'];
  $ad = $xamin_option['smooth_accelarationDelta'];
  $am = $xamin_option['smooth_accelarationMax'];
}
?>

<body <?php body_class(); ?> data-fr="<?php echo esc_attr($fr); ?>" data-at="<?php echo esc_attr($at); ?>" data-sz="<?php echo esc_attr($sz); ?>" data-ad="<?php echo esc_attr($ad); ?>" data-am="<?php echo esc_attr($am); ?>">
  <?php wp_body_open(); ?>

  <?php
  if (class_exists('ReduxFramework')) {
  ?>
    <div id="has-side-bar" class="iq-menu-side-bar">
      <?php
      get_template_part('template-parts/header/header', 'sidearea');
      ?>
    </div>
  <?php }

  if (class_exists('ReduxFramework') && isset($xamin_option['xamin_display_loader'])) {
    $options = $xamin_option['xamin_display_loader'];

    if ($options == "yes") {
  ?>
      <!-- loading -->
      <div id="loading">
        <div id="loading-center">
          <?php
          if (!empty($xamin_option['xamin_loader_gif']['url'])) {
            $bgurl = $xamin_option['xamin_loader_gif']['url'];
          ?>
            <img src="<?php echo esc_url($bgurl); ?>" alt="<?php esc_html_e('loader', 'xamin'); ?>">
          <?php
          } else {
            $bgurl = get_template_directory_uri() . '/assets/images/redux/loader.gif';
          ?>
            <img src="<?php echo esc_url($bgurl); ?>" alt="<?php esc_html_e('loader', 'xamin'); ?>">
          <?php
          }
          ?>
        </div>
      </div>
      <!-- loading End -->
  <?php
    }
  } else { ?>
    <!-- loading -->
    <div id="loading">
      <div id="loading-center">
        <?php $bgurl = get_template_directory_uri() . '/assets/images/redux/loader.gif'; ?>
          <img src="<?php echo esc_url($bgurl); ?>" alt="<?php esc_html_e('loader', 'xamin'); ?>">
      </div>
    </div>
    <!-- loading End -->
    <?php
  }
  
  $is_default_header = true;
  $header_response = $site_classes = $xamin_header_class = '';

  if (function_exists('get_field') && class_exists('ReduxFramework')) {
    $id = (get_queried_object_id()) ? get_queried_object_id() : '';
    // ------------header
    if (class_exists("Elementor\Plugin")) {
      $header_display = !empty($id) ? get_post_meta($id, 'display_header', true) : '';
      $header_layout = !empty($id) ? get_post_meta($id, 'header_layout_type', true) : '';
      $header_name = !empty($id) ? get_post_meta($id, 'header_layout_name', true) : '';

      if ($header_display === 'yes' && $header_layout === 'custom' && !empty($header_name)) {
        $is_default_header = false;
        $header = $header_name;
        $has_sticky = '';
        $my_layout = get_page_by_path($header, '', 'iqonic_hf_layout');
        if ($my_layout) {
          $header_response =  Plugin::instance()->frontend->get_builder_content_for_display($my_layout->ID);
          wp_reset_postdata();
        }
      } else if ($header_layout == 'default' && $header_display != 'default') {
        $is_default_header = true;
      } else if (isset($xamin_option['header_layout']) && $xamin_option['header_layout'] == 'custom') {
        if (!empty($xamin_option['menu_style'])) {
          $is_default_header = false;
          $header = $xamin_option['menu_style'];
          $has_sticky = '';
          $my_layout = get_page_by_path($header, '', 'iqonic_hf_layout');
          if ($my_layout) {
            $header_response =  Plugin::instance()->frontend->get_builder_content_for_display($my_layout->ID);
            wp_reset_postdata();
          }
        }
      }
    }

    // ---------------header end
    $h_layout_position = !empty($id) ? get_post_meta($id, 'header_layout_position', true) : '';
    if ($header_display === 'yes' && $header_layout === 'custom' && $h_layout_position === 'vertical') {
      $site_classes .= ' vertical-header';
    } else {
      if (isset($xamin_option['header_layout_position']) && $xamin_option['header_layout_position'] == 'vertical') {
        $site_classes .= ' vertical-header';
      }
    }

    if (!strpos($site_classes, 'vertical-header')) {
      $h_position = !empty($id) ? get_post_meta($id, 'header_postion', true) : '';
      if ($h_position === 'over') {
        $site_classes .= ' header-over';
      } else {
        if (isset($xamin_option['header_postion']) && $xamin_option['header_postion'] == 'over') {
          $site_classes .= ' header-over';
        }
      }
    } else {
      add_filter('content_container_class', function ($container) {
        $container = 'container-fluid';
        return $container;
      });
    }
  }
  // Header Selection
  if (function_exists('get_field') && class_exists('ReduxFramework')) {
    $id = (get_queried_object_id()) ? get_queried_object_id() : '';
    $header_display = !empty($id) ? get_post_meta($id, 'display_header', true) : '';
    if( !empty($header_display) && $header_display != 'default'){
      if (get_field('header_layout_type', $id) === 'custom') {
        $xamin_header_class .= 'custom-header ';
      } else  {
        $xamin_header_class .= 'header-default ';
      } 
    } else {
        if (isset($xamin_option['header_layout']) && $xamin_option['header_layout'] == 'custom') {
          $xamin_header_class .= 'custom-header ';
        }  else {
          $xamin_header_class .= 'header-default ';
        }
      }
  } else {
    $xamin_header_class .= 'header-default ';
  }

  //--- class setting for vertical menu start ---// 
  $xamin_menu_style = function_exists('get_field') ? get_field('key_header') : '';

  $xamin_container = $xamin_header_type = $vertical_site_content = '';
  $xamin_header_id = 'default-header';
  if ($is_default_header || empty($header_response)) {

    if (isset($xamin_menu_style['header_variation']) || isset($xamin_option['xamin_header_variation'])) {
      // Switch For Advance Custom Field Options
      if ( function_exists('get_field') && get_field('display_header') != 'default') {
        switch ($xamin_menu_style['header_variation']) {
          case '3':
            $xamin_header_type = '3';
            $xamin_header_id = 'vertical-sidebar';
            $xamin_header_class .= 'style-vertical';
            $vertical_site_content = 'vertical-site-content';
            break;
          case '2':
            $xamin_header_type = '2';
            $xamin_header_class .= 'site-header style-two';
            break;
          case '1':
          case 'default':
            $xamin_header_id = 'main-header';
            $xamin_header_class .= 'site-header style-one';
            break;
        }
      } else {
        // Switch For Redux Options
        switch ($xamin_option['xamin_header_variation']) {
          case '3':
            $xamin_header_type = '3';
            $xamin_header_id = 'vertical-sidebar';
            $xamin_header_class .= 'style-vertical';
            $vertical_site_content = 'vertical-site-content';
            break;
          case '2':
            $xamin_header_type = '2';
            $xamin_header_class .= 'site-header style-two';
            break;
          case '1':
            $xamin_header_id = 'main-header';
            $xamin_header_class .= 'site-header style-one';
            break;
        }
      }
    }else{$xamin_header_class .= ' style-one';}
  }
  ?>
  <div id="page" class="site <?php echo esc_attr($vertical_site_content);
                              echo esc_attr($default_site_content); ?>">
    <a class="skip-link screen-reader-text" href="#primary"><?php esc_html_e('Skip to content', 'xamin'); ?></a>
    <?php
    $xamin_container = '';
    if (class_exists('ReduxFramework')) {
      if (isset($xamin_option['header_container']) && $xamin_option['header_container'] == 'container') {
        $xamin_container = 'container';
      } else {
        $xamin_container = 'container-fluid';
      }
    } else {
      $xamin_container = 'container';
    }
    ?>
    <header id="<?php echo esc_attr($xamin_header_id); ?>" class="<?php echo esc_attr($xamin_header_class); ?>">
      <?php
      if (!$is_default_header && !empty($header_response)) {
        echo function_exists('iqonic_return_elementor_res') ? iqonic_return_elementor_res($header_response) : $header_response;
      } else {
        $is_default_header = true;
      }
      if ($is_default_header && $xamin_header_type !== '3' && isset($xamin_option['email_and_button']) && $xamin_option['email_and_button'] == "yes") {
        get_template_part('template-parts/header/header', 'top');
      }
      if ($is_default_header && $xamin_header_type === '3') {
        get_template_part('template-parts/header/navigation', 'vertical');
      }
      ?>
      <?php if ($is_default_header && $xamin_header_type !== '3') { ?>
        <div class="main-header <?php echo esc_attr($has_sticky); ?>">
          <div class="<?php echo esc_attr($xamin_container); ?>">
            <div class="row">
              <div class="col-md-12">
                <?php
                if ($xamin_header_type === '2') {
                  get_template_part('template-parts/header/navigation', 'two');
                } else {
                  get_template_part('template-parts/header/navigation');
                } ?>
              </div>
            </div>
          </div>
        </div>
      <?php } ?>
    </header><!-- #masthead -->
    <?php if ($is_default_header && $xamin_header_type === '3') {
      get_template_part('template-parts/header/vertical', 'top');
    }
    ?>
    <?php get_template_part('template-parts/breadcrumb/breadcrumb'); ?>