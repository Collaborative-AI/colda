<?php
/*
 * Header Options
 */
$opt_name;
Redux::setSection( $opt_name, array(
    'title'      => esc_html__( 'MailChimp Subscribe', 'xamin' ),
    'id'         => 'xamin-subscribe',
    'icon'       => 'el el-envelope',
    'fields'     => array(

        array(
            'id'        => 'xamin_display_subscribe',
            'type'      => 'button_set',
            'title'     => esc_html__( 'Display Subscribe Top','xamin'),
            'id'        => 'display_subscribe',
            'type'      => 'button_set',
            'title'     => esc_html__( 'Display Subscribe Top','xamin'),
            


            'options'   => array(
                            'yes' => esc_html__('Yes','xamin'),
                            'no' => esc_html__('No','xamin')
                        ),
            'default'   => esc_html__('yes','xamin')
        ),

        array(
            'id'        => 'xamin_subscribe',
            'type'      => 'text',
            'title'     => esc_html__( 'Subscribe Shortcode','xamin'),
            'subtitle'  => wp_kses( __( '<br />Put you Mailchimp for WP Shortcode here','xamin' ), array( 'br' => array() ) ),

            'required'  => array( 'xamin_display_subscribe', '=', 'yes' ),


            'required'  => array( 'xamin_display_subscribe', '=', 'yes' ),

            'required'  => array( 'display_subscribe', '=', 'yes' ),

        ),

    )) 
);
