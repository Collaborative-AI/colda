<?php $xamin_options = get_option('xamin_options'); ?>
<div class="responsive-vertical-logo-btn" id="responsive-logo-btn">
    <div class="container-fluid">
        <div class="row align-items-center">
            <div class="col-9 col-md-6">
                <!-- vertical menu btn container start-->
                <div class="iq-vertical-btn-container btn-vertical-open" id="vertical-menu-btn-open">
                    <span class="vertical-menu-btn d-inline-block">
                        <!-- <i class="fa fa-list-ul" aria-hidden="true"></i> -->
                        <span class="menu-btn d-inline-block">
                            <span class="line one"></span>
                            <span class="line two"></span>
                            <span class="line three"></span>
                        </span>
                    </span>
                </div>
                <!-- vertical menu btn container end-->
                <?php
                if ($xamin_options['header_radio'] == 1) {
                ?>
                    <a href="<?php echo esc_url(home_url('/')); ?>">
                        <?php
                        if (!empty($xamin_options['header_text'])) {
                        ?>
                            <h1 class="logo-text"><?php echo esc_html($xamin_options['header_text']); ?></h1>
                        <?php
                        }
                        ?>
                    </a>
                <?php
                } else {
                ?>
                    <a class="vertical-navbar-brand" href="<?php echo esc_url(home_url('/')); ?>">
                        <?php
                        if (function_exists('get_field') && class_exists('ReduxFramework')) {
                            $key_vertical = get_field('key_header');

                            if (!empty($key_vertical['header_logo']['url'])) {
                                $logo_vertical = $key_vertical['header_logo']['url'];
                            } else if (isset($xamin_options['xamin_logo']['url'])) {
                                $logo_vertical = $xamin_options['xamin_logo']['url'];
                            }
                        ?>
                            <img class="img-fluid logo" src="<?php echo esc_url($logo_vertical); ?>" alt="<?php esc_attr_e('xamin', 'xamin'); ?>">
                        <?php
                        } else {
                        ?>
                            <img class="img-fluid logo" src="<?php echo esc_url(get_template_directory_uri()); ?>/assets/images/redux/logo.png" alt="<?php esc_attr_e('xamin', 'xamin'); ?>">
                        <?php } ?>
                    </a>
                <?php
                }
                ?>
            </div>

            <div class="col-3 col-md-6 text-right">
                <!-- action btn & sidebar btn start-->
                <div class="sub-main" id="vertical-menu-sub-main">
                    <!--mobile View-->
                    <div class="xamin-res-shop-btn-container" id='x-ver-res-btn'>
                        <span class="xamin-res-shop-btn">
                            <i class="fa fa-shopping-basket" aria-hidden="true"></i>
                        </span>
                    </div>
                    <ul class="shop_list">
                        <!-- search -->
                        <?php
                        if (isset($xamin_options['header_display_search'])) {
                            $options = $xamin_options['header_display_search'];
                            if ($options == "yes") {
                        ?>
                                <li class="search-btn xamin-shop-btn">
                                    <a href="#" id="btn-search-popup"><i class="fa fa-search" aria-hidden="true"></i></a>
                                    <div class="search custom-serach">
                                        <button id="btn-search-popup-close" class="btn btn--search-close" aria-label="Close search form">
                                            <i class="ion-close-round" aria-hidden="true"></i>
                                        </button>
                                        <?php get_search_form(); ?>
                                    </div>
                                </li>
                        <?php
                            }
                        }
                        ?>
                        <!-- wishlist -->
                        <?php
                        if (class_exists('WooCommerce')) {
                        ?>
                            <?php
                            if (function_exists('YITH_WCWL') && isset($xamin_options['header_display_shop']) && $xamin_options['header_display_shop'] == 'yes') {
                                $wish_url = '';
                                if (isset($xamin_options['wishlist_link']) && !empty($xamin_options['wishlist_link'])) {
                                    $wish_url = get_page_link($xamin_options['wishlist_link']);
                                }
                            ?>
                                <li class="wishlist-btn xamin-shop-btn">
                                    <div class="wishlist_count">
                                        <?php $wishlist_count = YITH_WCWL()->count_products(); ?>
                                        <a href="<?php echo esc_url($wish_url); ?>">
                                            <i class="fa fa-heart"></i>
                                            <span class="wcount"><?php echo esc_html($wishlist_count); ?></span>
                                        </a>
                                    </div>
                                </li>
                            <?php } ?>
                            <!-- mini cart -->
                            <?php
                            if (isset($xamin_options['header_display_shop'])) {
                                $options = $xamin_options['header_display_shop'];
                                if ($options == "yes") { ?>
                                    <li class="cart-btn xamin-shop-btn">
                                        <div class="cart_count">
                                            <a class="parents mini-cart-count" href="<?php echo esc_url(wc_get_cart_url()); ?>">
                                                <i class="fa fa-shopping-cart"></i>
                                                <span id="mini-cart-count"><?php echo WC()->cart->get_cart_contents_count(); ?></span>
                                            </a>
                                        </div>
                                    </li>

                        <?php
                                }
                            }
                        } ?>
                        <li>
                            <nav aria-label="breadcrumb">
                                <?php if ((!empty($xamin_options['xamin_download_link'])) && (!empty($xamin_options['xamin_download_title']))) {
                                    $dlink = $xamin_options['xamin_download_link'];
                                    $dtitle = $xamin_options['xamin_download_title'];
                                ?>
                                    <div class="button-started xamin-btn-container">
                                        <a class="xamin-button" href="<?php echo esc_url($dlink, 'xamin'); ?>">
                                            <span class="btn_text"><?php echo esc_html($dtitle, 'xamin'); ?></span><i class="fas fa-angle-double-right"></i>
                                        </a>
                                    </div>
                                <?php } ?>
                                
                            </nav>
                        </li>
                        <li>
                            <!-- side area btn container start-->
                            <div class="iq-sidearea-btn-container" id="menu-btn-side-open">
                                    <span class="menu-btn d-inline-block">
                                        <span class="line one"></span>
                                        <span class="line two"></span>
                                        <span class="line three"></span>
                                    </span>
                                </div>
                                <!-- side area btn container end-->
                        </li>
                    </ul>
                </div>
                <!-- action btn & sidebar btn start-->
            </div>
        </div>
    </div>
</div>