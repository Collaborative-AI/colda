<?php

/**
 * Xamin\Xamin\Dynamic_Style\Styles\General class
 *
 * @package xamin
 */

namespace Xamin\Xamin\Dynamic_Style\Styles;

use Xamin\Xamin\Dynamic_Style\Component;
use function add_action;

class General extends Component
{
	public function __construct()
	{
		add_action('wp_enqueue_scripts', array($this, 'xamin_general_root_var'), 20);
		add_action('wp_enqueue_scripts', array($this, 'xamin_create_general_style'), 20);
		add_action('admin_head', array($this, 'xamin_custom_admin_styles'), 20);
	}
	public function xamin_general_root_var() {

		$xamin_options = get_option('xamin_options');
		$id = get_queried_object_id();
		$general_var = '';
		if (!empty($xamin_option['grid_container'])) {
			$general = $xamin_option['grid_container']['width'];
			$general_var .= '--content-width: ' . $general . ' !important;';
		}

		$is_page_spacing = get_post_meta($id, '_is_page_spacing', true);

		// general
		if ( $is_page_spacing == 'custom' ) {

			$page_spacing = get_post_meta($id, '_page_spacing', true);
		    $page_bottom_spacing = get_post_meta($id, '_page_bottom_spacing', true);

			if(!empty(trim($page_spacing))){
			    $general_var .= "--global-page-top-spacing:" . $page_spacing . "!important;";
			}
			if(!empty(trim($page_bottom_spacing))){
			    $general_var .= "--global-page-bottom-spacing:" . $page_bottom_spacing . "!important;";
			}

		} else {

			if (isset($xamin_options['is_page_spacing']) && $xamin_options['is_page_spacing'] == "custom") {
				$general_var .= !in_array($xamin_options['page_spacing']["top"], ['em', 'px', '%']) ? "--global-page-top-spacing:" . $xamin_options['page_spacing']["top"] . "!important;" : "";
				$general_var .= !in_array($xamin_options['page_spacing']["bottom"], ['em', 'px', '%']) ? "--global-page-bottom-spacing:" . $xamin_options['page_spacing']["bottom"] . "!important;" : "";
			}
		}

		// tablet
		if ( $is_page_spacing == 'custom' ) {
			
			$page_spacing_tab = get_post_meta($id, '_page_spacing_tab', true);
			$page_bottom_spacing_tab = get_post_meta($id, '_page_bottom_spacing_tab', true);
			if(!empty(trim($page_spacing_tab))){
			    $general_var .= "--global-page-spacing-top-tablet:" . $page_spacing_tab . "!important;";
			}
			if(!empty(trim($page_bottom_spacing_tab))){
			    $general_var .= "--global-page-spacing-bottom-tablet:" . $page_bottom_spacing_tab . "!important;";
			}

		} else {

			if (isset($xamin_options['is_page_spacing']) && $xamin_options['is_page_spacing'] == "custom") {
				$general_var .= !in_array($xamin_options['page_spacing_tablet']["top"], ['em', 'px', '%']) ? "--global-page-spacing-top-tablet:" . $xamin_options['page_spacing_tablet']["top"] . "!important;" : "";
				$general_var .= !in_array($xamin_options['page_spacing_tablet']["bottom"], ['em', 'px', '%']) ? "--global-page-spacing-bottom-tablet:" . $xamin_options['page_spacing_tablet']["bottom"] . "!important;" : "";
			}
		}

		// mobile
		if ( $is_page_spacing == 'custom') {
			$page_spacing_mob = get_post_meta($id, '_page_spacing_mob', true);
			$page_bottom_spacing_mob = get_post_meta($id, '_page_bottom_spacing_mob', true);
			if(!empty(trim($page_spacing_mob))){
			    $general_var .= "--global-page-spacing-top-mobile:" . $page_spacing_mob . "!important;";
			}
			if(!empty(trim($page_bottom_spacing_mob))){
			    $general_var .= "--global-page-spacing-bottom-mobile:" . $page_bottom_spacing_mob . "!important;";
			}
		} else {
			if (isset($xamin_options['is_page_spacing']) && $xamin_options['is_page_spacing'] == "custom") {
				$general_var .= !in_array($xamin_options['page_spacing_mobile']["top"], ['em', 'px', '%']) ? "--global-page-spacing-top-mobile:" . $xamin_options['page_spacing_mobile']["top"] . "!important;" : "";
				$general_var .= !in_array($xamin_options['page_spacing_mobile']["bottom"], ['em', 'px', '%']) ? "--global-page-spacing-bottom-mobile:" . $xamin_options['page_spacing_mobile']["bottom"] . "!important;" : "";
			}
		}
		if (!empty($general_var)) {
			$general_var = ":root{" . $general_var . "}";
			wp_add_inline_style('xamin-global', $general_var);
		}

	}


	public function xamin_custom_admin_styles()
	{
		echo '<style> .redux-container .ui-button { height: unset; } </style>';
	}

	public function xamin_create_general_style()
	{

		$xamin_option = get_option('xamin_options');
		$general_var = ':root { ';

		if (isset($xamin_option['grid_container']) && !empty($xamin_option['grid_container'])) {
			$general = $xamin_option['grid_container']['width'];
			$general_var .= ' --content-width: ' . $general . ' !important;';
		}
		$general_var .= '}';
		if ($xamin_option['layout_set'] == 1) {
			if (
				isset($xamin_option['xamin_layout_color'])  && !empty($xamin_option['xamin_layout_color'])
			) {
				$general = $xamin_option['xamin_layout_color'];
				$general_var .= ' body { background : ' . $general . ' !important; }';
			}
		}
		if ($xamin_option['layout_set'] == 3) {
			if (isset($xamin_option['xamin_layout_image']['url']) && !empty($xamin_option['xamin_layout_image']['url'])) {
				$general = $xamin_option['xamin_layout_image']['url'];
				$general_var .= '
					body { background-image: url(' . $general . ') !important; }';
			}
		}

		if ($xamin_option['xamin_back_to_top'] == 'no') {
			if (isset($xamin_option['xamin_back_to_top']) && !empty($xamin_option['xamin_back_to_top'])) {
				$general_var .= '
					#back-to-top { display: none !important; }';
			}
		}

		wp_add_inline_style('xamin-global', $general_var);
	}
}
