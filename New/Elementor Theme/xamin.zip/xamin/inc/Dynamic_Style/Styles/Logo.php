<?php
/**
 * Xamin\Xamin\Dynamic_Style\Styles\Logo class
 *
 * @package xamin
 */

namespace Xamin\Xamin\Dynamic_Style\Styles;

use Xamin\Xamin\Dynamic_Style\Component;
use function add_action;

class Logo extends Component
{
 
	public function __construct()
	{
		add_action('wp_enqueue_scripts', array($this, 'xamin_logo_options'), 20);
	}

	public function xamin_logo_options(){
        $xamin_options = get_option('xamin_options');
        $logo_var = '';
        if($xamin_options['header_radio'] == 1){
            if(isset($xamin_options['header_color'])){
                $logo = $xamin_options['header_color'];
                    $logo_var .= "
                    .navbar-light .navbar-brand,.navbar-light .logo-text {
                        color : $logo !important;
                    }"; 
            }  
        }          
            wp_add_inline_style( 'xamin-global', $logo_var );
    }
}
