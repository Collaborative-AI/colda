<?php

/**
 * Xamin\Xamin\Dynamic_Style\Styles\HeaderTop class
 *
 * @package xamin
 */

namespace Xamin\Xamin\Dynamic_Style\Styles;

use Xamin\Xamin\Dynamic_Style\Component;
use function add_action;
use function Xamin\Xamin\xamin;

class HeaderVertical extends Component
{
	public function __construct()
	{
		add_action('wp_enqueue_scripts', array($this, 'xamin_header_ver_background_style'), 20);
		add_action('wp_enqueue_scripts', array($this, 'xamin_ver_menu_color_options'), 20);
		add_action('wp_enqueue_scripts', array($this, 'xamin_ver_sub_menu_color_options'), 20);
		add_action('wp_enqueue_scripts', array($this, 'xamin_wave_effect_color'), 20);
		add_filter('body_class', array($this, 'xamin_ver_body_class'));
	}

	public function xamin_header_ver_background_style()
	{
		$xamin_option = get_option('xamin_options');
		$inline_css = '';

		if (function_exists('get_field')) {
			$page_id_header = get_queried_object_id();

			$key_header_back = get_field('key_dark_header', $page_id_header);
			$key_header_style = get_field('key_header', $page_id_header);

			$header_style = $key_header_style['header_variation'];
			$has_dark = $key_header_back['name_menu_has_dark'];
			$back_color = $key_header_back['name_back_color'];
		}

		if (isset($has_dark) && $has_dark == 'yes') {
			if (isset($back_color) && !empty($back_color) && isset($header_style) && ($header_style == '3' || $header_style == 'default')) {
				$inline_css = 'header.style-vertical,footer.iq-over-dark-90{
					background:' . $back_color . ' !important;
				}';
			}
		} else if (isset($xamin_option['xamin_header_variation'])  && $xamin_option['xamin_header_variation'] == '3') {
			if (isset($xamin_option['xamin_header_background_type']) && $xamin_option['xamin_header_background_type'] != 'default') {
				$type = $xamin_option['xamin_header_background_type'];
				if ($type == 'color') {
					if (!empty($xamin_option['xamin_header_background_color'])) {
						$inline_css = 'header.style-vertical{
							background:' . $xamin_option['xamin_header_background_color'] . ' !important;
						}';
					}
				}

				if ($type == 'image') {
					if (!empty($xamin_option['xamin_header_background_image']['url'])) {
						$inline_css = 'header.style-vertical{
							background:url(' . $xamin_option['xamin_header_background_image']['url'] . ') !important;
						}';
					}
				}

				if ($type == 'transparent') {
					$inline_css = 'header.style-vertical{
						background:transparent !important;
					}';
				}
			}
		}

		if (!empty($inline_css)) {
			wp_add_inline_style('xamin-global', $inline_css);
		}
	}
	public function xamin_ver_menu_color_options()
	{
		$xamin_option = get_option('xamin_options');
		$inline_css = '';
		$acf_menu_color = xamin()->isSetAcfDark();

		if (isset($xamin_option['xamin_header_variation'])  && $xamin_option['xamin_header_variation'] == '3' && !$acf_menu_color) {
			if (isset($xamin_option['header_menu_color_type']) && $xamin_option['header_menu_color_type'] == 'custom') {

				if (isset($xamin_option['xamin_header_menu_color']) && !empty($xamin_option['xamin_header_menu_color'])) {
					$inline_css .= 'header.style-vertical .navbar ul li a,header.style-vertical .navbar ul li a i{
                    color : ' . $xamin_option['xamin_header_menu_color'] . '!important;
                }';
				}

				if (isset($xamin_option['xamin_header_menu_active_color']) && !empty($xamin_option['xamin_header_menu_active_color'])) {
					$inline_css .= 'header.style-vertical #vertical-menu li.active>a, header.style-vertical #vertical-menu li.active>a i, header.style-vertical .navbar ul li.current-menu-ancestor >i, header .navbar ul li.current-menu-item i, header.style-vertical .navbar ul li.current-menu-ancestor > a, header.style-vertical .navbar ul li.current-menu-parent >a, header.style-vertical .navbar ul li.current-menu-ancestor >a ,header.style-vertical .navbar ul li.current-menu-ancestor >a i,header.style-vertical .navbar ul li.current-menu-ancestor .current-menu-item a, header.style-vertical #vertical-menu li ul li.current-menu-item a
                    {
                        color : ' . $xamin_option['xamin_header_menu_active_color'] . ' !important;
                    }';


					$inline_css .= '#vertical-menu li.menu-item-has-children ul >li.current-menu-ancestor:after, #vertical-menu li.menu-item-has-children ul >li.current-menu-item a:after ,header.style-vertical #vertical-menu li>a::before ,header.style-vertical .navbar ul li.current-menu-ancestor ul li.current-menu-ancestor > a:after ,header.style-vertical .navbar ul li a:hover:after{
                    background : ' . $xamin_option['xamin_header_menu_active_color'] . ' !important;
                }';
				}

				if (isset($xamin_option['xamin_header_menu_hover_color']) && !empty($xamin_option['xamin_header_menu_hover_color'])) {
					$inline_css .= 'header.style-vertical .navbar ul li a:hover ,header.style-vertical .navbar ul li a:hover i{
                    color : ' . $xamin_option['xamin_header_menu_hover_color'] . ' !important;
                }';
				}

				if (isset($xamin_option['xamin_vertical_header_active_background_color']) && !empty($xamin_option['xamin_vertical_header_active_background_color'])) {
					$inline_css .= 'header.style-vertical #vertical-menu li.active>a, header.style-vertical .navbar ul li.current-menu-item a, header.style-vertical #vertical-menu > li.current-menu-ancestor>a{
                    background : ' . $xamin_option['xamin_vertical_header_active_background_color'] . ' !important;
                }';

					$inline_css .= 'header.style-vertical .navbar ul li .iq-has-sub-menu a{
                    background : transparent !important;
                }';
				}
			}
		}
		if (!empty($inline_css)) {
			wp_add_inline_style('xamin-global', $inline_css);
		}
	}
	public function xamin_ver_sub_menu_color_options()
	{
		$xamin_option = get_option('xamin_options');
		$inline_css = '';
		$acf_menu_color = xamin()->isSetAcfDark();

		if (isset($xamin_option['xamin_header_variation'])  && $xamin_option['xamin_header_variation'] == '3' && !$acf_menu_color) {
			if (isset($xamin_option['header_submenu_color_type']) && $xamin_option['header_submenu_color_type'] == 'custom') {
				if (isset($xamin_option['xamin_header_submenu_color']) && !empty($xamin_option['xamin_header_submenu_color'])) {
					$inline_css .= 'header.style-vertical #vertical-menu li ul li a ,header.style-vertical #vertical-menu li ul li a i{
                   color : ' . $xamin_option['xamin_header_submenu_color'] . ' !important;
               }';
				}

				if (isset($xamin_option['xamin_header_submenu_active_color']) && !empty($xamin_option['xamin_header_submenu_active_color'])) {
					$inline_css .= 'header.style-vertical .navbar ul li.current-menu-ancestor .current-menu-item a, header.style-vertical #vertical-menu li ul li.current-menu-item a ,header.style-vertical #vertical-menu li ul li.current-menu-ancestor >a,header.style-vertical .navbar ul li.current-menu-ancestor li.current-menu-ancestor >a i,header.style-vertical #vertical-menu li ul li.current-menu-ancestor >a i
                    {
                     color : ' . $xamin_option['xamin_header_submenu_active_color'] . ' !important;
                    }';


					$inline_css .= '#vertical-menu li.menu-item-has-children ul >li.current-menu-item a:after,#vertical-menu li.menu-item-has-children ul >li.current-menu-ancestor > a:after
                {
                  background : ' . $xamin_option['xamin_header_submenu_active_color'] . ' !important;
                }';
				}

				if (isset($xamin_option['xamin_header_submenu_hover_color']) && !empty($xamin_option['xamin_header_submenu_hover_color'])) {
					$inline_css .= 'header.style-vertical #vertical-menu li ul li a:hover ,header.style-vertical #vertical-menu li ul li a:hover i{
                   color : ' . $xamin_option['xamin_header_submenu_hover_color'] . ' !important;
               }';

					$inline_css .= 'header.style-vertical #vertical-menu li ul li a:hover:after{
                   background : ' . $xamin_option['xamin_header_submenu_hover_color'] . ' !important;
               }';
				}
			}
		}
		if (!empty($inline_css)) {
			wp_add_inline_style('xamin-global', $inline_css);
		}
	}
	public function xamin_wave_effect_color()
	{
		$xamin_option = get_option('xamin_options');
		$inline_css = '';
		// remove below line when acf color customuzation introduce option and function from custom-color folders init.php file
		$acf_menu_color = xamin()->isSetAcfDark();

		if (isset($xamin_option['xamin_header_variation'])  && $xamin_option['xamin_header_variation'] == '3' && $acf_menu_color != 'true') {
			//--------wave effect color for vertical menu------/
			if (isset($xamin_option['xamin_vertical_menu_wave_effect_color']) && !empty($xamin_option['xamin_vertical_menu_wave_effect_color'])) {
				$inline_css .= 'header.style-vertical .ripple{
					background : ' . $xamin_option['xamin_vertical_menu_wave_effect_color'] . ' !important;
				}';
			}

			//--------line color for vertical menu------/
			if (isset($xamin_option['xamin_vertical_submenu_line__color']) && !empty($xamin_option['xamin_vertical_submenu_line__color'])) {
				$inline_css .= 'header.style-vertical #vertical-menu li.active ul:before{
					background : ' . $xamin_option['xamin_vertical_submenu_line__color'] . ' !important;
				}';
			}
		}
		if (!empty($inline_css)) {
			wp_add_inline_style('xamin-global', $inline_css);
		}
	}
	public function xamin_ver_body_class($classes)
	{
		$xamin_option = get_option('xamin_options');

		if (function_exists('get_field')) {
			$page_id_header = get_queried_object_id();

			$key_header_back = get_field('key_dark_header', $page_id_header);
			if (get_field('header_layout_switch') == 'default' &&  isset($key_header_back['name_menu_has_dark']) && $key_header_back['name_menu_has_dark'] == 'yes') {
				array_push($classes, 'iq-dark-mode');
			}

			$key_header_style = get_field('key_header', $page_id_header);
		}

		if (isset($key_header_style['header_variation']) && $key_header_style['header_variation'] == '3') {
			if (isset($key_header_style['name_ver_collapsed']) && $key_header_style['name_ver_collapsed'] == 'acf_ver_collapsed') {
				array_push($classes, 'vertical-menu-collapsed');
			} else {
				array_push($classes, 'vertical-menu-expanded');
			}
		} else if (isset($xamin_option['xamin_header_variation'])  && $xamin_option['xamin_header_variation'] == '3') {

			if (isset($xamin_option['xamin_vertical_hedader_collapsed']) && $xamin_option['xamin_vertical_hedader_collapsed'] == "collapsed") {
				array_push($classes, 'vertical-menu-collapsed');
			} else {
				array_push($classes, 'vertical-menu-expanded');
			}
		}
		return  $classes;
	}
}
