<?php

namespace Xamin\Xamin;


get_header();

?>
<div class="site-content-contain">
   <div id="content" class="site-content">
      <div id="primary" class="content-area">
         <main id="main" class="site-main">
            <div class="container">
                <div class="xamin-team-detail"> <?php
                    if(have_posts()) {
                        while(have_posts()) { ?>
                            <div class="row">
                                <div class="col-xl-4">
                                    <div class="xamin-team-detail-content"> 
                                        <?php the_post(); ?>
                                        <div class="featured-image"> <?php
                                            if(has_post_thumbnail()) {
                                                the_post_thumbnail('full');
                                            } ?>
                                        </div>
                                        <div class="xamin-team-member-content">
                                            <div class="title">
                                                <h4 class="team-member-title"><?php the_title(); ?></h4>
                                            </div>
                                            <?php
                                            if (!empty(rwmb_meta('iq_team_designation'))) {
                                                $designation  = rwmb_meta('iq_team_designation');
                                                ?>
                                                <div class="designation">
                                                    <span><?php echo esc_html($designation);?></span>
                                                </div>
                                            <?php } ?>
                                            
                                            <div class="content">
                                                <?php the_excerpt(); ?>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="xamin-personal_information">
                                        <div class="title">
                                            <h4 class="team-member-title"><?php echo esc_html__('Personal Information', 'xamin') ?></h4>
                                        </div>
                                        <div class="personal_information-content-list">
                                            <?php $fields = get_field('key_ioas1245', get_the_ID()); ?>
                                                <div class="content-list-item">
                                                    <div class="team-phone-number">
                                                        <span class="contact-title"><?php echo "Phone Number"; ?></span>
                                                        <span class="contact-number"><?php echo esc_html__($fields['iqonic_team_contact'],'xamin') ;?></span>
                                                    </div>
                                                    <div class="team-email-address">
                                                        <span class="email-address-title"><?php echo "E-mail Address"; ?></span>
                                                        <span class="team-email"><?php echo esc_html__($fields['iqonic_team_email'],'xamin');?></span>
                                                    </div>
                                                    <div class="team-website">
                                                        <span class="website-title"><?php echo "Website"; ?></span>
                                                        <span class="website"><?php echo esc_html__($fields['iqonic_team_website'],'xamin');?></span>
                                                    </div>
                                                    <div class="team-address">
                                                        <span class="address-title"><?php echo "Address"; ?></span>
                                                        <span class="address"><?php echo esc_html__($fields['iqonic_team_address'],'xamin');?></span>
                                                    </div>
                                                </div>
                                        </div>
                                    </div>
                                    <div class="xamin-team-details-social"> 
                                        <ul class="social-list">
                                        <?php
                                            $key = get_field('key_pjros1245', get_the_ID());
                                            $facebook = $key['iqonic_team_facebook'];
                                            $twitter = $key['iqonic_team_twitter'];
                                            $google = $key['iqonic_team_google'];
                                            $github = $key['iqonic_team_github'];
                                            $insta = $key['iqonic_team_insta'];

                                            $li = '';
                                    
                                            if (!empty($facebook)) {
                                                $li .= sprintf('<li class="social-list-item"><a href="%s" class="icon"><i class="fab fa-facebook-f"></i></a></li>', esc_url($facebook));
                                            }

                                            if (!empty($insta)) {
                                                $li .= sprintf('<li class="social-list-item"><a href="%s" class="icon"><i class="fab fa-instagram"></i></a></li>', esc_url($insta));
                                            }

                                            if (!empty($twitter)) {
                                                $li .= sprintf('<li class="social-list-item"><a href="%s" class="icon"><i class="fab fa-twitter"></i></a></li>', esc_url($twitter));
                                            }
                                    
                                            if (!empty($google)) {
                                                $li .= sprintf('<li class="social-list-item"><a href="%s" class="icon"><i class="fab fa-youtube"></i></a></li>', esc_url($google));
                                            }
                                    
                                            if (!empty($github)) {
                                                $li .= sprintf('<li class="social-list-item"><a href="%s" class="icon"><i class="fab fa-github"></i></a></li>', esc_url($github));
                                            }
                                            $allowed_html = array (
                                                    'li' => array( 
                                                        'class' => true,
                                                    ),
                                                    'i' => array(
                                                        'class' => true,
                                                    ),
                                                    'a' => array(
                                                        'href' => true,
                                                        'class'=> true,
                                                    ),
                                            );
                                            echo wp_kses($li,$allowed_html);
                                        ?>
                                        </ul>
                                    </div>
                                </div>
                                <div class="col-xl-8 mt-5 mt-xl-0 pl-xl-5">
                                    <?php the_content(); ?>
                                </div>
                            </div> <?php
                        }
                    } ?>
                </div>
            </div>
         </main>
        <!-- #primary -->
      </div>
   </div>
</div>
<?php    
get_footer();
