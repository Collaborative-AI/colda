<?php

/**
 * Xamin\Xamin\Dynamic_Style\Styles\AdditionalCode class
 *
 * @package xamin
 */

namespace Xamin\Xamin\Dynamic_Style\Styles;

use Xamin\Xamin\Dynamic_Style\Component;
use function add_action;

class AdditionalCode extends Component
{

    public function __construct()
    {
        add_action('wp_enqueue_scripts', array($this, 'xamin_inline_css'), 20);
        add_action('wp_enqueue_scripts', array($this, 'xamin_inline_js'), 20);
    }

    public function xamin_inline_css()
    {
        $xamin_options = get_option('xamin_options');
        $custom_style = "";

        if (!empty($xamin_options['xamin_css_code'])) {

            $xamin_css_code = $xamin_options['xamin_css_code'];
            $custom_style = $xamin_css_code;
        }
        wp_add_inline_style('xamin-global', $custom_style);
    }

    public function xamin_inline_js()
    {
        $xamin_option = get_option('xamin_options');

        $custom_js = "";
        if (!empty($xamin_option['xamin_js_code'])) {

            $xamin_js_code = $xamin_option['xamin_js_code'];

            $custom_js = $xamin_js_code;
            wp_register_script('xamin-custom-js', '', [], '', true);
            wp_enqueue_script('xamin-custom-js');
            wp_add_inline_script('xamin-custom-js', wp_specialchars_decode($custom_js));
        }
    }
}
