<?php

/**
 * Template part for displaying the page content when an error has occurred
 *
 * @package xamin
 */

namespace Xamin\Xamin;

?>
<section class="error">

	<div class="page-content">
		<?php
		if (is_home() && current_user_can('publish_posts')) {
		?>
			<p>
				<?php
				printf(
					wp_kses(
						/* translators: 1: link to WP admin new post page. */
						__('Ready to publish your first post? <a href="%1$s">Get started here</a>.', 'xamin'),
						array(
							'a' => array(
								'href' => array(),
							),
						)
					),
					esc_url(admin_url('post-new.php'))
				);
				?>
			</p>
		<?php
		} elseif (is_search()) {
		?>
			<?php
					$xamin_options = get_option('xamin_options');

					if (!empty($xamin_options['xamin_404_banner_image']['url'])) { ?>
					<div class="fourzero-image mb-5 image">
						<img src="<?php echo esc_url($xamin_options['xamin_404_banner_image']['url']); ?>" alt="<?php esc_html_e('404', 'xamin'); ?>" />
					</div>
				<?php } else {
						$bgurl = get_template_directory_uri() . '/assets/images/redux/404.png'; ?>
					<div class="fourzero-image mb-5">
						<img src="<?php echo esc_url($bgurl); ?>" alt="<?php esc_html_e('404', 'xamin'); ?>" />
					</div><?php }
						$four_title = isset($xamin_options['xamin_fourzerofour_title']) ? $xamin_options['xamin_fourzerofour_title'] : '';
						?><h4> <?php echo esc_html($four_title); ?></h4>
			
			<?php if (!empty($xamin_options['xamin_four_description'])) { ?>
				<p class="mb-5">
					<?php $four_des = $xamin_options['xamin_four_description'];
					echo esc_html($four_des); ?>
				</p> <?php
					} else { ?>
				<p class="mb-5">
					<?php esc_html_e('The requested page does not exist.', 'xamin'); ?>
				</p>
			<?php } ?>
			<div class="d-block">
				<a class="xamin-button" href="<?php echo esc_url(home_url()); ?>">
					<span class="text-btn">
						<?php if (!empty($xamin_options['xamin_fourzerofour_btn_text'])) {
							esc_html_e($xamin_options['xamin_fourzerofour_btn_text'], 'xamin');
						} else {
							esc_html_e('Back to Home', 'xamin');
						} ?></span><i class="fas fa-angle-double-right"></i>
				</a>

			</div>
		<?php
		} else {
		?>
			<p>
				<?php esc_html_e('It seems we can&rsquo;t find what you&rsquo;re looking for. Perhaps searching can help.', 'xamin'); ?>
			</p>
			<div class="d-block">
				<a class="xamin-button" href="<?php echo esc_url(home_url()); ?>">
					<span class="text-btn">
						<?php if (!empty($xamin_options['xamin_fourzerofour_btn_text'])) {
							esc_html_e($xamin_options['xamin_fourzerofour_btn_text'], 'xamin');
						} else {
							esc_html_e('Back to Home', 'xamin');
						} ?></span><i class="fas fa-angle-double-right"></i>
				</a>

			</div>
		<?php
		}

		get_search_form('');
		?>
	</div><!-- .page-content -->
</section><!-- .error -->