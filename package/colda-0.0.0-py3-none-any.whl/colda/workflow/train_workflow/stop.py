
class StopTrain:
    pass