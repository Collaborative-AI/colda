<?php

/**
 * Xamin\Xamin\Accessibility\Component class
 *
 * @package xamin
 */

namespace Xamin\Xamin\Accessibility;

use Xamin\Xamin\Component_Interface;
use function Xamin\Xamin\xamin;
use WP_Post;
use function add_action;
use function add_filter;
use function wp_enqueue_script;
use function get_theme_file_uri;
use function get_theme_file_path;
use function wp_script_add_data;
use function wp_localize_script;

/**
 * Class for improving accessibility among various core features.
 */
class Component implements Component_Interface
{

	/**
	 * Gets the unique identifier for the theme component.
	 *
	 * @return string Component slug.
	 */
	public function get_slug(): string
	{
		return 'accessibility';
	}

	/**
	 * Adds the action and filter hooks to integrate with WordPress.
	 */
	public function initialize()
	{
		add_action('wp_enqueue_scripts', array($this, 'action_enqueue_navigation_script'));
		add_action('wp_print_footer_scripts', array($this, 'action_print_skip_link_focus_fix'));
	}

	/**
	 * Enqueues a script that improves navigation menu accessibility.
	 */
	public function action_enqueue_navigation_script()
	{

		// If the AMP plugin is active, return early.
		if (xamin()->is_amp()) {
			return;
		}

		wp_script_add_data('xamin-navigation', 'async', true);
		wp_script_add_data('xamin-navigation', 'precache', true);
		wp_localize_script(
			'xamin-navigation',
			'xaminScreenReaderText',
			array(
				'expand'   => __('Expand child menu', 'xamin'),
				'collapse' => __('Collapse child menu', 'xamin'),
			)
		);
	}

	/**
	 * Prints an inline script to fix skip link focus in IE11.
	 *
	 * The script is not enqueued because it is tiny and because it is only for IE11,
	 * thus it does not warrant having an entire dedicated blocking script being loaded.
	 *
	 * Since it will never need to be changed, it is simply printed in its minified version.
	 *
	 * @link https://git.io/vWdr2
	 */
	public function action_print_skip_link_focus_fix()
	{

		// If the AMP plugin is active, return early.
		if (xamin()->is_amp()) {
			return;
		}

		// Print the minified script.
		wp_register_script('xamin-minified', '', false, true);
		wp_enqueue_script('xamin-minified', '', array(), false, true);
		wp_add_inline_script('xamin-minified', '/(trident|msie)/i.test(navigator.userAgent)&&document.getElementById&&window.addEventListener&&window.addEventListener("hashchange",function(){var t,e=location.hash.substring(1);/^[A-z0-9_-]+$/.test(e)&&(t=document.getElementById(e))&&(/^(?:a|select|input|button|textarea)$/i.test(t.tagName)||(t.tabIndex=-1),t.focus())},!1);');
	}

	/**
	 * Filters the HTML attributes applied to a menu item's anchor element.
	 *
	 * Checks if the menu item is the current menu item and adds the aria "current" attribute.
	 *
	 * @param array   $atts The HTML attributes applied to the menu item's `<a>` element.
	 * @param WP_Post $item The current menu item.
	 * @return array Modified HTML attributes
	 */
	
}
