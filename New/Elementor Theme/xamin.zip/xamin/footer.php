<?php

/**
 * The template for displaying the footer
 *
 * Contains the closing of the #content div and all content after.
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package xamin
 */

namespace Xamin\Xamin;

use Elementor\Plugin;

$footer_class = ' footer-one';
$xamin_options = get_option('xamin_options');
$is_default = true;

if (isset($xamin_options['display_footer'])) {
	$options = $xamin_options['display_footer'];
	if ($options == "yes") {
		if (isset($xamin_options['footer_image']['url'])) {
			$bgurl = $xamin_options['footer_image']['url'];
		}
	}
}
if (function_exists('get_field') && class_exists('ReduxFramework') && class_exists("Elementor\Plugin")) {
	$id = (get_queried_object_id()) ? get_queried_object_id() : '';
	$footer_display = !empty($id) ? get_post_meta($id, 'display_footer', true) : '';
	$footer_layout = !empty($id) ? get_post_meta($id, 'footer_layout_type', true) : '';
	$footer_name = !empty($id) ? get_post_meta($id, 'footer_layout_name', true) : '';
	if ($footer_display === 'yes' && $footer_layout !== 'default' && !empty($footer_name)) {
		$is_default = false;
		$footer_class = " custom-footer-layout";
		$footer = $footer_name;
		$my_layout = get_page_by_path($footer, '', 'iqonic_hf_layout');
		$footer_response =  Plugin::instance()->frontend->get_builder_content_for_display($my_layout->ID);
	} else if (isset($xamin_options['footer_layout']) && $xamin_options['footer_layout'] == 'custom') {
		$is_default = false;
		$footer_class = " custom-footer-layout";
		$footer = $xamin_options['footer_style'];
		$my_layout = get_page_by_path($footer, '', 'iqonic_hf_layout');
		$footer_response =  Plugin::instance()->frontend->get_builder_content_for_display($my_layout->ID);
	}
}
?>

<footer id="colophon" class="footer<?php echo esc_attr($footer_class); ?>" <?php if (!empty($bgurl)) { ?> style="background-image: url(<?php echo esc_url($bgurl); ?> ) !important;" <?php } ?>>
	<?php
	if (function_exists('iqonic_return_elementor_res') && isset($footer_response) && !empty($footer_response)) {
		echo iqonic_return_elementor_res($footer_response);
	} else {
		$is_default = true;
	}

	if ($is_default) {
		echo '';
		get_template_part('template-parts/footer/widget');
		get_template_part('template-parts/footer/info');
	}
	?>
</footer><!-- #colophon -->

<!-- === back-to-top === -->
<div id="back-to-top">
	<a class="top" id="top" href="#top">
		<i aria-hidden="true" class="fa fa-caret-up"></i>
	</a>
</div>
<!-- === back-to-top End === -->
</div><!-- #page -->
<?php wp_footer(); ?>

</body>

</html>