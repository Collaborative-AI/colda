<?php

/**
 * Xamin\Xamin\Redux_Framework\Options\Footer class
 *
 * @package xamin
 */

namespace Xamin\Xamin\Redux_Framework\Options;

use Redux;
use Xamin\Xamin\Redux_Framework\Component;

class Footer extends Component
{

	public function __construct()
	{
		$this->set_widget_option();
	}

	protected function set_widget_option()
	{
		Redux::set_section($this->opt_name, array(
			'title' => esc_html__('Footer', 'xamin'),
			'id'    => 'footer-editor',
			'icon'  => 'el el-arrow-down',
			'customizer_width' => '500px',
		));

		Redux::set_section($this->opt_name, array(
			'title' => esc_html__('Footer Background', 'xamin'),
			'id'    => 'footer-logo',
			'subsection' => true,
			'desc'  => esc_html__('This section contains options for footer.', 'xamin'),
			'fields' => array(
				array(
					'id' => 'footer_layout',
					'type' => 'button_set',
					'title' => esc_html__('Footer Layout', 'xamin'),
					'options' => array(
						'default' => esc_html__('Default', 'xamin'),
						'custom' => esc_html__('Custom', 'xamin'),
					),
					'default' => 'default'
				),
				array(
					'id'        => 'footer_style',
					'type'      => 'select',
					'title' 	=> esc_html__('Footer Layout', 'xamin'),
					'subtitle' 	=> esc_html__('Select the layout variation that you want to use for Footer.', 'xamin'),
					'options'	=> (function_exists('iqonic_addons_get_list_layouts')) ? iqonic_addons_get_list_layouts(false, 'footer') : '',
					'required' 	=> array('footer_layout', '=', 'custom'),
				),

				array(
					'id'        => 'display_footer',
					'type'      => 'button_set',
					'title'     => esc_html__('Display Footer Background Image', 'xamin'),
					'subtitle' => esc_html__('Display Footer Background Image On All page', 'xamin'),
					'required' 	=> array('footer_layout', '=', 'default'),
					'options'   => array(
						'yes' => esc_html__('Yes', 'xamin'),
						'no' => esc_html__('No', 'xamin')
					),
					'default'   => esc_html__('no', 'xamin')
				),

				array(
					'id'       => 'footer_image',
					'type'     => 'media',
					'url'      => false,
					'title'    => esc_html__('Footer Background Image', 'xamin'),
					'required'  => array('display_footer', '=', 'yes'),
					'read-only' => false,
					'subtitle' => esc_html__('Upload Footer image for your Website.', 'xamin'),
					'default'  => array('url' => get_template_directory_uri() . '/assets/images/redux/footer-img.jpg'),
				),

				array(
					'id'        => 'change_footer_color',
					'type'      => 'button_set',
					'title'     => esc_html__('Change Footer Color', 'xamin'),
					'subtitle'  => esc_html__('Turn on to Change Footer Background Color', 'xamin'),
					'required' 	=> array('footer_layout', '=', 'default'),
					'options'   => array(
						'0' => esc_html__('Yes', 'xamin'),
						'1' => esc_html__('No', 'xamin')
					),
					'default'   => esc_html__('0', 'xamin')
				),

				array(
					'id'            => 'footer_color',
					'type'          => 'color',
					'title'         => esc_html__('Footer Background Color', 'xamin'),
					'subtitle'      => esc_html__('Choose Footer Background Color', 'xamin'),
					'required'  => array('change_footer_color', '=', '0'),
					'default'       => '#eff1fe',
					'mode'          => 'background',
					'transparent'   => false
				),

				array(
					'id'            => 'footer_title_color',
					'type'          => 'color',
					'title'         => esc_html__('Title Color', 'xamin'),
					'required'  => array('change_footer_color', '=', '0'),
					'default'       => '#eff1fe',
					'mode'          => 'background',
					'transparent'   => false
				),

				array(
					'id'            => 'footer_text_color',
					'type'          => 'color',
					'title'         => esc_html__('Text Color', 'xamin'),
					'required'  => array('change_footer_color', '=', '0'),
					'default'       => '#eff1fe',
					'mode'          => 'background',
					'transparent'   => false
				),
			

			)
		));

		Redux::set_section($this->opt_name, array(
			'title' => esc_html__('Footer Option', 'xamin'),
			'id'    => 'footer-section',
			'subsection' => true,
			'desc'  => esc_html__('This section contains options for footer.', 'xamin'),
			'fields' => array(
				
				array(
					'id'   => 'info_footer_option',
					'type' => 'info',
					'style' => 'warning',
					'required' 	=> array('footer_layout', '=', 'custom'),
					'desc' => esc_html__('The options will be displayed for default footer', 'xamin')
				),

				array(
					'id'        => 'xamin_footer_top',
					'type'      => 'button_set',
					'title'     => esc_html__('Display Footer', 'xamin'),
					'subtitle' => esc_html__('Display Footer On All page', 'xamin'),
					'required' 	=> array('footer_layout', '=', 'default'),
					'options'   => array(
						'yes' => esc_html__('Yes', 'xamin'),
						'no' => esc_html__('No', 'xamin')
					),
					'default'   => esc_html__('yes', 'xamin')
				),

				array(
					'id'        => 'xamin_footer_width',
					'type'      => 'image_select',
					'title'     => esc_html__('Footer Layout Type', 'xamin'),
					'required'  => array('xamin_footer_top', '=', 'yes'),
					'subtitle'  => wp_kses(__('<br />Choose among these structures (1column, 2column and 3column) for your footer section.<br />To fill these column sections you should go to appearance > widget.<br />And add widgets as per your needs.', 'xamin'), array('br' => array())),
					'options'   => array(
						'1' => array('title' => esc_html__('Footer Layout 1', 'xamin'), 'img' => get_template_directory_uri() . '/assets/images/redux/footer_first.png'),
						'2' => array('title' => esc_html__('Footer Layout 2', 'xamin'), 'img' => get_template_directory_uri() . '/assets/images/redux/footer_second.png'),
						'3' => array('title' => esc_html__('Footer Layout 3', 'xamin'), 'img' => get_template_directory_uri() . '/assets/images/redux/footer_third.png'),
						'4' => array('title' => esc_html__('Footer Layout 4', 'xamin'), 'img' => get_template_directory_uri() . '/assets/images/redux/footer_four.png'),
						'5' => array('title' => esc_html__('Footer Layout 5', 'xamin'), 'img' => get_template_directory_uri() . '/assets/images/redux/footer_five.png'),
					),
					'default'   => '4',
				),

				array(
					'id'       => 'footer_one',
					'type'     => 'select',
					'title'    => esc_html__('Select 1 Footer Alignment', 'xamin'),
					'required'  => array('xamin_footer_top', '=', 'yes'),
					'options'  => array(
						'1' => 'Left',
						'2' => 'Right',
						'3' => 'Center',
					),
					'default'  => '1',
				),

				array(
					'id'       => 'footer_two',
					'type'     => 'select',
					'title'    => esc_html__('Select 2 Footer Alignment', 'xamin'),
					'required'  => array('xamin_footer_top', '=', 'yes'),
					'options'  => array(
						'1' => 'Left',
						'2' => 'Right',
						'3' => 'Center',
					),
					'default'  => '1',
				),

				array(
					'id'       => 'footer_three',
					'type'     => 'select',
					'title'    => esc_html__('Select 3 Footer Alignment', 'xamin'),
					'required'  => array('xamin_footer_top', '=', 'yes'),
					'options'  => array(
						'1' => 'Left',
						'2' => 'Right',
						'3' => 'Center',
					),
					'default'  => '1',
				),

				array(
					'id'       => 'footer_fore',
					'type'     => 'select',
					'title'    => esc_html__('Select 4 Footer Alignment', 'xamin'),
					'required'  => array('xamin_footer_top', '=', 'yes'),
					'options'  => array(
						'1' => 'Left',
						'2' => 'Right',
						'3' => 'Center',
					),
					'default'  => '1',
				),

				array(
					'id'       => 'footer_five',
					'type'     => 'select',
					'title'    => esc_html__('Select 5 Footer Alignment', 'xamin'),
					'required'  => array('xamin_footer_top', '=', 'yes'),
					'options'  => array(
						'1' => 'Left',
						'2' => 'Right',
						'3' => 'Center',
					),
					'default'  => '1',
				),
			)
		));

		Redux::set_section($this->opt_name, array(
			'title'      => esc_html__('Footer Copyright', 'xamin'),
			'id'         => 'footer-copyright',
			'subsection' => true,
			'fields'     => array(

				array(
					'id'   => 'info_normal',
					'type' => 'info',
					'style' => 'warning',
					'required' 	=> array('footer_layout', '=', 'custom'),
					'desc' => esc_html__('The options will be displayed for default footer', 'xamin')
				),

				array(
					'id'        => 'display_copyright',
					'type'      => 'button_set',
					'title'     => esc_html__('Display Copyrights', 'xamin'),
					'required' 	=> array('footer_layout', '=', 'default'),
					'options'   => array(
						'yes' => esc_html__('Yes', 'xamin'),
						'no' => esc_html__('No', 'xamin')
					),
					'default'   => esc_html__('yes', 'xamin')
				),
				array(
					'id'       => 'footer_copyright_align',
					'type'     => 'select',
					'required'  => array('display_copyright', '=', 'yes'),
					'title'    => esc_html__('Copyrights Alignment', 'xamin'),
					'options'  => array(
						'1' => 'Left',
						'2' => 'Right',
						'3' => 'Center',
					),
					'default'  => '3',
				),

				array(
					'id'        => 'footer_copyright',
					'type'      => 'editor',
					'required'  => array('display_copyright', '=', 'yes'),
					'title'     => esc_html__('Copyrights Text', 'xamin'),
					'default'   => esc_html__('Copyright 2022 xamin All Rights Reserved.', 'xamin'),
				),

				array(
					'id'            => 'footer_copyright_bgcolor',
					'type'          => 'color',
					'title'         => esc_html__('Background Color', 'xamin'),
					'subtitle'      => esc_html__('Choose Background Color', 'xamin'),
					'required'  	=> array('display_copyright', '=', 'yes'),
					'default'       => '#f5f7fe',
					'mode'          => 'background',
					'transparent'   => false
				),

				array(
					'id'            => 'footer_copyright_color',
					'type'          => 'color',
					'title'         => esc_html__('Text Color', 'xamin'),
					'subtitle'      => esc_html__('Choose Text Color', 'xamin'),
					'required'  	=> array('display_copyright', '=', 'yes'),
					'default'       => '#525f81',
					'mode'          => 'background',
					'transparent'   => false
				),
				
			)
		));
	}
}
