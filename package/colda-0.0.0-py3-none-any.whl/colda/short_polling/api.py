from short_polling.polling import ShortPolling


__all__ = [
    'ShortPolling'
]