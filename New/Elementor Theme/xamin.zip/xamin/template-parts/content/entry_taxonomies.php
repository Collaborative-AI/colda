<?php
/**
 * Template part for displaying a post's taxonomy terms
 *
 * @package xamin
 */

namespace Xamin\Xamin;

$taxonomies = wp_list_filter(
	get_object_taxonomies( $post, 'objects' ),
	array(
		'public' => true,
	)
);

?>
<?php
	$post_tag = get_the_tags();
	if ($post_tag) { ?>
			<ul class="xamin-blogtag">
				<li class="xamin-tag-title">
					<i class="fa fa-tags" aria-hidden="true"></i> Tags:
				</li>
				<?php foreach ($post_tag as $cat) { ?>
					<li><a href="<?php echo get_category_link($cat->term_id) ?>"><?php echo esc_html($cat->name); ?></a></li>
				<?php } ?>
			</ul>

<?php }
	?>