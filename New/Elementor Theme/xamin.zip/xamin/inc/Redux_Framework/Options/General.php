<?php

/**
 * Xamin\Xamin\Redux_Framework\Options\General class
 *
 * @package xamin
 */

namespace Xamin\Xamin\Redux_Framework\Options;

use Redux;
use Xamin\Xamin\Redux_Framework\Component;

class General extends Component
{

	public function __construct()
	{
		$this->set_widget_option();
	}

	protected function set_widget_option()
	{
		Redux::set_section($this->opt_name, array(
			'title' => esc_html__('General', 'xamin'),
			'id'    => 'editer-general',
			'icon'  => 'el el-dashboard',
			'customizer_width' => '500px',
		));

		Redux::set_section($this->opt_name, array(
			'title' => esc_html__('Body Layout', 'xamin'),
			'id'    => 'layout-section',
			'icon'  => 'el el-website',
			'subsection' => true,
			'fields' => array(

				array(
					'id'       => 'layout_ui',
					'type'     => 'button_set',
					'title'    => esc_html__('New Layout UI', 'xamin'),
					'subtitle' => esc_html__('Select this option for layout New UI Design of the theme.', 'xamin'),
					'options'  => array(
						'yes' => 'Yes',
						'no' => 'No',
					),
					'default'  => 'yes'
				),

				array(
					'id'       => 'layout_set',
					'type'     => 'button_set',
					'title'    => esc_html__('Body Set Option', 'xamin'),
					'subtitle' => esc_html__('Select this option for body color or image of the theme.', 'xamin'),
					'options'  => array(
						'1' => 'Color',
						'2' => 'Default',
						'3' => 'Image'
					),
					'default'  => '2'
				),

				array(
					'id'       => 'xamin_layout_image',
					'type'     => 'media',
					'url'      => false,
					'title'    => esc_html__('Set Body Image', 'xamin'),
					'read-only' => false,
					'required'  => array('layout_set', '=', '3'),
					'subtitle' => esc_html__('Upload Image for your body.', 'xamin'),
				),

				array(
					'id'            => 'xamin_layout_color',
					'type'          => 'color',
					'title'         => esc_html__('Set Body Color', 'xamin'),
					'subtitle'      => esc_html__('Choose Body Color', 'xamin'),
					'required'  => array('layout_set', '=', '1'),
					'default'       => '#ffffff',
					'mode'          => 'background',
					'transparent'   => false
				),

				// top - bottom spacing after hide banner

				array(
					'id' => 'is_page_spacing',
					'type' => 'button_set',
					'title' => esc_html__('Page Spacing', 'xamin'),
					'subtitle'  =>  esc_html__('Adjust your site page top / bottom spacing if you hide banner.', 'xamin'),
					'options' => array(
						'default' => 'Default',
						'custom' => 'Custom',
					),
					'default' => 'default'
				),

				array(
					'title' => esc_html__( 'General View', 'xamin' ),
					'id' => 'page_spacing',
					'type' => 'spacing',
					'output' => array('.progress-wrap'),
					'mode' => 'absolute',
					'units' => array('px'),
					'all' => false,
					'top' => true,
					'right' => false,
					'bottom' => true,
					'left' => false,
					'default' => array(
						'top' => '130',
						'bottom' => '130',
						'units' => 'px'
					),
					'desc'      =>  esc_html__('Top / Bottom', 'xamin'),
					'required' 	=> array('is_page_spacing', '=', 'custom'),
				),

				array(
					'title' => esc_html__( 'Tablet View', 'xamin' ),
					'id' => 'page_spacing_tablet',
					'type' => 'spacing',
					'output' => array('.progress-wrap'),
					'mode' => 'absolute',
					'units' => array('px'),
					'all' => false,
					'top' => true,
					'right' => false,
					'bottom' => true,
					'left' => false,
					'default' => array(
						'top' => '70',
						'bottom' => '70',
						'units' => 'px'
					),
					'desc'      =>  esc_html__('Top / Bottom', 'xamin'),
					'required' 	=> array('is_page_spacing', '=', 'custom'),
				),

				array(
					'title' => esc_html__( 'Mobile View', 'xamin' ),
					'id' => 'page_spacing_mobile',
					'type' => 'spacing',
					'mode' => 'absolute',
					'units' => array('px'),
					'all' => false,
					'top' => true,
					'right' => false,
					'bottom' => true,
					'left' => false,
					'default' => array(
						'top' => '40',
						'bottom' => '40',
						'units' => 'px'
					),
					'desc'      =>  esc_html__('Top / Bottom', 'xamin'),
					'required' 	=> array('is_page_spacing', '=', 'custom'),
				),


			)
		));

		/* SmoothScoll Settings */
		Redux::set_section($this->opt_name, array(
			'title' => esc_html__('Smooth Scroll Settings', 'xamin'),
			'id' => 'smoothscroll_options',
			'icon' => 'el el-adjust-alt',
			'subsection' => true,
			'fields' => array(
				array(
					'id'       	=> 'smoth_scroll',
					'type'     	=> 'button_set',
					'options' => array(
						'on' => esc_html__('Enable', 'xamin'),
						'off' => esc_html__('Disable', 'xamin'),
					),
					'title'    	=> esc_html__('Smoth Scroll', 'xamin'),
					'subtitle' 	=> esc_html__('Enable / Disable Smoth Scroll', 'xamin'),
					'default'  	=> 'on',
				),

				array(
					'id' 		=> 'smooth_framerate',
					'type' 		=> 'text',
					'title' 	=> esc_html__('Frame Rate', 'xamin'),
					'desc' 		=> esc_html__('Frame Rate', 'xamin'),
					'required' 	=> array('smoth_scroll', '=', 'on'),
					'validate' 	=> 'text',
					'default'   => 150
				),

				array(
					'id' 		=> 'smooth_animationTime',
					'type' 		=> 'text',
					'title'     => esc_html__('Animation Time', 'xamin'),
					'desc' 		=> esc_html__('Animation Time', 'xamin'),
					'required' 	=> array('smoth_scroll', '=', 'on'),
					'validate' 	=> 'text',
					'default'   => 1000
				),

				array(
					'id' 		=> 'smooth_stepSize',
					'type' 		=> 'text',
					'title' 	=> esc_html__('Step Size', 'xamin'),
					'desc' 		=> esc_html__('Step Size', 'xamin'),
					'required' 	=> array('smoth_scroll', '=', 'on'),
					'validate' 	=> 'text',
					'default' 	=> 100
				),

				array(
					'id' 		=> 'smooth_accelarationDelta',
					'type' 		=> 'text',
					'title' 	=> esc_html__('AccelarationDelta', 'xamin'),
					'desc' 		=> esc_html__('AccelarationDelta', 'xamin'),
					'required' 	=> array('smoth_scroll', '=', 'on'),
					'validate' 	=> 'text',
					'default' 	=> 50
				),

				array(
					'id' 		=> 'smooth_accelarationMax',
					'type' 		=> 'text',
					'title' 	=> esc_html__('AccelarationMax', 'xamin'),
					'desc' 		=> esc_html__('AccelarationMax', 'xamin'),
					'required' 	=> array('smoth_scroll', '=', 'on'),
					'validate' 	=> 'text',
					'default' 	=> 3
				),
			)
		));

		Redux::set_section($this->opt_name, array(
			'title' => esc_html__('Back to Top', 'xamin'),
			'id'    => 'header-general',
			'icon'  => 'el el-circle-arrow-up',
			'subsection' => true,
			'fields' => array(
				array(
					'id'        => 'xamin_back_to_top',
					'type'      => 'button_set',
					'title'     => esc_html__('"Back to top" Button', 'xamin'),
					'subtitle'  => esc_html__('Turn on to show "Back to top" button.', 'xamin'),
					'options'   => array(
						'yes'   => esc_html__('Yes', 'xamin'),
						'no'    => esc_html__('No', 'xamin')
					),
					'default'   => esc_html__('yes', 'xamin')
				),
			)
		));

		Redux::set_section($this->opt_name, array(
			'title' => esc_html__('Favicon', 'xamin'),
			'id'    => 'header-fevicon',
			'icon'  => 'el el-ok',
			'subsection' => true,
			'fields' => array(
				array(
					'id'       => 'xamin_fevicon',
					'type'     => 'media',
					'url'      => false,
					'title'    => esc_html__('Favicon', 'xamin'),
					'default'  => array('url' => get_template_directory_uri() . '/assets/images/redux/favicon.ico'),
					'subtitle' => esc_html__('Upload logo image for your Website. Otherwise site title will be displayed in place of logo.', 'xamin'),
				),
			)
		));
	}
}
