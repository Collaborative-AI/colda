<?php
/**
 * Xamin\Xamin\Dynamic_Style\Styles\BodyContainer class
 *
 * @package xamin
 */

namespace Xamin\Xamin\Dynamic_Style\Styles;

use Xamin\Xamin\Dynamic_Style\Component;
use function add_action;

class BodyContainer extends Component
{

	public function __construct()
	{
		if (class_exists('ReduxFramework')) {
			add_action('wp_enqueue_scripts', array( $this,'xamin_container_width'), 21);
		}
	}

	public function xamin_container_width()
	{
		$xamin_options = get_option('xamin_options');

		$box_container_width = "";

		if (isset($xamin_options['opt-slider-label']) && !empty($xamin_options['opt-slider-label'])) {

			$container_width = $xamin_options['opt-slider-label'];

			$box_container_width = "body.iq-container-width .container,
        							body.iq-container-width .elementor-section.elementor-section-boxed>
        							.elementor-container { max-width: " . $container_width . "px; } ";
		}


		wp_add_inline_style('xamin-style',
			$box_container_width
		);
	}
}
