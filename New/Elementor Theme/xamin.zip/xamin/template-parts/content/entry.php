<?php

/**
 * Template part for displaying a post
 *
 * @package xamin
 */

namespace Xamin\Xamin;
?>

<div class="xamin_blog-box-wrapper">
	<article id="post-<?php the_ID(); ?>" <?php post_class('entry iq-blog-article-style'); ?>>
		<div class="xamin-blog-box">
			<?php 
				get_template_part('template-parts/content/entry_header', get_post_type());
			?>
			<div class="xamin-blog-detail">
				<?php 
				get_template_part('template-parts/content/entry_meta', get_post_type());
				get_template_part('template-parts/content/entry_title', get_post_type());
				if (is_single()) {
					get_template_part('template-parts/content/entry_content', get_post_type());
				} else {
					get_template_part('template-parts/content/entry_summary', get_post_type());
				}
				get_template_part('template-parts/content/entry_footer', get_post_type());
				?>
			</div>
			<?php
			wp_link_pages(array(
				'before'      => '<div class="page-links">' . esc_html__('Pages:', 'xamin'),
				'after'       => '</div>',
				'link_before' => '<span class="page-number">',
				'link_after'  => '</span>',
			));
			?>
		</div>
	</article><!-- #post-<?php the_ID(); ?> -->
	<?php
	
	if (is_singular(get_post_type())) {
		if (class_exists('ReduxFramework')) {
			$xamin_option = get_option('xamin_options');
			if ($xamin_option['xamin_display_comment'] == 'yes') {
				// Show comments only when the post type supports it and when comments are open or at least one comment exists.
				if (post_type_supports(get_post_type(), 'comments') && (comments_open() || get_comments_number())) {
					comments_template();
				}
			}
		} else {
			// Show comments only when the post type supports it and when comments are open or at least one comment exists.
			if (post_type_supports(get_post_type(), 'comments') && (comments_open() || get_comments_number())) {
				comments_template();
			}
		}
	}
	?>
</div>