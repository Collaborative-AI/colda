<?php

/**
 * Xamin\Xamin\Dynamic_Style\Styles\Header class
 *
 * @package xamin
 */

namespace Xamin\Xamin\Dynamic_Style\Styles;

use Xamin\Xamin\Dynamic_Style\Component;

use function add_action;
use function Xamin\Xamin\xamin;

class Header extends Component
{

	public function __construct()
	{
		add_action('wp_enqueue_scripts', array($this, 'xamin_header_display_style'), 20);
		add_action('wp_enqueue_scripts', array($this, 'xamin_header_background_style'), 20);
		add_action('wp_enqueue_scripts', array($this, 'xamin_menu_color_options'), 20);
		add_action('wp_enqueue_scripts', array($this, 'xamin_sub_menu_color_options'), 20);
		add_action('wp_enqueue_scripts', array($this, 'xamin_responsive_menu_color_options'), 20);
		add_action('wp_enqueue_scripts', array($this, 'xamin_action_btn_color_options'), 20);
	}

	public function xamin_header_display_style()
	{
		$dynamic_css = '';

		if (function_exists('get_field')) {
			$page_id_header = get_queried_object_id();
			$display_header = get_field('acf_key_header_switch', $page_id_header);


			if ($display_header == 'no') {
				$dynamic_css .= 'header {
		 		display: none !important;
		 	}';
			}

			if (!empty($dynamic_css)) {
				wp_add_inline_style('xamin-global', $dynamic_css);
			}
		}
	}

	public function xamin_header_background_style()
	{
		$xamin_option = get_option('xamin_options');
		$dynamic_css = '';

		if (function_exists('get_field')) {
			$page_id_header = get_queried_object_id();

			$key_header_back = get_field('key_dark_header', $page_id_header);
			$key_header_style = get_field('key_header', $page_id_header);

			$header_style = $key_header_style['header_variation'];
			$has_dark = $key_header_back['name_menu_has_dark'];
			$back_color = $key_header_back['name_back_color'];
		}
		if (isset($has_dark) && $has_dark == 'yes') {
			if (!empty($back_color)  && isset($header_style) && $header_style != '3') {
				$dynamic_css .= 'header#main-header,footer.iq-over-dark-90{
					background: ' . $back_color . ' !important;
				}';
			}
		} else if (isset($xamin_option['xamin_header_variation'])  && $xamin_option['xamin_header_variation'] != '3') {
			if (isset($xamin_option['xamin_header_background_type']) && $xamin_option['xamin_header_background_type'] != 'default') {
				$type = $xamin_option['xamin_header_background_type'];
				if ($type == 'color') {
					if (!empty($xamin_option['xamin_header_background_color'])) {
						$dynamic_css .= 'header#main-header{
							background: ' . $xamin_option['xamin_header_background_color'] . ' !important;
						}';
					}
				}

				if ($type == 'image') {
					if (!empty($xamin_option['xamin_header_background_image']['url'])) {
						$dynamic_css .= 'header#main-header{
							background: url(' . $xamin_option['xamin_header_background_image']['url'] . ') !important;
						}';
					}
				}

				if ($type == 'transparent') {
					$dynamic_css .= 'header#main-header{
						background: transparent !important;
					}';
				}
			}
		}
		if (!empty($dynamic_css)) {
			wp_add_inline_style('xamin-global', $dynamic_css);
		}
	}

	public function xamin_menu_color_options()
	{

		$xamin_option =  get_option('xamin_options');
		$inline_css = '';

		$acf_menu_color = xamin()->isSetAcfDark();

		if (isset($xamin_option['xamin_header_variation'])  && $xamin_option['xamin_header_variation'] != '3' && !$acf_menu_color) {
			if (isset($xamin_option['header_menu_color_type']) && $xamin_option['header_menu_color_type'] == 'custom') {

				if (isset($xamin_option['xamin_header_menu_color']) && !empty($xamin_option['xamin_header_menu_color'])) {
					$inline_css .= 'header .navbar ul li a,header .navbar ul li i{
                    color : ' . $xamin_option['xamin_header_menu_color'] . '!important;
                }';
				}

				if (isset($xamin_option['xamin_header_menu_active_color']) && !empty($xamin_option['xamin_header_menu_active_color'])) {
					$inline_css .= ' header .navbar ul li.current-menu-item a, header .navbar ul li.current-menu-parent > a, header .navbar ul li.current-menu-parent i, header .navbar ul li.current-menu-item i, header .navbar ul li.current-menu-ancestor> a, header .navbar ul li.current-menu-ancestor> i{
                    color : ' . $xamin_option['xamin_header_menu_active_color'] . ' !important;
                }';
				}

				if (isset($xamin_option['xamin_header_menu_hover_color']) && !empty($xamin_option['xamin_header_menu_hover_color'])) {
					$inline_css .= 'header .navbar ul li:hover > a,header .navbar ul li:hover > i{
                    color : ' . $xamin_option['xamin_header_menu_hover_color'] . ' !important;
                }';
				}
			}
		}
		if (!empty($inline_css)) {
			wp_add_inline_style('xamin-global', $inline_css);
		}
	}

	public function xamin_sub_menu_color_options()
	{
		$xamin_option = get_option('xamin_options');
		$inline_css = '';
		$acf_menu_color = xamin()->isSetAcfDark();

		if (isset($xamin_option['xamin_header_variation'])  && $xamin_option['xamin_header_variation'] != '3' && !$acf_menu_color) {
			if (isset($xamin_option['header_submenu_color_type']) && $xamin_option['header_submenu_color_type'] == 'custom') {
				if (isset($xamin_option['xamin_header_submenu_color']) && !empty($xamin_option['xamin_header_submenu_color'])) {
					$inline_css .= 'header #mega-menu-top > li ul.mega-sub-menu li.mega-menu-item a,header #mega-menu-top > li ul.mega-sub-menu li.mega-menu-item i,header #mega-menu-top > li ul.mega-sub-menu li.mega-menu-item svg,header .navbar ul li .sub-menu li a,header .navbar ul li .sub-menu li.current-menu-parent .sub-menu  li a, header .navbar ul li .sub-menu li:hover .sub-menu li a,header .navbar ul li .sub-menu li i,header .navbar ul li .sub-menu li.current-menu-parent .sub-menu  li i, header .navbar ul li .sub-menu li:hover .sub-menu li i,header .navbar ul li .sub-menu li:hover .sub-menu li a,header .navbar ul li .sub-menu li:hover .sub-menu li i{
                   color : ' . $xamin_option['xamin_header_submenu_color'] . ' !important;
               }';
				}

				if (isset($xamin_option['xamin_header_submenu_active_color']) && !empty($xamin_option['xamin_header_submenu_active_color'])) {
					$inline_css .= 'header #mega-menu-top > li ul.mega-sub-menu li.mega-current-menu-item a,header #mega-menu-top > li ul.mega-sub-menu li.mega-current-menu-item svg,header #mega-menu-top > li ul.mega-sub-menu li.mega-current-menu-item i,header .navbar ul li .sub-menu li.current-menu-item a,header .navbar ul li .sub-menu li.current-menu-item i,header .navbar ul li .sub-menu li.current-menu-ancestor a,header .navbar ul li .sub-menu li.current-menu-ancestor i,header .navbar ul li .sub-menu li.current-menu-parent .sub-menu li.current-menu-item  a,header .navbar ul li .sub-menu li.current-menu-parent .sub-menu li.current-menu-item  i
                   {
                       color : ' . $xamin_option['xamin_header_submenu_active_color'] . ' !important;
                   }';
				}

				if (isset($xamin_option['xamin_header_submenu_hover_color']) && !empty($xamin_option['xamin_header_submenu_hover_color'])) {
					$inline_css .= 'header #mega-menu-top > li ul.mega-sub-menu li.mega-menu-item:hover a,header #mega-menu-top > li ul.mega-sub-menu li.mega-menu-item:hover i,header #mega-menu-top > li ul.mega-sub-menu li.mega-menu-item:hover svg,header .navbar ul li .sub-menu li:hover a,header .navbar ul li .sub-menu li:hover i,header .navbar ul li .sub-menu li.current-menu-parent:hover a, header .navbar ul li .sub-menu li.current-menu-parent .sub-menu li:hover a, header .navbar ul li .sub-menu li.current-menu-parent:hover .sub-menu li:hover a,header .navbar ul li .sub-menu li.current-menu-parent:hover i, header .navbar ul li .sub-menu li.current-menu-parent .sub-menu li:hover i, header .navbar ul li .sub-menu li.current-menu-parent:hover .sub-menu li:hover i,header .navbar ul li .sub-menu li:hover .sub-menu li:hover a,header .navbar ul li .sub-menu li:hover .sub-menu li:hover i{
                   color : ' . $xamin_option['xamin_header_submenu_hover_color'] . ' !important;
               }';
				}

				if (isset($xamin_option['xamin_header_submenu_background_color']) && !empty($xamin_option['xamin_header_submenu_background_color'])) {
					$inline_css .= 'header #mega-menu-top > li ul.mega-sub-menu li.mega-menu-item a,header #mega-menu-top > li ul.mega-sub-menu li.mega-menu-item i,header #mega-menu-top > li ul.mega-sub-menu li.mega-menu-item svg,header .navbar ul li .sub-menu li a,header .navbar ul li .sub-menu li.current-menu-parent li a,header .navbar ul li .sub-menu li.current-menu-parent:hover .sub-menu li a,header .navbar ul li .sub-menu li:hover .sub-menu li a,header .navbar ul li .sub-menu li:hover .sub-menu li a {
                   background : ' . $xamin_option['xamin_header_submenu_background_color'] . ' !important;
               }';
				}

				if (isset($xamin_option['header_submenu_background_hover_color']) && !empty($xamin_option['header_submenu_background_hover_color'])) {
					$inline_css .= 'header #mega-menu-top > li ul.mega-sub-menu li.mega-menu-item:hover a,header #mega-menu-top > li ul.mega-sub-menu li.mega-menu-item:hover i,header #mega-menu-top > li ul.mega-sub-menu li.mega-menu-item:hover svg,header .navbar ul li .sub-menu li:hover a,header .navbar ul li .sub-menu li.current-menu-parent:hover a,header .navbar ul li .sub-menu li.current-menu-parent .sub-menu li:hover a,header .navbar ul li .sub-menu li.current-menu-parent:hover .sub-menu li:hover a,header .navbar ul li .sub-menu li:hover .sub-menu li:hover a{
                   background : ' . $xamin_option['header_submenu_background_hover_color'] . ' !important;
               }';
				}

				if (isset($xamin_option['header_submenu_background_active_color']) && !empty($xamin_option['header_submenu_background_active_color'])) {
					$inline_css .= 'header #mega-menu-top > li ul.mega-sub-menu li.mega-current-menu-item a,header #mega-menu-top > li ul.mega-sub-menu li.mega-current-menu-item svg,header #mega-menu-top > li ul.mega-sub-menu li.mega-current-menu-item i,header .navbar ul li .sub-menu li.current-menu-item a,header .navbar ul li .sub-menu li.current-menu-parent a,header .navbar ul li .sub-menu li.current-menu-parent .sub-menu li.current-menu-item  a {
                   background : ' . $xamin_option['header_submenu_background_active_color'] . ' !important;
               }';
				}
			}
		}
		if (!empty($inline_css)) {
			wp_add_inline_style('xamin-global', $inline_css);
		}
	}

	public function xamin_responsive_menu_color_options()
	{
		$xamin_option = get_option('xamin_options');
		$inline_css = '';

		if (isset($xamin_option['responsive_menu_button_type']) && $xamin_option['responsive_menu_button_type'] == 'custom') {

			if (isset($xamin_option['responsive_menu_button_background_color']) && !empty($xamin_option['responsive_menu_button_background_color'])) {
				$inline_css .= 'header .navbar-light .navbar-toggler,#mega-menu-wrap-top .mega-menu-toggle .mega-toggle-block-0 .mega-toggle-animated-inner,#mega-menu-wrap-top .mega-menu-toggle .mega-toggle-block-0 .mega-toggle-animated-inner::before, #mega-menu-wrap-top .mega-menu-toggle .mega-toggle-block-0 .mega-toggle-animated-inner::after{
                background : ' . $xamin_option['responsive_menu_button_background_color'] . ' !important;
                border-color : ' . $xamin_option['responsive_menu_button_background_color'] . ' !important;
            }';
			}
			if (isset($xamin_option['responsive_menu_color']) && !empty($xamin_option['responsive_menu_color'])) {
				$inline_css .= '@media (max-width: 992px){
                header .navbar ul li a{
                    color : ' . $xamin_option['responsive_menu_color'] . ' !important;
                }
            }';
			}
			if (isset($xamin_option['responsive_menu_color']) && !empty($xamin_option['responsive_menu_color'])) {
				$inline_css .= '@media (max-width: 992px){
                header .navbar ul li a, header .navbar ul li i{
                    color : ' . $xamin_option['responsive_menu_color'] . ' !important;
                }
            }';
			}

			if (isset($xamin_option['responsive_menu_hover_color']) && !empty($xamin_option['responsive_menu_hover_color'])) {
				$inline_css .= '@media (max-width: 992px){
                header .navbar ul li:hover a,header .navbar ul li:hover i, header #mega-menu-top li .mega-sub-menu li:hover > a.mega-menu-link, header #mega-menu-top li:hover > i, header #mega-menu-top li:hover > svg{
                    color : ' . $xamin_option['responsive_menu_hover_color'] . ' !important;
                }
            }';
			}
			if (isset($xamin_option['responsive_menu_hover_color']) && !empty($xamin_option['responsive_menu_hover_color'])) {
				$inline_css .= '@media (max-width: 992px){
                header .navbar ul li:hover a,header .navbar ul li:hover i,header .navbar ul li.current-menu-item a, header .navbar ul li.current-menu-parent a, header .navbar ul li.current-menu-parent i, header .navbar ul li.current-menu-item i,header .navbar ul li.current-menu-ancestor a,header .navbar ul li.current-menu-ancestor i {
                    color : ' . $xamin_option['responsive_menu_hover_color'] . ' !important;
                }
            }';
			}

			if (isset($xamin_option['responsive_menu_background_color']) && !empty($xamin_option['responsive_menu_background_color'])) {
				$inline_css .= '@media (max-width: 992px){
                header .navbar ul li a, header #mega-menu-top li .mega-sub-menu li a.mega-menu-link, header #mega-menu-top li i, header #mega-menu-top li svg,
				header .navbar #mega-menu-top li a:hover,header .navbar #mega-menu-top li:hover a{
                    background : ' . $xamin_option['responsive_menu_background_color'] . ' !important;
                }
            }';
			}
			if (isset($xamin_option['responsive_menu_active_background_color']) && !empty($xamin_option['responsive_menu_active_background_color'])) {
				$inline_css .= '@media (max-width: 992px){
                header .navbar ul li.current-menu-item a, header .navbar ul li a:hover,
                header .navbar ul li:hover a,header .navbar ul li.current-menu-item a, header .navbar ul li.current-menu-parent a,   header .navbar ul li.current-menu-ancestor a,
				header #mega-menu-top li .mega-sub-menu li.mega-current-menu-item a.mega-menu-link, header #mega-menu-top li.mega-current-menu-item i, header #mega-menu-top li.mega-current-menu-item svg{
                    background : ' . $xamin_option['responsive_menu_active_background_color'] . ' !important;
                }
            }';
			}
		}
		if (!empty($inline_css)) {
			wp_add_inline_style('xamin-global', $inline_css);
		}
	}

	public function xamin_action_btn_color_options()
	{
		$xamin_option = get_option('xamin_options');
		$inline_css = '';

		if (isset($xamin_option['header_display_button'])) {
			$options = $xamin_option['header_display_button'];
			if ($options == "no") {
				$inline_css .= '.sub-main .button-started{
                display : none !important;
                }';
			}
		}

		if (isset($xamin_option['header_button_color_type']) && $xamin_option['header_button_color_type'] == 'custom') {
			if (isset($xamin_option['xamin_download_btn_background']) && !empty($xamin_option['xamin_download_btn_background'])) {
				$inline_css .= 'header .navbar .sub-main .button-started a,.responsive-vertical-logo-btn .sub-main .button-started a{
                background : ' . $xamin_option['xamin_download_btn_background'] . ' !important;
            }';
			}

			if (isset($xamin_option['xamin_download_btn_background_hover']) && !empty($xamin_option['xamin_download_btn_background_hover'])) {
				$inline_css .= 'header .navbar .sub-main .button-started a:hover,.responsive-vertical-logo-btn .sub-main .button-started a:hover{
                background : ' . $xamin_option['xamin_download_btn_background_hover'] . ' !important;
            }';
			}

			if (isset($xamin_option['xamin_download_btn_text']) && !empty($xamin_option['xamin_download_btn_text'])) {
				$inline_css .= '
				header .navbar .sub-main .button-started a,
				.responsive-vertical-logo-btn .sub-main .button-started a,
				.xamin-button span {
                    color : ' . $xamin_option['xamin_download_btn_text'] . ' !important;
                }';
			}

			if (isset($xamin_option['xamin_download_btn_text_hover']) && !empty($xamin_option['xamin_download_btn_text_hover'])) {
				$inline_css .= 'header .navbar .sub-main .button-started:hover a,.responsive-vertical-logo-btn .sub-main .button-started:hover a{
                color : ' . $xamin_option['xamin_download_btn_text_hover'] . ' !important;
            }';
			}
		}

		if (!empty($inline_css)) {
			wp_add_inline_style('xamin-global', $inline_css);
		}
	}
}
