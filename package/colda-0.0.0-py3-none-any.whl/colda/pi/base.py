from __future__ import annotations

from typing import final

from typeguard import typechecked


#@typechecked
class BasePI:
    '''
    Base class for PI
    '''

    @final
    def placeholder(self):
        pass
