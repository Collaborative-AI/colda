<?php
function xamin_import_files()
{
    return array(
        array(
            'import_file_name'             => esc_html__('All Content', 'xamin'),
            'local_import_redux'           => array(
                array(
                    'file_path'   => trailingslashit(get_template_directory()) . 'inc/Import/Demo/xamin_redux.json',
                    'option_name' => 'xamin_options',
                ),
            ),
            'local_import_file'            => trailingslashit(get_template_directory()) . 'inc/Import/Demo/xamin-content.xml',
            'local_import_widget_file'     => trailingslashit(get_template_directory()) . 'inc/Import/Demo/xamin-widget.wie',
            'local_import_customizer_file' => trailingslashit(get_template_directory()) . 'inc/Import/Demo/xamin-export.dat',

            'import_preview_image_url'     => get_template_directory_uri() . '/inc/Import/Demo/preview_import_image.jpg',
            'import_notice' => esc_html__('DEMO IMPORT REQUIREMENTS: Memory Limit of 128 MB and max execution time (php time limit) of 300 seconds. ', 'xamin') . '</br></br>' . esc_html__('Based on your INTERNET SPEED it could take 5 to 25 minutes. ', 'xamin'),
            'preview_url'                  => 'https://wordpress.iqonic.design/xamin-elementor/',
        ),
    );
}
add_filter('pt-ocdi/import_files', 'xamin_import_files');

function xamin_after_import_setup($selected_import)
{
    global $wp_filesystem;
    $content    =   '';

    // Assign menus to their locations.
    $locations = get_theme_mod('nav_menu_locations'); // registered menu locations in theme
    $menus = wp_get_nav_menus(); // registered menus

    if ($menus) {
        foreach ($menus as $menu) { // assign menus to theme locations

            if ($menu->name == 'Home Menu') {
                $locations['top'] = $menu->term_id;
            }
            if ($menu->name == 'Vertical Menu') {
                $locations['vertical'] = $menu->term_id;
            }
            if ($menu->name == 'Social Links Menu') {
                $locations['social'] = $menu->term_id;
            }
        }
    }
    set_theme_mod('nav_menu_locations', $locations); // set menus to locations 

    if ('All Content' === $selected_import['import_file_name']) {

        $front_page_id = get_page_by_title('Home');
        $blog_page_id  = get_page_by_title('Blog');


        update_option('show_on_front', 'page');
        update_option('page_on_front', $front_page_id->ID);
        update_option('page_for_posts', $blog_page_id->ID);
    }

    //Import Revolution Slider
    if (class_exists('RevSlider')) {
        $slider_array = array(
            get_template_directory() . "/inc/Import/slider/corona.zip",
            get_template_directory() . "/inc/Import/slider/data-analytics-news.zip",
            get_template_directory() . "/inc/Import/slider/Data-Center.zip",
            get_template_directory() . "/inc/Import/slider/data-science-course.zip",
            get_template_directory() . "/inc/Import/slider/healthcare-xamin.zip",
            get_template_directory() . "/inc/Import/slider/slider-3-11.zip",
            get_template_directory() . "/inc/Import/slider/sports-xamin.zip",
            get_template_directory() . "/inc/Import/slider/xamin.zip",
            get_template_directory() . "/inc/Import/slider/xamin5.zip",
            get_template_directory() . "/inc/Import/slider/xamin6.zip",
            get_template_directory() . "/inc/Import/slider/xamin7.zip",
            get_template_directory() . "/inc/Import/slider/xamin41.zip",
            get_template_directory() . "/inc/Import/slider/xamin-1.zip",
            get_template_directory() . "/inc/Import/slider/xamin-3.zip",
            get_template_directory() . "/inc/Import/slider/xamin-banking-n-finance.zip",
            get_template_directory() . "/inc/Import/slider/xamin-behaviour.zip",
            get_template_directory() . "/inc/Import/slider/xamin-data-science.zip",
            get_template_directory() . "/inc/Import/slider/xamin-e-book.zip",
            get_template_directory() . "/inc/Import/slider/xamin-education.zip",
            get_template_directory() . "/inc/Import/slider/xamin-manufacturing.zip",
            get_template_directory() . "/inc/Import/slider/xamin-marketing.zip",
            get_template_directory() . "/inc/Import/slider/xamin-security.zip",
            get_template_directory() . "/inc/Import/slider/xamin-visualization.zip",
            get_template_directory() . "/inc/Import/slider/xamin-visualization-1.zip",
        );

        $slider = new RevSlider();

        foreach ($slider_array as $filepath) {
            $slider->importSliderFromPost(true, true, $filepath);
        }
    }

      //Elementor Settings

    require_once(ABSPATH . '/wp-admin/includes/file.php');
    WP_Filesystem();

    $import_file =  trailingslashit(get_template_directory()) . 'inc/Import/Demo/elementor-site-settings.json';
    $enable_edit_with_elementor = [
        "post",
        "page",
        "xaminteam",
        "testimonial",
        "portfolio",
        "xamincareer",
    ];
    update_option('elementor_cpt_support', $enable_edit_with_elementor);
    if (file_exists($import_file)) {
        $content = $wp_filesystem->get_contents($import_file);
    }

    if (!empty($content)) {
        $default_post_id = get_option('elementor_active_kit');
        update_post_meta($default_post_id, '_elementor_page_settings', json_decode($content, true));
    }

    $menu_item = get_posts([
        'post_type' => 'nav_menu_item',
        'post_status' => 'publish',
        'numberposts' => -1,
    ]);
    foreach ($menu_item as $key => $value) {
        wp_update_post(
            array(
                'ID' => $value->ID,
                'post_content' => $value->post_content,
            )
        );
    }

    // remove default post
    wp_delete_post(1, true);
}
add_action('pt-ocdi/after_import', 'xamin_after_import_setup');
