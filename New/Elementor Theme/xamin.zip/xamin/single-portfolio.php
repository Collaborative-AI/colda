<?php

namespace Xamin\Xamin;

get_header();

?>
<div id="portfolio" class="content-area">
	<main id="portfolio-main" class="site-main">
		<div class="container">					
			<?php
			while ( have_posts() ) : the_post(); 
				get_template_part( 'template-parts/portfolio/content', get_post_format() );
			endwhile; // End of the loop. ?>
		</div>
	</main><!-- #main -->
</div><!-- .container -->
<?php get_footer();
