from __future__ import annotations

from typing import (
    final
)
from typeguard import typechecked


class BaseLog:
    '''
    Base class for log
    '''
    
    # TODO: implement methods
    @final
    def placeholder(self):
        pass