from Apollo_test_helper_functions import Test_Helper_API_TestCase

class Find_Test_API_TestCase(Test_Helper_API_TestCase):
    
    def test_find_test_assistor_two_assistors(self):
        self.find_test_assistor_two_assistors_helper()

    

    
