from __future__ import annotations

import json

from typing import Any

from _typing import JSONType


# def load_json(
#     data: JSONType
# ) -> Any:
#     '''
#     Load json

#     Parameters
#     ----------
#     data : JSONType
    
#     Returns
#     -------
#     Any
#     '''
#     return 