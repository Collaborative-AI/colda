<?php

/**
 * Template part for displaying the footer info
 *
 * @package xamin
 */

namespace Xamin\Xamin;

if (class_exists('ReduxFramework')) {

	$xamin_options = get_option('xamin_options');
	if ($xamin_options['footer_copyright_align'] == '1') {
		$align = 'left';
	} else if ($xamin_options['footer_copyright_align'] == '2') {
		$align = 'right';
	} else {
		$align = 'center';
	}
?>
	<div class="copyright-footer">
		<div class="container">
			<div class="row">
				<?php

				$page_copy=false;
				if(function_exists('get_field')){
					
					if( get_field('display_footer') == 'yes' || get_field('display_footer') != 'default'  )
					{
						if( get_field('acf_footer_copyright') == 'yes')
						{
							$page_copy=true;
						}
						else{
							
							$page_copy=false;
						}
						if(get_field('display_footer')=='no'){
							$page_copy=false;
						}
					}


				} else {

					if ($xamin_options['display_copyright'] == 'yes') {
						$page_copy=true;
					}

				}

					if ($page_copy) {
					?>
						<div class="col-sm-12 m-0 text-<?php echo esc_attr($align); ?>">
							<div class="pt-3 pb-3">
								<?php
								if (isset($xamin_options['footer_copyright'])) {  ?>
									<span class="copyright"><?php echo html_entity_decode($xamin_options['footer_copyright']); ?></span>
								<?php
								} else {	?>
									<span class="copyright"><a target="_blank" href="<?php echo esc_url('https://themeforest.net/user/iqonicthemes/portfolio/'); ?>"> <?php echo esc_html__('© 2022', 'xamin'); ?><strong><?php echo esc_html__(' xamin ', 'xamin'); ?></strong><?php echo esc_html__('. All Rights Reserved.', 'xamin'); ?></a></span>
								<?php
								} ?>
							</div>
						</div>
				<?php }
				 ?>
			</div>
		</div>
	</div><!-- .site-info -->

<?php } else { ?>

	<div class="copyright-footer">
		<div class="container">
			<div class="row">
				<div class="col-sm-12">
					<div class="pt-3 pb-3">
						<span class="copyright"><a target="_blank" href="<?php echo esc_url(__('https://themeforest.net/user/iqonicthemes/portfolio/', 'xamin')); ?>"> <?php printf(esc_html__('© 2022', 'xamin'), 'xamin'); ?><strong><?php printf(esc_html__(' xamin ', 'xamin'), 'xamin'); ?></strong><?php printf(esc_html__('. All Rights Reserved.', 'xamin'), 'xamin'); ?></a></span>
					</div>
				</div>
			</div>
		</div>
	</div><!-- .site-info -->
<?php }
