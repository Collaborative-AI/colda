<?php 
if(function_exists('get_field') && class_exists('ReduxFramework'))
{
    add_action( 'wp_head', 'xamin_footer_dynamic_style' );
}
function xamin_footer_dynamic_style()
{
    $page_id = get_queried_object_id();
    $xamin_option = get_option('xamin_options');
    $dynamic_css = array();
    

    	if(get_field('acf_key_footer_switch' , $page_id) != 'default')  
        {	
        	if(get_field('acf_key_footer_switch' ,$page_id) == 'no')
        	{
        		$dynamic_css[] = array(
                'elements'  =>  '.footer-top',
                'property'  =>  'display',
                'value'     =>  'none !important'
                );
                
        	}
    	}
	    else if(isset($xamin_option['xamin_footer_top']))
	    {
	    	 
	    	if($xamin_option['xamin_footer_top'] == 'no')
	    	{
				$dynamic_css[] = array(
		        'elements'  =>  '.footer-top',
		        'property'  =>  'display',
		        'value'     =>  'none !important'
		    	);

               
	    	}
	    }
        // Subscribe Option
        if(get_field('display_subscribe' , $page_id) != 'default')  
        {
            if(get_field('display_subscribe' , $page_id) == 'no')
            {
                $dynamic_css[] = array(
                'elements'  =>  '.footer_top_block',
                'property'  =>  'display',
                'value'     =>  'none !important'
                );
            }
        }
        else if(isset($xamin_option['xamin_display_subscribe']))
        {
            if($xamin_option['xamin_display_subscribe'] == "no")
            {
                $dynamic_css[] = array(
                'elements'  =>  '.footer_top_block',
                'property'  =>  'display',
                'value'     =>  'none !important'
                );
            }
        }
	
    
  
    if ( count( $dynamic_css ) > 0 ) 
    {
        echo "<style type='text/css' id='xamin-dynamic-css".rand(10,100000)."'>\n\n"; 
            xamin_dynamic_style( $dynamic_css );
        echo '</style>';
    }  
}
