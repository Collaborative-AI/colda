

class StopTest:
    pass