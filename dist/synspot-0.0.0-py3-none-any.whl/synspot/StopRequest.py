
class StopRequest:

    def __init__(self):
        pass

    def stopSingleTrainingTask(self, task_id: str):
        pass

    def stopAllTrainingTasks(self, task_id: str = None):
        pass