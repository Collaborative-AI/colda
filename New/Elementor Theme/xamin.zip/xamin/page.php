<?php

/**
 * The template for displaying all pages
 *
 * This is the template that displays all pages by default.
 * Please note that this is the WordPress construct of pages
 * and that other 'pages' on your WordPress site may use a
 * different template.
 *
 * @link https://codex.wordpress.org/Template_Hierarchy
 *
 * @package WordPress
 * @subpackage xamin
 * @since 1.0
 * @version 1.0
 */

namespace Xamin\Xamin;

$xamin_options = get_option('xamin_options');
$is_sidebar = xamin()->is_primary_sidebar_active();
$post_section = xamin()->post_style();
get_header();

?>
<div id="primary" class="content-area">
    <main id="main" class="site-main">
        <div class="container">
            <div class="row <?php echo esc_attr($post_section['row_reverse']); ?>">
                <?php if ($is_sidebar) {
                    echo '<div class="col-xl-8 col-sm-12">';
                }
                if (have_posts()) {

                    while (have_posts()) { ?>
                        <div class="<?php echo esc_attr($post_section['post']); ?>">
                            <?php the_post();
                            get_template_part('template-parts/content/entry_page', get_post_type());
                            ?>
                        </div>

                <?php wp_reset_postdata();
                    }
                } else {
                    get_template_part('template-parts/content/error');
                }

                ?>
                <?php if ($is_sidebar) {
                    echo '</div>';
                }
                get_sidebar(); ?>
            </div>
        </div>
    </main><!-- #main -->
</div><!-- .container -->
<?php get_footer();
