	</div><!-- #content -->
    </div><!-- .site-content-contain -->
</div><!-- #page -->
<?php remove_action( 'wp_footer', 'woocommerce_demo_store' ); ?>
<?php wp_footer(); ?>
</body>
</html>
