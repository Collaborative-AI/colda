from Apollo_train_helper_functions import Train_Helper_API_TestCase

class FindAPITestCase(Train_Helper_API_TestCase):
    def test_find_assistor_two_assistors(self):
        self.find_assistor_two_assistors_helper()