<?php

/**
 * Xamin\Xamin\Redux_Framework\Options\FourZeroFour class
 *
 * @package xamin
 */

namespace Xamin\Xamin\Redux_Framework\Options;

use Redux;
use Xamin\Xamin\Redux_Framework\Component;

class FourZeroFour extends Component
{

	public function __construct()
	{
		$this->set_widget_option();
	}

	protected function set_widget_option()
	{
		Redux::set_section($this->opt_name, array(
			'title' => esc_html__('404', 'xamin'),
			'id'    => 'fourzerofour-section',
			'icon'  => 'el-icon-error',
			'desc'  => esc_html__('This section contains options for 404.', 'xamin'),
			'fields' => array(


				array(
					'id' 		=> 'four_zero_four_layout',
					'type' 		=> 'button_set',
					'title' 	=> esc_html__('Page Layout', 'xamin'),
					'options' 	=> array(
						'default' 	=> esc_html__('Default', 'xamin'),
						'custom' 	=> esc_html__('Custom', 'xamin'),
					),
					'default'	=> 'default'
				),

				array(
					'id'        => '404_layout',
					'type'      => 'select',
					'title' 	=> esc_html__('404 Layout', 'xamin'),
					'subtitle' 	=> esc_html__('Select the layout variation that you want to use for 404 page.', 'xamin'),
					'options'	=> (function_exists('iqonic_addons_get_list_layouts')) ? iqonic_addons_get_list_layouts(false, 'four_zero_four') : '',
					'description'	=> (function_exists('iqonic_addons_get_list_layouts')) ? esc_html__("Create", 'xamin') . " <a target='_blank' href='" . admin_url('edit.php?post_type=iqonic_hf_layout') . "'>" . esc_html__("New Layout", 'xamin') . "</a>" : "",
					'required' 	=> array('four_zero_four_layout', '=', 'custom'),
				),

				array(
					'id'       => 'xamin_404_banner_image',
					'type'     => 'media',
					'url'      => true,
					'title'    => esc_html__('404 Page Default Banner Image', 'xamin'),
					'read-only' => false,
					'required' 	=> array('four_zero_four_layout', '=', 'default'),
					'default'  => array('url' => get_template_directory_uri() . '/assets/images/redux/404.png'),
					'subtitle' => esc_html__('Upload banner image for your Website. Otherwise blank field will be displayed in place of this section.', 'xamin'),
				),

				array(
					'id'        => 'xamin_fourzerofour_btn_text',
					'type'      => 'text',
					'title'     => esc_html__('404 Button Text', 'xamin'),
					'required' 	=> array('four_zero_four_layout', '=', 'default'),
					'default'   => esc_html__('Back to Home', 'xamin')
				),

				array(
					'id'        => 'xamin_fourzerofour_title',
					'type'      => 'text',
					'title'     => esc_html__('404 Page Title', 'xamin'),
					'required' 	=> array('four_zero_four_layout', '=', 'default'),
					'default'   => esc_html__('Oops! This Page is Not Found.', 'xamin')
				),
				array(
					'id'        => 'xamin_four_description',
					'type'      => 'textarea',
					'title'     => esc_html__('404 Page Description', 'xamin'),
					'required' 	=> array('four_zero_four_layout', '=', 'default'),
					'default'   => esc_html__('The requested page does not exist.', 'xamin')
				),
			)
		));
	}
}
