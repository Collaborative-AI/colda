<?php

/**
 * The template for displaying all pages
 *
 * This is the template that displays all pages by default.
 * Please note that this is the WordPress construct of pages
 * and that other 'pages' on your WordPress site may use a
 * different template.
 *
 * @link https://codex.wordpress.org/Template_Hierarchy
 *
 * @package WordPress
 * @subpackage xamin
 * @since 1.0
 * @version 1.0
 */

namespace Xamin\Xamin;

get_header();
$xamin_field = get_fields();
?>
<div id="primary" class="content-area">
    <main id="main" class="site-main">
        <div class="container">
            <div class="row">
                <div class="col-lg-8 col-sm-12">
                    <div class="xamin-course-single">
                        <!-- Categories -->
                        <div class="xamin-course-category">
                            <?php
                                $postcat = wp_get_post_terms(get_the_ID(), 'course-categories');
                                if ($postcat) {
                                    ?>
                                    <ul class="iq-course-cat">
                                        <?php
                                        foreach($postcat as $cat) {
                                            ?>
                                            <li class="item">
                                                <a href="<?php echo get_category_link( $cat->term_id ) ?>">
                                                    <?php echo esc_html__($cat->name); ?>
                                                </a>
                                            </li>   <?php
                                            }
                                        ?>
                                    </ul>
                                    <?php
                                }
                                ?>
                        </div>
                        <?php if(!empty(get_the_post_thumbnail(get_the_ID(), 'large'))){?>
                            <!-- Feature Image -->
                            <div class="xamin-course-feature-image">
                                <?php echo get_the_post_thumbnail(get_the_ID(), 'large'); ?>
                            </div>
                        <?php } ?>
                        <!-- title -->
                        <div class="xamin-course-title">
                            <h3 class="title"><?php echo get_the_title(); ?></h3>
                        </div>
                        <?php if(isset($xamin_field['course_price'])){?>
                            <!-- price -->
                            <div class="xamin-course-price">
                                <?php echo esc_html($xamin_field['course_price']); ?>
                            </div>
                        <?php } ?>
                        <!-- Tab Content -->

                        <?php
                        while (have_posts()) : the_post();
                        ?>
                            <nav class="xamin-nav-tabs">
                                <div class="nav nav-tabs" id="nav-tab" role="tablist">
                                    <a class="nav-item nav-link active" id="nav-description-tab" data-toggle="tab" href="#nav-description" role="tab" aria-controls="nav-description" aria-selected="true"><?php echo esc_html__('Description', 'xamin'); ?></a>
                                    <a class="nav-item nav-link" id="nav-instructor-tab" data-toggle="tab" href="#nav-instructor" role="tab" aria-controls="nav-instructor" aria-selected="false"><?php echo esc_html__('instructor', 'xamin'); ?></a>
                                    <a class="nav-item nav-link" id="nav-review-tab" data-toggle="tab" href="#nav-review" role="tab" aria-controls="nav-review" aria-selected="false"><?php echo esc_html__('Review', 'xamin'); ?></a>
                                </div>
                            </nav>
                            <div class="tab-content" id="nav-tabContent">
                                <!-- Description tab -->
                                <div class="tab-pane fade show active" id="nav-description" role="tabpanel" aria-labelledby="nav-description-tab">
                                    <?php if(!empty(get_the_excerpt())){
                                        echo esc_html(get_the_excerpt()); }
                                    ?>
                                </div>
                                <!-- instructor tab -->
                                <div class="tab-pane fade" id="nav-instructor" role="tabpanel" aria-labelledby="nav-instructor-tab">
                                    <div class="iq-instrutor-box">
                                        <div class="iq-instrutor-box-inner">
                                            <div class="row align-items-center">
                                                <?php if (isset($xamin_field['instructor_image']['url'])) { ?>
                                                    <div class="col-md-4">
                                                        <div class="iq-instrutor-img">
                                                            <img src="<?php echo esc_url($xamin_field['instructor_image']['url']); ?>" alt="instructor_image">
                                                        </div>
                                                    </div>
                                                <?php } ?>
                                                <div class="col-md-8">
                                                    <div class="iq-instrutor-details">
                                                        <?php if(!empty($xamin_field['instructor_name'])){?>
                                                            <div class="iq-instrutor-name">
                                                                <h4 class="name"><?php echo esc_html($xamin_field['instructor_name']); ?></h4>
                                                            </div>
                                                        <?php } ?>
                                                        <?php if(!empty($xamin_field['acf_social_media'])){ ?>
                                                            <div class="iq-insturtor-socials">
                                                                <?php $social = $xamin_field['acf_social_media']; ?>
                                                                <?php if(!empty($social['social_facebook'])){?>
                                                                <a href="<?php echo esc_url($social['social_facebook']); ?>"><i class="fab fa-facebook-f"></i></a><?php }?>
                                                                <?php if(!empty($social['social_twitter'])){?>
                                                                <a href="<?php echo esc_url($social['social_twitter']); ?>"><i class="fab fa-twitter"></i></a><?php }?>
                                                                <?php if(!empty($social['social_linkedin'])){?>
                                                                <a href="<?php echo esc_url($social['social_linkedin']); ?>"><i class="fab fa-linkedin-in"></i></a><?php }?>
                                                                <?php if(!empty($social['social_github'])){?>
                                                                <a href="<?php echo esc_url($social['social_github']); ?>"><i class="fab fa-github"></i></a><?php }?>
                                                            </div>
                                                        <?php } 
                                                        if(!empty($xamin_field['instructor_detail'])){ ?>
                                                            <div class="iq-instrutor-desc">
                                                                <p><?php echo esc_html($xamin_field['instructor_detail']); ?></p>
                                                            </div>
                                                        <?php } ?>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <!-- Review Tab -->
                                <div class="tab-pane fade" id="nav-review" role="tabpanel" aria-labelledby="nav-review-tab">
                                    <?php wp_list_comments();
                                    if (is_single()) {
                                        comments_template();
                                    }
                                    ?>
                                </div>
                            </div>
                        <?php
                            the_content();
                        endwhile; // End of the loop.
                        wp_reset_postdata();
                        ?>
                    </div>
                </div>
                <div class="col-lg-4">
                    <?php xamin()->display_primary_sidebar(); ?>
                </div>
            </div>

        </div><!-- #primary -->
    </main><!-- #main -->
</div><!-- .container -->
<?php get_footer();
