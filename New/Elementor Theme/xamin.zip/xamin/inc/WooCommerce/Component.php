<?php

/**
 * Xamin\Xamin\Woocommerce\Component class
 *
 * @package xamin
 */

namespace Xamin\Xamin;

namespace Xamin\Xamin\Woocommerce;

use Xamin\Xamin\Component_Interface;
use Xamin\Xamin\Templating_Component_Interface;
use function add_action;

/**
 * Class for managing Woocommerce UI.
 *
 * Exposes template tags:
 * * `xamin()->the_comments( array $args = array() )`
 *
 * @link https://wordpress.org/plugins/amp/
 */
class Component implements Component_Interface, Templating_Component_Interface
{
	/**
	 * Gets the unique identifier for the theme component.
	 *
	 * @return string Woocommerce slug.
	 */
	public function get_slug(): string
	{
		return 'woocommerce';
	}
	function __construct()
	{
		add_filter('woocommerce_gallery_thumbnail_size', function ($size) {
			return array(300, 300);
		});
	}

	/**
	 * Adds the action and filter hooks to integrate with WordPress.
	 */
	public function initialize()
	{	

        add_filter( 'woocommerce_show_page_title', '__return_false' );

		remove_action('woocommerce_before_shop_loop_item_title', 'woocommerce_template_loop_product_thumbnail', 10);
        add_action('woocommerce_before_shop_loop_item_title', array($this,'xamin_loop_product_thumbnail'), 10);

		// Single
		remove_action('woocommerce_single_product_summary', 'woocommerce_template_single_title', 5);
		add_action('woocommerce_single_product_summary',  array($this, 'woocommerce_my_single_title'), 5);

		add_action('woocommerce_before_shop_loop_item', array($this,'xamin_woocommerce_product_loop_start'), -1);
		add_action('woocommerce_after_shop_loop_item', array($this,'xamin_woocommerce_product_loop_end'), -1);

		remove_action('woocommerce_before_shop_loop_item', 'woocommerce_template_loop_product_link_open', 10);
        remove_action('woocommerce_after_shop_loop_item', 'woocommerce_template_loop_product_link_close', 5);

		add_theme_support('woocommerce');
        remove_action('woocommerce_before_main_content', 'woocommerce_breadcrumb', 20, 0);
    
		add_action('woocommerce_before_shop_loop_item_title', array($this,'woocommerce_product_loop_action_start'), 10);

		add_action('woocommerce_after_shop_loop_item', array($this,'woocommerce_product_loop_wishlist_button'), -1);

		add_action('woocommerce_before_main_content', array($this,'woocommerce_output_content_wrapper'));
		add_action('woocommerce_after_main_content', array($this,'woocommerce_output_content_wrapper_end'));

		/* products loop_columns */
		add_filter('loop_shop_columns', array($this, 'xamin_loop_columns'), 10, 2);

		remove_action( 'woocommerce_after_shop_loop_item', 'woocommerce_template_loop_add_to_cart');
		add_action('woocommerce_after_shop_loop_item', array($this,'woocommerce_template_loop_add_to_cart'));

		add_action('init', array($this,'disable_woo_commerce_sidebar'));

		remove_action( 'woocommerce_after_single_product_summary', 'woocommerce_upsell_display', 15 );


	}

	/**
	 * Gets template tags to expose as methods on the Template_Tags class instance, accessible through `xamin()`.
	 *
	 * @return array Associative array of $method_name => $callback_info pairs. Each $callback_info must either be
	 *               a callable or an array with key 'callable'. This approach is used to reserve the possibility of
	 *               adding support for further arguments in the future.
	 */
	public function template_tags(): array
	{
		return array();
	}

	function xamin_loop_product_thumbnail()
	{
		global $product;
		if (!$product) {
			return '';
		}
		$gallery    = $product->get_gallery_image_ids();
		$hover_skin = get_theme_mod('xamin_woocommerce_product_hover', 'none');
		if ($hover_skin == '0' || count($gallery) <= 0) {
			echo '<div class="iq-product-image">' . $product->get_image('shop_catalog') . '</div>';

			return '';
		}
		$image_featured = '<div class="iq-product-image">' . $product->get_image('shop_catalog') . wp_get_attachment_image($gallery[0], 'shop_catalog hover_image') . '</div>';

?>
		<?php echo '<div class="iq-product-img-wrap">'. $image_featured .'</div>'; ?>
	<?php
	}

	function xamin_template_loop_product_thumbnail($size = 'woocommerce_thumbnail', $deprecated1 = 0, $deprecated2 = 0)
	{
		echo xamin_loop_product_thumbnail();
	}

	function xamin_woocommerce_product_loop_start()
	{
		echo '<a href="' . esc_url_raw(get_the_permalink()) . '"> <div class="iq-product-block">';
	}
	public function xamin_woocommerce_product_loop_end(){
		echo  '</a>';
	}

	// overwrite existing output content wrapper function
	function woocommerce_output_content_wrapper()
	{
		if (is_singular()) {
			if (is_singular()) {
				echo '<div class="container">
							<div class="row" >
								<div class="col-sm-12" >';
			}
		}

	}
	function woocommerce_output_content_wrapper_end()
	{
		echo '</div><!-- Col -->
						</div><!-- Close Row -->
					</div><!-- Close Container -->
				';
		
	}

	function woocommerce_my_single_title()
	{
        ?>
		<h3 itemprop="name" class="product_title entry-title"><span><?php the_title(); ?></span></h3>
		<?php
	}

	function woocommerce_product_loop_action_start()
	{
		echo '<div class="product-caption">';
	}


	function woocommerce_product_loop_wishlist_button()
	{
		if (defined('YITH_WCWL') && !function_exists('yith_wcwl_add_wishlist_to_loop')) {
			echo do_shortcode('[yith_wcwl_add_to_wishlist]');
		}
	}

    /* products loop_columns */
	function xamin_loop_columns() {
	    return 3; // 3 products per row
	}

	function woocommerce_template_loop_add_to_cart($args = array())
	{
		global $product;

		if ($product) {
			$defaults = array(
				'quantity'   => 1,
				'class'      => implode(
					' ',
					array_filter(
						array(
							'button',
							'product_type_' . $product->get_type(),
							$product->is_purchasable() && $product->is_in_stock() ? 'add_to_cart_button' : '',
							$product->supports('ajax_add_to_cart') && $product->is_purchasable() && $product->is_in_stock() ? 'ajax_add_to_cart' : '',
							'xamin-button',
						)
					)
				),
				'attributes' => array(
					'data-product_id'  => $product->get_id(),
					'data-product_sku' => $product->get_sku(),
					'aria-label'       => $product->add_to_cart_description(),
					'rel'              => 'nofollow',
				),
			);
			$args = apply_filters('woocommerce_loop_add_to_cart_args', wp_parse_args($args, $defaults), $product);
			if (isset($args['attributes']['aria-label'])) {
				$args['attributes']['aria-label'] = wp_strip_all_tags($args['attributes']['aria-label']);
			}

			wc_get_template('loop/add-to-cart.php', $args);
		}
	}

	function disable_woo_commerce_sidebar()
	{
		remove_action('woocommerce_sidebar', 'woocommerce_get_sidebar', 10);
	}

}
