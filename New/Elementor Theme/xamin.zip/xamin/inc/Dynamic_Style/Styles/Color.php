<?php

/**
 * Xamin\Xamin\Dynamic_Style\Styles\Banner class
 *
 * @package xamin
 */

namespace Xamin\Xamin\Dynamic_Style\Styles;

use Xamin\Xamin\Dynamic_Style\Component;
use function add_action;

class Color extends Component
{

	public function __construct()
	{
		add_action('wp_enqueue_scripts', array($this, 'xamin_color_options'), 20);
		add_action('wp_enqueue_scripts', array($this, 'xamin_banner_title_color'), 20);
		add_action('wp_enqueue_scripts', array($this, 'xamin_layout_color'), 20);
		add_action('wp_enqueue_scripts', array($this, 'xamin_loader_color'), 20);
		add_action('wp_enqueue_scripts', array($this, 'xamin_opacity_color'), 20);
		add_action('wp_enqueue_scripts', array($this, 'xamin_header_radio'), 20);
		add_action('wp_enqueue_scripts', array($this, 'xamin_footer_color'), 20);
	}

	public function xamin_color_options()
	{

		$xamin_option = get_option('xamin_options');
		$color_var = ':root { ';
		if (!empty($xamin_option['primary_color'])) {
			$color = $xamin_option['primary_color'];
			$color_var .= ' --primary-color: ' . $color . ' !important;';
			$color_var .= ' --color-theme-primary: ' . $color . ' !important;';
		}
		if (!empty($xamin_option['secondary_color'])) {
			$color = $xamin_option['secondary_color'];
			$color_var .= ' --secondary-color: ' . $color . ' !important;';
			$color_var .= ' --color-theme-secondary: ' . $color . ' !important;';
		}
		if (!empty($xamin_option['text_color'])) {
			$color = $xamin_option['text_color'];
			$color_var .= ' --body-text: ' . $color . ' !important;';
		}
		if (!empty($xamin_option['title_color'])) {
			$color = $xamin_option['title_color'];
			$color_var .= ' --title-color: ' . $color . ' !important;';
		}
		
		$color_var .= '}';

		if (!empty($xamin_option['sub_title_color'])) {
			$color = $xamin_option['sub_title_color'];
			$color_var .= ' .iq-title-box .iq-subtitle {
				color: ' . $color . ' !important;
			}';
		}

		wp_add_inline_style('xamin-global', $color_var);
	}

	public function xamin_banner_title_color()
	{
		//Set Body Color
		$xamin_option = get_option('xamin_options');

		$bg_title_color = isset($xamin_option['bg_title_color']) ? $xamin_option['bg_title_color'] : "";
		$bn_title_color = "";

		if (!empty($bg_title_color)) {
			$bn_title_color .= "
        .iq-breadcrumb-one .title{
            color: $bg_title_color !important;
        }";
		}
		wp_add_inline_style('xamin-global', $bn_title_color);
	}

	public function xamin_layout_color()
	{
		//Set Body Color
		$xamin_option = get_option('xamin_options');

		$xamin_layout_color = $xamin_option['xamin_layout_color'];
		$body_accent_color = "";

		if (function_exists('get_field')) {
			$page_id_body_col = get_queried_object_id();
			$key_body_bg_col = get_field('key_body', $page_id_body_col);
			if (isset($key_body_bg_col['body_variation']) && $key_body_bg_col['body_variation'] == 'has_body_color') {
				if (isset($key_body_bg_col['acf_body_color']) && !empty($key_body_bg_col['acf_body_color'])) {
					$body_back_color = $key_body_bg_col['acf_body_color'];
				}
			}
			if (isset($key_body_bg_col['body_variation']) && $key_body_bg_col['body_variation'] == 'has_body_image') {
				if (isset($key_body_bg_col['acf_body_image']) && !empty($key_body_bg_col['acf_body_image'])) {
					$body_back_bg = $key_body_bg_col['acf_body_image'];
				}
			}
		}

		if (isset($body_back_color) && !empty($body_back_color)) {
			$body_accent_color .= "
            body {
                background-color: $body_back_color !important;
            }";
		} else if (isset($body_back_bg) && !empty($body_back_bg)) {
			$body_accent_color .= "
            body {
				background: url($body_back_bg[url]); 
            }";
		} else if ($xamin_option['layout_set'] == "1" && $key_body_bg_col['body_variation'] == 'default') {
			if (!empty($xamin_layout_color) && $xamin_layout_color != '#ffffff') {
				$body_accent_color .= "
            body {
                background-color: $xamin_layout_color !important;
            }";
			}
		} else {
			$body_accent_color = "";
		}
		wp_add_inline_style('xamin-global', $body_accent_color);
	}

	public function xamin_loader_color()
	{
		//Set Loader Background Color
		$xamin_option = get_option('xamin_options');

		$loader_color = $xamin_option['loader_color'];
		$ld_color = "";

		if (!empty($loader_color) && $loader_color != '#ffffff') {
			$ld_color .= "
        #loading {
            background : $loader_color !important;
        }";
		}
		wp_add_inline_style('xamin-global', $ld_color);
	}


	public function xamin_opacity_color()
	{
		//Set Background Opacity Color
		$xamin_option = get_option('xamin_options');

		if ($xamin_option['bg_opacity'] == "3") {
			$bg_opacity = $xamin_option['opacity_color']['rgba'];
		}
		$op_color = "";

		if ($xamin_option['bg_opacity'] == "3") {
			if (!empty($bg_opacity) && $bg_opacity != '#ffffff') {
				$op_color .= "
				.breadcrumb-video::before,.breadcrumb-bg::before, .breadcrumb-ui::before {
					background : $bg_opacity !important;
				}";
			}
		}
		wp_add_inline_style('xamin-global', $op_color);
	}

	public function xamin_header_radio()
	{
		//Set Text Logo Color
		$xamin_option = get_option('xamin_options');

		$logo = $xamin_option['header_color'];
		$logo_color = "";

		if ($xamin_option['header_radio'] == "1") {
			if (!empty($logo) && $logo != '#ffffff') {
				$logo_color .= "
            .logo-text {
                color : $logo !important;
            }";
			}
		}
		wp_add_inline_style('xamin-global', $logo_color);
	}

	public function xamin_footer_color()
	{
		//Set Footer Background Color
		$xamin_option = get_option('xamin_options');

		if ($xamin_option['change_footer_color'] == "0") {
			$f_color = $xamin_option['footer_color'];
		}
		$footer_color = "";

		if (function_exists('get_field')) {
			$page_id_header = get_queried_object_id();

			$key_header_back = get_field('key_dark_header', $page_id_header);
			$has_dark = $key_header_back['name_menu_has_dark'];
			$f_back_color = $key_header_back['name_back_color'];
		}


		if (isset($has_dark) && $has_dark == 'yes') {
			if (isset($f_back_color) && !empty($f_back_color)) {
				$footer_color .= "
                    .iq-over-dark-90 {
                        background : $f_back_color !important;
                    }";
			}
		} else if ($xamin_option['change_footer_color'] == "0") {
			if (!empty($f_color) && $f_color != '#ffffff') {
				$footer_color .= "
            .iq-over-dark-90 {
                background : $f_color !important;
            }";
			}
		} else {
			$footer_color = '';
		}

		wp_add_inline_style('xamin-global', $footer_color);
	}
}
