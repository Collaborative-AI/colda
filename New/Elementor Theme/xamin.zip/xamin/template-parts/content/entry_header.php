<?php

/**
 * Template part for displaying a post's header
 *
 * @package xamin
 */

namespace Xamin\Xamin;

$xamin_options = get_option('xamin_options');
?>

	<?php
	if (!is_search()) {
		if (class_exists('ReduxFramework')) {
			$options = isset($xamin_options['xamin_display_image']) ? $xamin_options['xamin_display_image'] : 'no';
			if ($options == "yes") {
				get_template_part('template-parts/content/entry_thumbnail', get_post_type());
			}
		} else {
			get_template_part('template-parts/content/entry_thumbnail', get_post_type());
		}
	}
	?>
	
