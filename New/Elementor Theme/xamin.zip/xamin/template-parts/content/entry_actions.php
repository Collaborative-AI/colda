<?php

/**
 * Template part for displaying a post's comment and edit links
 *
 * @package xamin
 */

namespace Xamin\Xamin;
?>
<?php $xamin_option = get_option('xamin_options'); ?>
<div class="entry-actions">
	<div class="blog-button">
		<?php
		if (isset($xamin_option['layout_ui']) && $xamin_option['layout_ui'] == 'yes') {
			if (!empty($xamin_option['blog_btn'])) {
		?>
				<div class="xamin-btn-container">
					<a class="xamin-button xamin-btn-link button-link" href="<?php the_permalink(); ?>">
						<span class="btn_text"><?php echo esc_html($xamin_option['blog_btn']); ?></span><i class="fas fa-angle-double-right"></i>
					</a>
				</div>
			<?php
			} else {
			?>
				<div class="xamin-btn-container">
					<a class="xamin-button xamin-btn-link button-link" href="<?php the_permalink(); ?>">
						<span class="btn_text"><?php esc_html_e('Read More', 'xamin'); ?></span><i class="fas fa-angle-double-right"></i>
					</a>
				</div>
			<?php
			}
		} else {
			if (!empty($xamin_option['blog_btn'])) {
			?>
				<a class="button-link" href="<?php the_permalink(); ?>">
					<?php echo esc_html($xamin_option['blog_btn']); ?><i class="fa fa-angle-right" aria-hidden="true"></i>
				</a>
			<?php
			} else { ?>
				<a class="button-link" href="<?php the_permalink(); ?>"><?php esc_html_e('Read More', 'xamin'); ?><i class="fas fa-angle-double-right"></i></a>
		<?php }
		}
		?>
	</div>
</div><!-- .entry-actions -->